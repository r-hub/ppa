/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995, 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"
#include "Mathlib.h"

/* Error Handling for Floating Point Errors */
#ifdef IEEEArith
#include <floatingpoint.h>

static void handle_fperror(int dummy)
{
	errno = ERANGE;
	fpresetsticky(~0);
	signal(SIGFPE, handle_fperror);
}
#else
static void handle_fperror(int dummy)
{
	errno = ERANGE;
	signal(SIGFPE, handle_fperror);
}
#endif

#ifdef SVIDArith
int matherr(struct exception *exc)
{
	switch (exc->type) {
	case DOMAIN:
	case SING:
		errno = EDOM;
		break;
	case OVERFLOW:
		errno = ERANGE;
		break;
	case UNDERFLOW:
		exc->retval = 0.0;
		break;
	}
	return 1;
}
#endif

/* Arithmetic Initialization */
void InitArithmetic()
{
	R_NaLogical = INT_MIN;
	R_NaInteger = INT_MIN;
	R_NaFactor = INT_MIN;
	R_NaReal = DBL_MAX;
	signal(SIGFPE, handle_fperror);
}

/* Base 2 Logs */
double log2(double x)
{
	return log(x) / 0.69314718055994530941;
}

static SEXP unary(SEXP, SEXP);
static SEXP binary(SEXP, SEXP);
static SEXP integer_unary(int, SEXP);
static SEXP real_unary(int, SEXP);
static SEXP integer_binary(int, SEXP, SEXP);
static SEXP real_binary(int, SEXP, SEXP);
static void math1(double (*)(), double *, double *, int);
static void math2(double (*f) (), double *, int, double *, int, double *, int);
static void math3(double (*f) (), double *, int, double *, int, double *, int, double *, int);
static void math4(double (*f) (), double *, int, double *, int, double *, int, double *, int, double *, int);
static int naflag;
static SEXP lcall;

/* Unary and Binary Operators */
SEXP do_arith(SEXP call, SEXP op, SEXP args, SEXP env)
{
	lcall = call;
	switch (length(args)) {
	case 1:
		return unary(op, CAR(args));
	case 2:
		return binary(op, args);
	default:
		error("operator with more than two arguments\n");
	}
	/*NOTREACHED*/
}

SEXP do_intdiv(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP s1, s2, ans;
	int i, n, n1, n2, x1, x2;
	checkArity(op, args);
	s1 = CAR(args) = coerceVector(CAR(args), INTSXP);
	s2 = CADR(args) = coerceVector(CADR(args), INTSXP);
	n1 = LENGTH(s1);
	n2 = LENGTH(s2);
	n = (n1 > n2) ? n1 : n2;
	ans = allocVector(INTSXP, n);
	for (i = 0; i < n; i++) {
		x1 = INTEGER(s1)[i % n1];
		x2 = INTEGER(s2)[i % n2];
		if (x1 == NA_INTEGER || x2 == NA_INTEGER || x2 == 0)
			INTEGER(ans)[i] = NA_INTEGER;
		else
			INTEGER(ans)[i] = x1 / x2;
	}
	return ans;
}

static void vecTooLong()
{
	errorcall(lcall, "vector longer than time-series\n");
	/* NOTREACHED */
}

static SEXP binary(SEXP op, SEXP args)
{
	SEXP x, y, dims, tsp, names;
	int xarray, yarray, xts, yts;

	x = CAR(args);
	y = CADR(args);

	if (!isNumeric(x) || !isNumeric(y))
		errorcall(lcall, "Non-numeric argument to binary operator\n");

	xarray = isArray(x);
	yarray = isArray(y);
	xts = isTs(x);
	yts = isTs(y);
	if (xarray || yarray) {
		xts = 0;
		yts = 0;
		if (xarray && yarray) {
			if (!conformable(x, y))
				errorcall(lcall, "Non-conformable arrays\n");
			PROTECT(dims = getAttrib(x, R_DimSymbol));
			PROTECT(names = getAttrib(x, R_DimNamesSymbol));
		}
		else if (xarray) {
			PROTECT(dims = getAttrib(x, R_DimSymbol));
			PROTECT(names = getAttrib(x, R_DimNamesSymbol));
		}
		else if (yarray) {
			PROTECT(dims = getAttrib(y, R_DimSymbol));
			PROTECT(names = getAttrib(y, R_DimNamesSymbol));
		}
	}
	else if (xts || yts) {
		if (xts && yts) {
			if (!tsConform(x, y))
				errorcall(lcall, "Non-conformable time-series\n");
			PROTECT(tsp = getAttrib(x, R_TspSymbol));
		}
		else if (xts) {
			if (length(x) < length(y))
				vecTooLong();
			PROTECT(tsp = getAttrib(x, R_TspSymbol));
		}
		else if (yts) {
			if (length(y) < length(x))
				vecTooLong();
			PROTECT(tsp = getAttrib(y, R_TspSymbol));
		}
	}
	else {
		PROTECT(dims = R_NilValue);
		PROTECT(names = getAttrib(x, R_NamesSymbol));
	}
	if (TYPEOF(x) == REALSXP || TYPEOF(y) == REALSXP) {
		x = CAR(args) = coerceVector(x, REALSXP);
		y = CADR(args) = coerceVector(y, REALSXP);
		x = real_binary(PRIMVAL(op), x, y);
	}
	else {
		x = integer_binary(PRIMVAL(op), x, y);
	}

	if (xts || yts) {
		PROTECT(x);
		setAttrib(x, R_TspSymbol, tsp);
		UNPROTECT(2);
	}
	else {
		PROTECT(x);
		if (dims != R_NilValue) {
			setAttrib(x, R_DimSymbol, dims);
			setAttrib(x, R_DimNamesSymbol, names);
		}
		else {
			if( length(x) == length(names) )
				setAttrib(x, R_NamesSymbol, names);
		}
		UNPROTECT(3);
	}
	return x;
}

static SEXP unary(SEXP op, SEXP s1)
{
	switch (TYPEOF(s1)) {
	case LGLSXP:
	case INTSXP:
		return integer_unary(PRIMVAL(op), s1);
	case REALSXP:
		return real_unary(PRIMVAL(op), s1);
	default:
		errorcall(lcall, "Invalid argument to unary operator\n");
	}
	/*NOTREACHED*/
}

static SEXP integer_unary(int code, SEXP s1)
{
	int i, n, x;
	SEXP ans;

	switch(code) {
	case PLUSOP:
		return s1;
	case MINUSOP:
		ans = duplicate(s1);
		n = LENGTH(s1);
		for (i = 0; i < n; i++) {
			x = INTEGER(s1)[i];
			INTEGER(ans)[i] = (x == NA_INTEGER) ?
				NA_INTEGER : ((x == 0.0) ? 0 : -x);
		}
		return ans;
	default:
		error("illegal unary operator\n");
	}
}

static SEXP real_unary(int code, SEXP s1)
{
	int i, n;
	double x;
	SEXP ans;

	switch(code) {
	case PLUSOP: return s1;
	case MINUSOP:
		ans = duplicate(s1);
		n = LENGTH(s1);
		for (i = 0; i < n; i++) {
			x = REAL(s1)[i];
			REAL(ans)[i] = (x == NA_REAL) ?
				NA_REAL : ((x == 0.0) ? 0.0 : -x);
		}
		return ans;
	default:
		error("illegal unary operator\n");
	}
}

static SEXP integer_binary(int code, SEXP s1, SEXP s2)
{
	int i, n, n1, n2;
	int x1, x2;
	SEXP ans;

	n1 = LENGTH(s1);
	n2 = LENGTH(s2);
	n = (n1 > n2) ? n1 : n2;

	if (code == DIVOP || code == POWOP)
		ans = allocVector(REALSXP, n);
	else
		ans = allocVector(INTSXP, n);

	if (n1 < 1 || n2 < 1) {
		for (i = 0; i < n; i++)
			INTEGER(ans)[i] = NA_INTEGER;
		return ans;
	}

	switch (code) {
	case PLUSOP:
		for (i = 0; i < n; i++) {
			x1 = INTEGER(s1)[i % n1];
			x2 = INTEGER(s2)[i % n2];
			if (x1 == NA_INTEGER || x2 == NA_INTEGER)
				INTEGER(ans)[i] = NA_INTEGER;
			else
				INTEGER(ans)[i] = x1 + x2;
		}
		break;
	case MINUSOP:
		for (i = 0; i < n; i++) {
			x1 = INTEGER(s1)[i % n1];
			x2 = INTEGER(s2)[i % n2];
			if (x1 == NA_INTEGER || x2 == NA_INTEGER)
				INTEGER(ans)[i] = NA_INTEGER;
			else
				INTEGER(ans)[i] = x1 - x2;
		}
		break;
	case TIMESOP:
		for (i = 0; i < n; i++) {
			x1 = INTEGER(s1)[i % n1];
			x2 = INTEGER(s2)[i % n2];
			if (x1 == NA_INTEGER || x2 == NA_INTEGER)
				INTEGER(ans)[i] = NA_INTEGER;
			else
				INTEGER(ans)[i] = x1 * x2;
		}
		break;
	case DIVOP:
		for (i = 0; i < n; i++) {
			x1 = INTEGER(s1)[i % n1];
			x2 = INTEGER(s2)[i % n2];
			if (x1 == NA_INTEGER || x2 == NA_INTEGER || x2 == 0)
				REAL(ans)[i] = NA_REAL;
			else
				REAL(ans)[i] = (double) x1 / (double) x2;
		}
		break;
	case POWOP:
		for (i = 0; i < n; i++) {
			x1 = INTEGER(s1)[i % n1];
			x2 = INTEGER(s2)[i % n2];
			if (x1 == NA_INTEGER || x2 == NA_INTEGER || x2 == 0)
				REAL(ans)[i] = NA_REAL;
			else {
				errno = 0;
				REAL(ans)[i] = pow((double) x1, (double) x2);
				if (errno)
					REAL(ans)[i] = NA_REAL;
			}
		}
		break;
	case MODOP:
		for (i = 0; i < n; i++) {
			x1 = INTEGER(s1)[i % n1];
			x2 = INTEGER(s2)[i % n2];
			if (x1 == NA_INTEGER || x2 == NA_INTEGER || x2 == 0)
				INTEGER(ans)[i] = NA_INTEGER;
			else {
				INTEGER(ans)[i] = x1 % x2;
			}
		}
		break;
	}
	return ans;
}

static SEXP real_binary(int code, SEXP s1, SEXP s2)
{
	int i, n, n1, n2;
	double x1, x2, q;
	SEXP ans;

	n1 = LENGTH(s1);
	n2 = LENGTH(s2);
	n = (n1 > n2) ? n1 : n2;
	PROTECT(s1);
	PROTECT(s2);
	ans = allocVector(REALSXP, n);
	UNPROTECT(2);

	if (n1 < 1 || n2 < 1) {
		for (i = 0; i < n; i++)
			REAL(ans)[i] = NA_REAL;
		return ans;
	}

	switch (code) {
	case PLUSOP:
		for (i = 0; i < n; i++) {
			x1 = REAL(s1)[i % n1];
			x2 = REAL(s2)[i % n2];
			if (x1 == NA_REAL || x2 == NA_REAL)
				REAL(ans)[i] = NA_REAL;
			else {
				errno = 0;
				REAL(ans)[i] = x1 + x2;
				if (errno) {
					REAL(ans)[i] = NA_REAL;
					errno = 0;
				}
			}
		}
		break;
	case MINUSOP:
		for (i = 0; i < n; i++) {
			x1 = REAL(s1)[i % n1];
			x2 = REAL(s2)[i % n2];
			if (x1 == NA_REAL || x2 == NA_REAL)
				REAL(ans)[i] = NA_REAL;
			else {
				errno = 0;
				REAL(ans)[i] = x1 - x2;
				if (errno) {
					REAL(ans)[i] = NA_REAL;
					errno = 0;
				}
			}
		}
		break;
	case TIMESOP:
		for (i = 0; i < n; i++) {
			x1 = REAL(s1)[i % n1];
			x2 = REAL(s2)[i % n2];
			if (x1 == NA_REAL || x2 == NA_REAL)
				REAL(ans)[i] = NA_REAL;
			else {
				errno = 0;
				REAL(ans)[i] = x1 * x2;
				if (errno) {
					REAL(ans)[i] = NA_REAL;
					errno = 0;
				}
			}
		}
		break;
	case DIVOP:
		for (i = 0; i < n; i++) {
			x1 = REAL(s1)[i % n1];
			x2 = REAL(s2)[i % n2];
			if (x1 == NA_REAL || x2 == NA_REAL || x2 == 0.0)
				REAL(ans)[i] = NA_REAL;
			else {
				errno = 0;
				REAL(ans)[i] = x1 / x2;
				if (errno) {
					REAL(ans)[i] = NA_REAL;
					errno = 0;
				}
			}
		}
		break;
	case POWOP:
		for (i = 0; i < n; i++) {
			x1 = REAL(s1)[i % n1];
			x2 = REAL(s2)[i % n2];
			if (x1 == NA_REAL || x2 == NA_REAL)
				REAL(ans)[i] = NA_REAL;
			else {
				errno = 0;
				REAL(ans)[i] = pow(x1, x2);
				if (errno) {
					REAL(ans)[i] = NA_REAL;
					errno = 0;
				}
			}
		}
		break;
	case MODOP:
		for (i = 0; i < n; i++) {
			x1 = REAL(s1)[i % n1];
			x2 = REAL(s2)[i % n2];
			if (x1 == NA_REAL || x2 == NA_REAL || x2 == 0.0)
				REAL(ans)[i] = NA_REAL;
			else {
				errno = 0;
				/* REAL(ans)[i] = fmod(x1, x2) */
				q = x1 / x2;
				REAL(ans)[i] = x1 - ((x1 < 0.0) ?  ceil(q) : floor(q)) * x2;
				if (errno) {
					REAL(ans)[i] = NA_REAL;
					errno = 0;
				}
			}
		}
		break;
	}
	return ans;
}

#define MATH1(num,name)	case num: \
				math1(name, REAL(s), REAL(t), LENGTH(s)); \
				break

/* Mathematical Functions of One Argument */
SEXP do_math1(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP s, t;

	checkArity(op, args);
	if (!isNumeric(t = CAR(args)))
		errorcall(call, "Non-numeric argument to mathematical function\n");

	PROTECT(t = coerceVector(t, REALSXP));
	s = allocVector(REALSXP, LENGTH(t));
	UNPROTECT(1);

	naflag = 0;
	switch (PRIMVAL(op)) {
		MATH1(0, fabs);
		MATH1(1, floor);
		MATH1(2, ceil);
		MATH1(3, sqrt);
		MATH1(4, sign);

		MATH1(10, cos);
		MATH1(11, sin);
		MATH1(12, tan);
		MATH1(13, acos);
		MATH1(14, asin);
		MATH1(15, atan);

		MATH1(20, exp);
		MATH1(21, log);
		MATH1(22, log2);
		MATH1(23, log10);

		MATH1(30, lgamma);
		MATH1(31, gamma);

		MATH1(32, digamma);
		MATH1(33, trigamma);
		MATH1(34, tetragamma);
		MATH1(35, pentagamma);

	default:
		error("internal error in do_math1\n");
	}
	if (naflag)
		warning("NAs produced in function \"%s\"\n", PRIMNAME(op));

	PROTECT(t);
	PROTECT(s);
	ATTRIB(s) = duplicate(ATTRIB(t));
	UNPROTECT(2);

	return s;
}

static void math1(double (*f) (), double * x, double * y, int n)
{
	int i;
	double yi;

	for (i = 0; i < n; i++) {
		yi = y[i];
		if (yi == NA_REAL)
			x[i] = NA_REAL;
		else {
			errno = 0;
			x[i] = f(y[i]);
			if (errno) {
				x[i] = NA_REAL;
				naflag = 1;
				errno = 0;
			}
		}
	}
}

#define MATH2(num, name)	case num: \
				math2(name, REAL(s), n, REAL(t), LENGTH(t), REAL(u), LENGTH(u)); \
				break

/* Mathematical Functions of Two Arguments */
SEXP do_math2(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP s, t, u;
	int i, n, n1, n2;

	checkArity(op, args);

	if (!isNumeric(t = CAR(args)) ||
		!isNumeric(u = CADR(args)))
			errorcall(call, "Non-numeric argument to mathematical function\n");

	PROTECT(t = coerceVector(t, REALSXP));
	PROTECT(u = coerceVector(u, REALSXP));
	n1 = LENGTH(t);
	n2 = LENGTH(u);
	n = (n1 < n2) ? n2 : n1;
	s = allocVector(REALSXP, n);
	UNPROTECT(2);

	if (n1 < 1 || n2 < 1) {
		for (i = 0; i < n; i++)
			REAL(s)[i] = NA_REAL;
	}
	else {
		naflag = 0;
		switch (PRIMVAL(op)) {
			MATH2(0, atan2);
			MATH2(1, lbeta);
			MATH2(2, beta);
			MATH2(3, rround);
			MATH2(4, lchoose);
			MATH2(5, choose);
			MATH2(6, dchisq);
			MATH2(7, pchisq);
			MATH2(8, qchisq);
			MATH2(9, dexp);
			MATH2(10, pexp);
			MATH2(11, qexp);
			MATH2(12, dgeom);
			MATH2(13, pgeom);
			MATH2(14, qgeom);
			MATH2(15, dpois);
			MATH2(16, ppois);
			MATH2(17, qpois);
			MATH2(18, dt);
			MATH2(19, pt);
			MATH2(20, qt);
			MATH2(21, prec);
		default:
			error("internal error in do_math2\n");
		}
		if (naflag)
			warning("NAs produced in function \"%s\"\n", PRIMNAME(op));
	}
	/*
	 * PROTECT(s); PROTECT(t); ATTRIB(s) = duplicate(ATTRIB(t));
	 * UNPROTECT(2);
	 */
	return s;
}

static void math2(double (*f) (), double * x, int nx, double * y, int ny, double * z, int nz)
{
	int i;
	double yi, zi;

	for (i = 0; i < nx; i++) {
		yi = y[i % ny];
		zi = z[i % nz];
		if (yi == NA_REAL || zi == NA_REAL)
			x[i] = NA_REAL;
		else {
			errno = 0;
			x[i] = f(yi, zi);
			if (errno) {
				x[i] = NA_REAL;
				naflag = 1;
				errno = 0;
			}
		}
	}
}

#define MATH3(num,name) \
	case num: \
	math3(name, REAL(s), n, REAL(t), LENGTH(t), REAL(u), LENGTH(u), REAL(v), LENGTH(v)); \
	break

/* Mathematic Functions of Three Arguments */
SEXP do_math3(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP s, t, u, v;
	int i, n, n1, n2, n3;

	checkArity(op, args);

	if (!isNumeric(t = CAR(args)) ||
		!isNumeric(u = CADR(args)) ||
		!isNumeric(v = CADDR(args)))
			errorcall(call, "non-numeric argument to mathematical function\n");

	PROTECT(t = coerceVector(t, REALSXP));
	PROTECT(u = coerceVector(u, REALSXP));
	PROTECT(v = coerceVector(v, REALSXP));
	n1 = LENGTH(t);
	n2 = LENGTH(u);
	n3 = LENGTH(v);
	n = n1;
	if (n2 > n)
		n = n2;
	if (n3 > n)
		n = n3;
	s = allocVector(REALSXP, n);
	UNPROTECT(3);

	if (n1 < 1 || n2 < 1 || n3 < 1) {
		for (i = 0; i < n; i++)
			REAL(s)[i] = NA_REAL;
	}
	else {
		naflag = 0;
		switch (PRIMVAL(op)) {

			MATH3(1, dbeta);
			MATH3(2, pbeta);
			MATH3(3, qbeta);

			MATH3(4, dbinom);
			MATH3(5, pbinom);
			MATH3(6, qbinom);

			MATH3(7, dcauchy);
			MATH3(8, pcauchy);
			MATH3(9, qcauchy);

			MATH3(10, df);
			MATH3(11, pf);
			MATH3(12, qf);

			MATH3(13, dgamma);
			MATH3(14, pgamma);
			MATH3(15, qgamma);

			MATH3(16, dlnorm);
			MATH3(17, plnorm);
			MATH3(18, qlnorm);

			MATH3(19, dlogis);
			MATH3(20, plogis);
			MATH3(21, qlogis);

			MATH3(22, dnbinom);
			MATH3(23, pnbinom);
			MATH3(24, qnbinom);

			MATH3(25, dnorm);
			MATH3(26, pnorm);
			MATH3(27, qnorm);

			MATH3(28, dunif);
			MATH3(29, punif);
			MATH3(30, qunif);

			MATH3(31, dweibull);
			MATH3(32, pweibull);
			MATH3(33, qweibull);

			/*
			   MATH3(34, dnchisq);
			 */
			MATH3(35, pnchisq);
			MATH3(36, qnchisq);


		default:
			error("internal error in do_math3\n");
		}
		if (naflag)
			warning("NAs produced in function \"%s\"\n", PRIMNAME(op));
	}
	/*
	 * PROTECT(s); PROTECT(t); ATTRIB(s) = duplicate(ATTRIB(t));
	 * UNPROTECT(2);
	 */
	return s;
}

static void math3(double (*f) (), double * w, int nw, double * x, int nx, double * y, int ny, double * z, int nz)
{
	int i;
	double xi, yi, zi;

	for (i = 0; i < nw; i++) {
		xi = x[i % nx];
		yi = y[i % ny];
		zi = z[i % nz];
		if (xi == NA_REAL || yi == NA_REAL || zi == NA_REAL)
			w[i] = NA_REAL;
		else {
			errno = 0;
			w[i] = f(xi, yi, zi);
			if (errno) {
				w[i] = NA_REAL;
				naflag = 1;
				errno = 0;
			}
		}
	}
}

#define MATH4(num,name) \
	case num: \
		math4(name, REAL(s), n, REAL(t), LENGTH(t), REAL(u), LENGTH(u), REAL(v), LENGTH(v), REAL(w), LENGTH(w)); \
		break

/* Mathematical Functions of Four Arguments */
SEXP do_math4(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP s, t, u, v, w;
	int i, n, n1, n2, n3, n4;

	checkArity(op, args);

	if (!isNumeric(t = CAR(args)) ||
		!isNumeric(u = CADR(args)) ||
		!isNumeric(v = CADDR(args)) ||
		!isNumeric(w = CADDDR(args)))
			errorcall(call, "non-numeric argument to mathematical function\n");

	PROTECT(t = coerceVector(t, REALSXP));
	PROTECT(u = coerceVector(u, REALSXP));
	PROTECT(v = coerceVector(v, REALSXP));
	PROTECT(w = coerceVector(w, REALSXP));
	n1 = LENGTH(t);
	n2 = LENGTH(u);
	n3 = LENGTH(v);
	n4 = LENGTH(w);
	n = n1;
	if (n2 > n)
		n = n2;
	if (n3 > n)
		n = n3;
	if (n4 > n)
		n = n4;
	s = allocVector(REALSXP, n);
	UNPROTECT(4);

	if (n1 < 1 || n2 < 1 || n3 < 1) {
		for (i = 0; i < n; i++)
			REAL(s)[i] = NA_REAL;
	}
	else {
		naflag = 0;
		switch (PRIMVAL(op)) {
			MATH4(1, dhyper);
			MATH4(2, phyper);
			MATH4(3, qhyper);
		default:
			error("internal error in do_math4\n");
		}
		if (naflag)
			warning("NAs produced in function \"%s\"\n", PRIMNAME(op));
	}
	/*
	 * PROTECT(s); PROTECT(t); ATTRIB(s) = duplicate(ATTRIB(t));
	 * UNPROTECT(2);
	 */
	return s;
}

static void math4(double (*f) (), double * w, int nw, double * x, int nx, double * y, int ny, double * z, int nz, double * a,
		  int na)
{
	int i;
	double xi, yi, zi, ai;

	for (i = 0; i < nw; i++) {
		xi = x[i % nx];
		yi = y[i % ny];
		zi = z[i % nz];
		ai = a[i % na];
		if (xi == NA_REAL || yi == NA_REAL || zi == NA_REAL || ai == NA_REAL)
			w[i] = NA_REAL;
		else {
			errno = 0;
			w[i] = f(xi, yi, zi, ai);
			if (errno) {
				w[i] = NA_REAL;
				naflag = 1;
				errno = 0;
			}
		}
	}
}
