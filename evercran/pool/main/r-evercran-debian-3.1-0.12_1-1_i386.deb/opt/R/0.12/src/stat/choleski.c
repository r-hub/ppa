/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Linpack.h"

/*
 *	CHOLESKI performs the choleski decomposition of a symmetric
 *	positive-definite matrix.  This is a wrapper for the linpack
 *	routine DPOFA.
 *
 *	On Entry
 *
 *	   a	   double[lda,n]
 *		   the upper triangle of the matrix to be factorized
 *		   is contained in the upper triangle of a.
 *
 *	   lda	   int
 *		   the leading dimension of a.
 *
 *	   n	   int
 *		   the number or rows and columns of the matrix
 *		   to be factorized.
 *
 *	On Return
 *
 *	   v	   double[n,n]
 *		   the square-root (Choleski) factor.
 *
 *	   info	   int*
 *		   the error indicator from DPOFA.  This will be
 *		   zero unless the matrix being factorized is
 *		   not positive definite.
 *
 *	This version dated Aug 25, 1996.
 */

void CHOLESKI(double *a, int lda, int n, double *v, int *info)
{
        int i, j;

	a -= (lda + 1);
	v -= (n + 1);

	for(i=1 ; i<=n ; i++)
		for(j=1 ; j<=n ; j++) {
			if(i > j)
				v[i+j*n] = 0;
			else
				v[i+j*n] = a[i+j*lda];
		}

	DPOFA(&v[lda+1], n, n, info);
}

int choleski_(double *a, int *lda, int *n, double *v, int *info)
{
	CHOLESKI(a, *lda, *n, v, info);
}


/*
 *	CHOL2INV computes the inverse of a postive-definite symmetric
 *	matrix from its Choleski factorization.  This can be used for
 *	example to compute the dispersion matrix for the estimated
 *	parameters in a regression analysis.
 *
 *	On Entry
 *
 *	   x	   double[ldx,k]
 *		   the Choleski decomposition, or the QR decomposition
 *		   computed by DQRDC or DQRDC2.
 *
 *	   ldx	   int
 *		   the leading dimension of the array x.
 *
 *	   n	   int
 *		   the number of rows of the matrix x.
 *
 *	   k	   int
 *		   the number of columns in the matrix k.
 *
 *	On Return
 *
 *	   v	   double[k,k]
 *		   the value of inv(x'x)
 *
 *	This version dated Aug 24, 1996.
 *	Ross Ihaka, University of Auckland.
 */

void CHOL2INV(double *x, int ldx, int n, double *v, int *info)
{
	double d;
	int i, j;

	for(i=0 ; i<n ; i++) {
		if(x[i+i*ldx] == 0) {
			*info = i+1;
			return;
		}
		for(j=i ; j<n ; j++)
			v[i+j*n] = x[i+j*ldx];
	}

	DPODI(v, n, n, &d, 1);

	for(i=0 ; i<n ; i++)
		for(j=0 ; j<i ; j++)
			v[i+j*n] = v[j+i*n];
}

int chol2inv_(double *x, int *ldx, int *n, double *v, int *info)
{
	CHOL2INV(x, *ldx, *n, v, info);
}
