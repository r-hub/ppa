/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DCHEX updates the cholesky factorization
 *
 *                   a = trans(r)*r
 *
 *     of a positive definite matrix a of order p under diagonal
 *     permutations of the form
 *
 *                   trans(e)*a*e
 *
 *     where e is a permutation matrix.  Specifically, given
 *     an upper triangular matrix r and a permutation matrix
 *     e (which is specified by k, l, and job), DCHEX determines
 *     a orthogonal matrix u such that
 *
 *                           u*r*e = rr,
 *
 *     where rr is upper triangular.  At the users option, the
 *     transformation u will be multiplied into the array z.
 *     If a = trans(x)*x, so that r is the triangular part of the
 *     qr factorization of x, then rr is the triangular part of the
 *     qr factorization of x*e, i.e. x with its columns permuted.
 *     For a less terse description of what DCHEX does and how
 *     it may be applied, see the LINPACK guide.
 *
 *     The matrix q is determined as the product u(l-k)*...*u(1)
 *     of plane rotations of the form
 *
 *                           (    c(i)       s(i) )
 *                           (                    ),
 *                           (    -s(i)      c(i) )
 *
 *     where c(i) is double, the rows these rotations operate
 *     on are described below.
 *
 *     There are two types of permutations, which are determined
 *     by the value of job.
 *
 *     1. right circular shift (job = 1).
 *
 *         the columns are rearranged in the following order.
 *
 *                1,...,k-1,l,k,k+1,...,l-1,l+1,...,p.
 *
 *         u is the product of l-k rotations u(i), where u(i)
 *         acts in the (l-i,l-i+1)-plane.
 *
 *     2. left circular shift (job = 2).
 *         the columns are rearranged in the following order
 *
 *                1,...,k-1,k+1,k+2,...,l,k,l+1,...,p.
 *
 *         u is the product of l-k rotations u(i), where u(i)
 *         acts in the (k+i-1,k+i)-plane.
 *
 *     On Entry
 *
 *         r      double(ldr,p), where ldr >= p.
 *                r contains the upper triangular factor
 *                that is to be updated.  elements of r
 *                below the diagonal are not referenced.
 *
 *         ldr    int.
 *                ldr is the leading dimension of the array r.
 *
 *         p      int.
 *                p is the order of the matrix r.
 *
 *         k      int.
 *                k is the first column to be permuted.
 *
 *         l      int.
 *                l is the last column to be permuted.
 *                l must be strictly greater than k.
 *
 *         z      double(ldz,nz), where ldz>=p.
 *                z is an array of nz p-vectors into which the
 *                transformation u is multiplied.  z is
 *                not referenced if nz = 0.
 *
 *         ldz    int.
 *                ldz is the leading dimension of the array z.
 *
 *         nz     int.
 *                nz is the number of columns of the matrix z.
 *
 *         job    int.
 *                job determines the type of permutation.
 *                       job = 1  right circular shift.
 *                       job = 2  left circular shift.
 *
 *     On Return
 *
 *         r      contains the updated factor.
 *
 *         z      contains the updated matrix z.
 *
 *         c      double(p).
 *                c contains the cosines of the transforming rotations.
 *
 *         s      double(p).
 *                s contains the sines of the transforming rotations.
 *
 *     LINPACK. This version dated 08/14/78.
 *     G.W. Stewart, University of Maryland, Argonne National Lab.
 *     C Translation by Ross Ihaka.
 */

#define r(i,j)  r[i+(j)*ldr]
#define z(i,j)  z[i+(j)*ldz]
#define c(i)    c[i]
#define s(i)    s[i]

void DCHEX(double *r, int ldr, int p, int k, int l, double *z, int ldz, int nz, double *c, double *s, int job)
{
	int i, ii, il, iu, j, jj, km1, kp1, lmk, lm1;
	double rjp1j, t;

	r -= (ldr+1);
	z -= (ldz+1);
	c -= 1;
	s -= 1;

	/* initialize */

	km1 = k-1;
	kp1 = k+1;
	lmk = l-k;
	lm1 = l-1;

	/* perform the appropriate task. */

	switch(job) {

	case 1:

		/* reorder the columns. */

		for(i=1 ; i <= l  ; i++) {
			ii = l-i+1;
			s(i) = r(ii, l);
		}
		for(jj=k ; jj <= lm1  ; jj++) {
			j = lm1-jj+k;
			for(i=1 ; i <= j ; i++) 
				r(i, j+1) = r(i, j);
			r(j+1, j+1) = 0.0;
		}
		if(k != 1)
			for(i=1 ; i <= km1  ; i++) {
				ii = l-i+1;
				r(i, k) = s(ii);
			}

		/* calculate the rotations. */

		t = s(1);
		for(i=1 ; i <= lmk  ; i++) {
			DROTG(&s(i+1), &t, &c(i), &s(i));
			t = s(i+1);
		}
		r(k, k) = t;
		for(j=kp1 ; j <= p  ; j++) {
			il = imax(1, l-j+1);
			for(ii=il ; ii <= lmk  ; ii++) {
				i = l-ii;
				t = c(ii)*r(i, j)+s(ii)*r(i+1, j);
				r(i+1, j) = c(ii)*r(i+1, j)-s(ii)*r(i, j);
				r(i, j) = t;
			}
		}

		/* if required, apply the transformations to z. */

		if(nz >= 1)
			for(j=1 ; j <= nz ; j++) 
				for(ii=1 ; ii <= lmk  ; ii++) {
					i = l-ii;
					t = c(ii)*z(i, j)+s(ii)*z(i+1, j);
					z(i+1, j) = c(ii)*z(i+1, j)-s(ii)*z(i, j);
					z(i, j) = t;
				}
		break;

	case 2:

		/* reorder the columns */

		for(i=1 ; i <= k  ; i++) {
			ii = lmk+i;
			s(ii) = r(i, k);
		}
		for(j=k ; j <= lm1  ; j++) {
			for(i=1 ; i <= j ; i++) 
				r(i, j) = r(i, j+1);
			jj = j-km1;
			s(jj) = r(j+1, j+1);
		}
		for(i=1 ; i <= k  ; i++) {
			ii = lmk+i;
			r(i, l) = s(ii);
		}
		for(i=kp1 ; i <= l ; i++) 
			r(i, l) = 0.0;

		/* reduction loop. */

		for(j=k ; j <= p  ; j++) {
			if(j != k) {

				/* apply the rotations. */

				iu = imin(j-1, l-1);
				for(i=k ; i <= iu  ; i++) {
					ii = i-k+1;
					t = c(ii)*r(i, j)+s(ii)*r(i+1, j);
					r(i+1, j) = c(ii)*r(i+1, j)-s(ii)*r(i, j);
					r(i, j) = t;
				}
			}
			if(j < l) {
				jj = j-k+1;
				t = s(jj);
				DROTG(&r(j, j), &t, &c(jj), &s(jj));
			}
		}

		/* apply the rotations to z. */

		if(nz >= 1)
			for(j=1 ; j <= nz ; j++) 
				for(i=k ; i <= lm1  ; i++) {
					ii = i-km1;
					t = c(ii)*z(i, j)+s(ii)*z(i+1, j);
					z(i+1, j) = c(ii)*z(i+1, j)-s(ii)*z(i, j);
					z(i, j) = t;
				}
	}
	return;
}

int dchex_(double *r, int *ldr, int *p, int *k, int *l, double *z, int *ldz, int *nz, double *c, double *s, int *job)
{
	DCHEX(r, *ldr, *p, *k, *l, z, *ldz, *nz, c, s, *job);
}
