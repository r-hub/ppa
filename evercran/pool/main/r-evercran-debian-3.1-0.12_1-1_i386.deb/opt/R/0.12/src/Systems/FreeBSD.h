		/* FreeBSD 2.1 on Intel 486/DX4-100 */

#ifndef _PLATFORM_H_
#define _PLATFORM_H_

#define FreeBSD
#define Unix
#define Readline
#define PosixArith
#define DLSupport
#define Proctime
#define F77_SYMBOL(x)	x ## _
#define F77_QSYMBOL(x)	#x ## "_"

#endif
