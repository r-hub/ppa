		/* SunOS on Sparc */

#ifndef _PLATFORM_H_
#define _PLATFORM_H_

#define SunOS
#define Unix
#define Readline			/* uncomment for readline */
#define PosixArith
#define DLSupport			/* uncomment for DLL support */
#define Proctime			/* uncomment for processing timing */
#define F77_SYMBOL(x)	x ## _
#define F77_QSYMBOL(x)	#x ## "_"

#endif
