/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DPBCO factors a double symmetric positive definite
 *     matrix stored in band form and estimates the condition of the
 *     matrix.
 *
 *     If  rcond  is not needed, DPBFA is slightly faster.
 *     To solve  a*x = b, follow DPBCO by DPBSL.
 *     To compute  inverse(a)*c, follow DPBCO by DPBSL.
 *     To compute  determinant(a), follow DPBCO by DPBDI.
 *
 *     On Entry
 *
 *        abd     double(lda, n)
 *                the matrix to be factored.  the columns of the upper
 *                triangle are stored in the columns of abd and the
 *                diagonals of the upper triangle are stored in the
 *                rows of abd.  see the comments below for details.
 *
 *        lda     int
 *                the leading dimension of the array  abd.
 *                lda must be >= m +1.
 *
 *        n       int
 *                the order of the matrix  a.
 *
 *        m       int
 *                the number of diagonals above the main diagonal.
 *                0 <= m < n.
 *
 *     On Return
 *
 *        abd     an upper triangular matrix  r, stored in band
 *                form, so that  a = trans(r)*r.
 *                if  info != 0, the factorization is not complete.
 *
 *        rcond   double
 *                an estimate of the reciprocal condition of  a.
 *                for the system  a*x = b, relative perturbations
 *                in  a  and  b  of size  epsilon  may cause
 *                relative perturbations in  x  of size  epsilon/rcond.
 *                if  rcond  is so small that the int expression
 *                           1.0 + rcond == 1.0
 *                is true, then  a  may be singular to working
 *                precision.  in particular,  rcond  is zero  if
 *                exact singularity is detected or the estimate
 *                underflows.  if info != 0, rcond is unchanged.
 *
 *        z       double(n)
 *                a work vector whose contents are usually unimportant.
 *                if  a  is singular to working precision, then  z  is
 *                an approximate null vector in the sense that
 *                norm(a*z) = rcond*norm(a)*norm(z).
 *                if  info != 0, z  is unchanged.
 *
 *        info    int
 *                = 0  for normal return.
 *                = k  signals an error condition.  the leading minor
 *                     of order  k  is not positive definite.
 *
 *     Band Storage
 *
 *           if  a  is a symmetric positive definite band matrix,
 *           the following program segment will set up the input.
 *
 *                   m = (band width above diagonal)
 *                   do 20 j = 1, n
 *                      i1 = imax(1, j-m)
 *                      do 10 i = i1, j
 *                         k = i-j+m+1
 *                         abd(k,j) = a(i,j)
 *                10    continue
 *                20 continue
 *
 *           this uses  m +1  rows of  a, except for the  m by m
 *           upper left triangle, which is ignored.
 *
 *     Example..  if the original matrix is
 *
 *           11 12 13  0  0  0
 *           12 22 23 24  0  0
 *           13 23 33 34 35  0
 *            0 24 34 44 45 46
 *            0  0 35 45 55 56
 *            0  0  0 46 56 66
 *
 *     then  n = 6, m = 2  and  abd  should contain
 *
 *            *  * 13 24 35 46
 *            * 12 23 34 45 56
 *           11 22 33 44 55 66
 *
 *     LINPACK.  This version dated 08/14/78.
 *     Cleve Moler, University of New Mexico, Argonne National Lab.
 *     C Translation by Ross Ihaka.
 */

void DPBCO(double *abd, int lda, int n, int m, double *rcond, double *z, int *info)
{
	double ek, t, wk, wkm;
	double anorm, s, sm, ynorm;
	int i, j, j2, k, kb, kp1, l, la, lb, lm, mu;

	abd -= (lda+1);
	z -= 1;

	/* find norm of a */

	for(j=1 ; j <= n  ; j++) {
		l = imin(j, m+1);
		mu = imax(m+2-j, 1);
		z[j] = DASUM(l, &abd[mu+j*lda], 1);
		k = j-l;
		if(m >= mu)
			for(i=mu ; i <= m  ; i++) {
				k = k+1;
				z[k] = z[k]+fabs(abd[i+j*lda]);
			}
	}
	anorm = 0.0;
	for(j=1 ; j <= n ; j++) 
		anorm = fmax(anorm, z[j]);

	/* factor */

	DPBFA(&abd[1+lda], lda, n, m, info);

	if(*info == 0) {

		/* rcond = 1/(norm(a)*(estimate of norm(inverse(a)))). */
		/* estimate = norm(z)/norm(y) where  a*z = y  and  a*y = e. */
		/* the components of  e  are chosen to cause maximum local */
		/* growth in the elements of w  where  trans(r)*w = e. */
		/* the vectors are frequently rescaled to avoid overflow. */

		/* solve trans(r)*w = e */

		ek = 1.0;
		for(j=1 ; j <= n ; j++) 
			z[j] = 0.0;
		for(k=1 ; k <= n  ; k++) {
			if(z[k] != 0.0)
				ek = fsign(ek, -z[k]);
			if(fabs(ek-z[k]) > abd[(m+1)+k*lda]) {
				s = abd[m+1+k*lda]/fabs(ek-z[k]);
				DSCAL(n, s, &z[1], 1);
				ek = s*ek;
			}
			wk = ek-z[k];
			wkm = -ek-z[k];
			s = fabs(wk);
			sm = fabs(wkm);
			wk = wk/abd[m+1+k*lda];
			wkm = wkm/abd[m+1+k*lda];
			kp1 = k+1;
			j2 = imin(k+m, n);
			i = m+1;
			if(kp1 <= j2) {
				for(j=kp1 ; j <= j2  ; j++) {
					i = i-1;
					sm = sm+fabs(z[j]+wkm*abd[i+j*lda]);
					z[j] = z[j]+wk*abd[i+j*lda];
					s = s+fabs(z[j]);
				}
				if(s < sm) {
					t = wkm-wk;
					wk = wkm;
					i = m+1;
					for(j=kp1 ; j <= j2  ; j++) {
						i = i-1;
						z[j] = z[j]+t*abd[i+j*lda];
					}
				}
			}
			z[k] = wk;
		}
		s = 1.0/DASUM(n, &z[1], 1);
		DSCAL(n, s, &z[1], 1);

		/* solve  r*y = w */

		for(kb=1 ; kb <= n  ; kb++) {
			k = n+1-kb;
			if(fabs(z[k]) > abd[(m+1)+k*lda]) {
				s = abd[m+1+k*lda]/fabs(z[k]);
				DSCAL(n, s, &z[1], 1);
			}
			z[k] = z[k]/abd[m+1+k*lda];
			lm = imin(k-1, m);
			la = m+1-lm;
			lb = k-lm;
			t = -z[k];
			DAXPY(lm, t, &abd[la+k*lda], 1, &z[lb], 1);
		}
		s = 1.0/DASUM(n, &z[1], 1);
		DSCAL(n, s, &z[1], 1);

		ynorm = 1.0;

		/* solve trans(r)*v = y */

		for(k=1 ; k <= n  ; k++) {
			lm = imin(k-1, m);
			la = m+1-lm;
			lb = k-lm;
			z[k] = z[k]-DDOT(lm, &abd[la+k*lda], 1, &z[lb], 1);
			if(fabs(z[k]) > abd[(m+1)+k*lda]) {
				s = abd[m+1+k*lda]/fabs(z[k]);
				DSCAL(n, s, &z[1], 1);
				ynorm = s*ynorm;
			}
			z[k] = z[k]/abd[m+1+k*lda];
		}
		s = 1.0/DASUM(n, &z[1], 1);
		DSCAL(n, s, &z[1], 1);
		ynorm = s*ynorm;

		/* solve  r*z = w */

		for(kb=1 ; kb <= n  ; kb++) {
			k = n+1-kb;
			if(fabs(z[k]) > abd[(m+1)+k*lda]) {
				s = abd[m+1+k*lda]/fabs(z[k]);
				DSCAL(n, s, &z[1], 1);
				ynorm = s*ynorm;
			}
			z[k] = z[k]/abd[m+1+k*lda];
			lm = imin(k-1, m);
			la = m+1-lm;
			lb = k-lm;
			t = -z[k];
			DAXPY(lm, t, &abd[la+k*lda], 1, &z[lb], 1);
		}

		/* make znorm = 1.0 */

		s = 1.0/DASUM(n, &z[1], 1);
		DSCAL(n, s, &z[1], 1);
		ynorm = s*ynorm;

		if(anorm != 0.0)
			*rcond = ynorm/anorm;
		else
			*rcond = 0.0;
	}
	return;
}

int dpbco_(double *abd, int *lda, int *n, int *m, double *rcond, double *z, int *info)
{
	DPBCO(abd, *lda, *n, *m, rcond, z, info);
}
