/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Mathlib.h"

/*
 *     dpofa factors a double precision symmetric positive definite
 *     matrix.
 *
 *     dpofa is usually called by dpoco, but it can be called
 *     directly with a saving in time if  rcond  is not needed.
 *     (time for dpoco) = (1 + 18/n)*(time for dpofa) .
 *
 *     on entry
 *
 *        a       double precision(lda, n)
 *                the symmetric matrix to be factored.  only the
 *                diagonal and upper triangle are used.
 *
 *        lda     integer
 *                the leading dimension of the array  a .
 *
 *        n       integer
 *                the order of the matrix  a .
 *
 *     on return
 *
 *        a       an upper triangular matrix  r  so that  a = trans(r)*r
 *                where  trans(r)  is the transpose.
 *                the strict lower triangle is unaltered.
 *                if  info .ne. 0 , the factorization is not complete.
 *
 *        info    integer
 *                = 0  for normal return.
 *                = k  signals an error condition.  the leading minor
 *                     of order  k  is not positive definite.
 *
 *     linpack.  this version dated 08/14/78 .
 *     cleve moler, university of new mexico, argonne national lab.
 */

static void dpofa(double *a, int lda, int n, int *info)
{
	double s, t;
	int j, jm1, k;

	a -= (lda + 1);

	for(j=1 ; j<=n ; j++) {
		*info = j;
		s = 0.0;
		jm1 = j-1;
		if (jm1 >= 1)
			for(k=1 ; k<=jm1 ; k++) {
				t = a[k+j*lda] - ddot(k-1, &a[1+k*lda], 1, &a[1+j*lda], 1);
				t = t/a[k+k*lda];
				a[k+j*lda] = t;
				s = s+t*t;
			}
		s = a[j+j*lda] - s;

		if (s <= 0.0)
			return;
		a[j+j*lda] = sqrt(s);
	}
	*info = 0;
}

/*
 *     dpoco factors a double precision symmetric positive definite
 *     matrix and estimates the condition of the matrix.
 *
 *     if  rcond  is not needed, dpofa is slightly faster.
 *     to solve  a*x = b , follow dpoco by dposl.
 *     to compute  inverse(a)*c , follow dpoco by dposl.
 *     to compute  determinant(a) , follow dpoco by dpodi.
 *     to compute  inverse(a) , follow dpoco by dpodi.
 *
 *     on entry
 *
 *        a       double precision(lda, n)
 *                the symmetric matrix to be factored.  only the
 *                diagonal and upper triangle are used.
 *
 *        lda     integer
 *                the leading dimension of the array  a .
 *
 *        n       integer
 *                the order of the matrix  a .
 *
 *     on return
 *
 *        a       an upper triangular matrix  r  so that  a = trans(r)*r
 *                where  trans(r)  is the transpose.
 *                the strict lower triangle is unaltered.
 *                if  info .ne. 0 , the factorization is not complete.
 *
 *        rcond   double precision
 *                an estimate of the reciprocal condition of  a .
 *                for the system  a*x = b , relative perturbations
 *                in  a  and  b  of size  epsilon  may cause
 *                relative perturbations in  x  of size  epsilon/rcond .
 *                if  rcond  is so small that the logical expression
 *                           1.0 + rcond .eq. 1.0
 *                is true, then  a  may be singular to working
 *                precision.  in particular,  rcond  is zero  if
 *                exact singularity is detected or the estimate
 *                underflows.  if info .ne. 0 , rcond is unchanged.
 *
 *        z       double precision(n)
 *                a work vector whose contents are usually unimportant.
 *                if  a  is close to a singular matrix, then  z  is
 *                an approximate null vector in the sense that
 *                norm(a*z) = rcond*norm(a)*norm(z) .
 *                if  info .ne. 0 , z  is unchanged.
 *
 *        info    integer
 *                = 0  for normal return.
 *                = k  signals an error condition.  the leading minor
 *                     of order  k  is not positive definite.
 *
 *     linpack.  this version dated 08/14/78 .
 *     cleve moler, university of new mexico, argonne national lab.
 */


static void dpoco(double *a, int lda, int n, double *rcond , double *z, int *info)
{
	double ek, t, wk, wkm;
	double anorm, s, sm, ynorm;
	int i, j, jm1, k, kb, kp1;

	a -= (lda + 1);
	z -= 1;

	/* find norm of a using only upper half */

	for(j=1 ; j<=n ; j++) {
		z[j] = dasum(j, &a[1+j*lda], 1);
		jm1 = j-1;
		if (jm1 >= 1)
			for(i=1 ; i<=jm1 ; i++)
				z[i] = z[i]+fabs(a[i+j*lda]);
	}
	anorm = 0.0;
	for(j=1 ; j<=n ; j++)
		anorm = fmax(anorm, z[j]);

	/* factor */

	dpofa(&a[lda+1], lda, n, info);

	/*
	 *  rcond = 1/(norm(a)*(estimate of norm(inverse(a)))) .
	 *  estimate = norm(z)/norm(y) where  a*z = y  and  a*y = e .
	 *  the components of  e  are chosen to cause maximum local
	 *  growth in the elements of w  where  trans(r)*w = e .
	 *  the vectors are frequently rescaled to avoid overflow.
	 */

	if (*info == 0) {

		/* solve trans(r)*w = e */

		ek = 1.0;
		for(j=1 ; j<=n ; j++)
			z[j] = 0.0;
		for(k=1 ; k<=n ; k++) {
			if (z[k] != 0.0)
				ek = fsign(ek, -z[k]);
			if (fabs(ek-z[k]) > a[k+k*lda]) {
				s = a[k+k*lda]/fabs(ek-z[k]);
				dscal(n, s, &z[1], 1);
				ek = s * ek;
			}
			wk = ek-z[k];
			wkm = -ek-z[k];
			s = fabs(wk);
			sm = fabs(wkm);
			wk = wk/a[k+k*lda];
			wkm = wkm/a[k+k*lda];
			kp1 = k+1;
			if (kp1 <= n) {
				for(j=kp1 ; j<=n ; j++) {
					sm = sm+fabs(z[j]+wkm*a[k+j*lda]);
					z[j] = z[j]+wk*a[k+(j)*lda];
					s = s+fabs(z[j]);
				}
				if (s<sm) {
					t = wkm-wk;
					wk = wkm;
					for(j=kp1 ; j<=n ; j++)
						z[j] = z[j]+t*a[k+j*lda];
				}
			}
			z[k] = wk;
		}
		s = 1.0/dasum(n, &z[1], 1);
		dscal(n, s, &z[1], 1);

		/* solve r*y = w */

		for(kb=1 ; kb<=n ; kb++) {
			k = n+1-kb;
			if (fabs(z[k]) > a[k+k*lda]) {
				s = a[k+k*lda]/fabs(z[k]);
				dscal(n, s, &z[1], 1);
			}
			z[k] = z[k]/a[k+k*lda];
			t = -z[k];
			daxpy(k-1, t, &a[1+k*lda], 1, &z[1], 1);
		}
		s = 1.0/dasum(n, &z[1], 1);
		dscal(n, s, &z[1], 1);

		ynorm = 1.0;

		/* solve trans(r)*v = y */

		for(k=1 ; k<=n ; k++) {
			z[k] = z[k]-ddot(k-1, &a[1+k*lda], 1, &z[1], 1);
			if (fabs(z[k]) > a[k+k*lda]) {
				s = a[k+k*lda]/fabs(z[k]);
				dscal(n, s, &z[1], 1);
				ynorm = s*ynorm;
			}
			z[k] = z[k]/a[k+k*lda];
		}
		s = 1.0/dasum(n, &z[1], 1);
		dscal(n, s, &z[1], 1);
		ynorm = s*ynorm;

		/* solve r*z = v */

		for(kb=1 ; kb<=n ; kb++) {
			k = n+1-kb;
			if (fabs(z[k]) > a[k+k*lda]) {
				s = a[k+k*lda]/fabs(z[k]);
				dscal(n, s, &z[1], 1);
				ynorm = s*ynorm;
			}
			z[k] = z[k]/a[k+k*lda];
			t = -z[k];
			daxpy(k-1, t, &a[1+k*lda], 1, &z[1], 1);
		}

		/* make znorm = 1.0 */

		s = 1.0/dasum(n, &z[1], 1);
		dscal(n, s, &z[1], 1);
		ynorm = s*ynorm;

		if (anorm != 0.0)
			*rcond = ynorm/anorm;
		if (anorm == 0.0)
			*rcond = 0.0;
	}
}

/*
 *     dpodi computes the determinant and inverse of a certain
 *     double precision symmetric positive definite matrix (see below)
 *     using the factors computed by dpoco, dpofa or dqrdc.
 *
 *     on entry
 *
 *        a       double precision(lda, n)
 *                the output  a  from dpoco or dpofa
 *                or the output  x  from dqrdc.
 *
 *        lda     integer
 *                the leading dimension of the array  a .
 *
 *        n       integer
 *                the order of the matrix  a .
 *
 *        job     integer
 *                = 11   both determinant and inverse.
 *                = 01   inverse only.
 *                = 10   determinant only.
 *
 *     on return
 *
 *        a       if dpoco or dpofa was used to factor  a  then
 *                dpodi produces the upper half of inverse(a) .
 *                if dqrdc was used to decompose  x  then
 *                dpodi produces the upper half of inverse(trans(x)*x)
 *                where trans(x) is the transpose.
 *                elements of  a  below the diagonal are unchanged.
 *                if the units digit of job is zero,  a  is unchanged.
 *
 *        det     double precision(2)
 *                determinant of  a  or of  trans(x)*x  if requested.
 *                otherwise not referenced.
 *                determinant = det(1) * 10.0**det(2)
 *                with  1.0 .le. det(1) .lt. 10.0
 *                or  det(1) .eq. 0.0 .
 *
 *     error condition
 *
 *        a division by zero will occur if the input factor contains
 *        a zero on the diagonal and the inverse is requested.
 *        it will not occur if the subroutines are called correctly
 *        and if dpoco or dpofa has set info .eq. 0 .
 *
 *     linpack.  this version dated 08/14/78 .
 *     cleve moler, university of new mexico, argonne national lab.
 */

void dpodi(double *a, int lda, int n, double *det, int job)
{
	double s, t, tmp;
	int i, j, jm1, k, kp1;

	a -= (lda + 1);
	det -= 1;

		/* compute determinant */

	if (job/10 != 0) {
		det[1] = 1.0;
		det[2] = 0.0;
		s = 10.0;
		for(i=1 ; i<=n ; i++) {
			tmp = a[i+i*lda];
			det[1] = tmp * tmp * det[1];

			if (det[1] == 0.0)
				break;
			while (det[1] < 1.0) {
				det[1] = s * det[1];
				det[2] = det[2] - 1.0;
			}
			while (det[1] >= s) {
				det[1] = det[1]/ s;
				det[2] = det[2] + 1.0;
			}
		}
	}

		/* compute inverse(r) */

	if (job%10 != 0) {
		for(k=1 ; k<=n ; k++) {
			a[k+k*lda] = 1.0/a[k+k*lda];
			t = -a[k+k*lda];
			dscal(k-1, t, &a[1+k*lda], 1);
			kp1 = k+1;
			if (n >= kp1)
				for(j=kp1 ; j<=n ; j++) {
					t = a[k+j*lda];
					a[k+j*lda] = 0.0;
					daxpy(k, t, &a[1+k*lda], 1, &a[1+j*lda], 1);
				}
		}

			/* form  inverse(r) * trans(inverse(r)) */

		for(j=1 ; j<=n ; j++) {
			jm1 = j-1;
			if (jm1 >= 1)
				for(k=1 ; k<=jm1 ; k++) {
					t = a[k+j*lda];
					daxpy(k, t, &a[1+j*lda], 1, &a[1+k*lda], 1);
				}
			t = a[j+j*lda];
			dscal(j, t, &a[1+j*lda], 1);
		}
	}
}

/*
 *     dposl solves the double precision symmetric positive definite
 *     system a * x = b
 *     using the factors computed by dpoco or dpofa.
 *
 *     on entry
 *
 *        a       double precision(lda, n)
 *                the output from dpoco or dpofa.
 *
 *        lda     integer
 *                the leading dimension of the array  a .
 *
 *        n       integer
 *                the order of the matrix  a .
 *
 *        b       double precision(n)
 *                the right hand side vector.
 *
 *     on return
 *
 *        b       the solution vector  x .
 *
 *     error condition
 *
 *        a division by zero will occur if the input factor contains
 *        a zero on the diagonal.  technically this indicates
 *        singularity but it is usually caused by improper subroutine
 *        arguments.  it will not occur if the subroutines are called
 *        correctly and  info .eq. 0 .
 *
 *     to compute  inverse(a) * c  where  c  is a matrix
 *     with  p  columns
 *           call dpoco(a,lda,n,rcond,z,info)
 *           if (rcond is too small .or. info .ne. 0) go to ...
 *           do 10 j = 1, p
 *              call dposl(a,lda,n,c(1,j))
 *        10 continue
 *
 *     linpack.  this version dated 08/14/78 .
 *     cleve moler, university of new mexico, argonne national lab.
 */


static void dposl(double *a, int lda, int n, double *b)
{
	double t;
	int k, kb;

	a -= (lda + 1);
	b -= 1;
		/* solve trans(r)*y = b */

	for(k=1 ; k<=n ; k++) {
		t = ddot(k-1, &a[1+(k)*lda], 1, &b[1], 1);
		b[k] = (b[k]-t)/a[k+k*lda];
	}

		/* solve r*x = y */

	for(kb=1 ; kb<=n ; kb++) {
		k = n+1-kb;
		b[k] = b[k]/a[k+k*lda];
		t = -b[k];
		daxpy(k-1, t, &a[1+k*lda], 1, &b[1], 1);
	}
}




		/*  P u b l i c   I n t e r f a c e s  */


		/* Choleski Decomposition */

int chol_fa(double *a, int *lda, int *n, int *info)
{
	dpofa(a, *lda, *n, info);
}

		/* Choleski Decomposition with Condition Estimate */

int chol_co(double *a, int *lda, int *n, double *rcond , double *z, int *info)
{
	dpoco(a, *lda, *n, rcond , z, info);
}

		/* Choleski Inversion */

int chol_di(double *a, int *lda, int *n, double *det, int *job)
{
	dpodi(a, *lda, *n, det, *job);
}

		/* Linear Equation Solution via Choleski */

int chol_sl(double *a, int *lda, int *n, double *b)
{
	dposl(a, *lda, *n, b);
}

void choleski(double *a, int *plda, int *pn, int *info)
{
        int i, j;
	int lda, n;

	lda = *plda;
	n = *pn;

        a -= (lda + 1);

        dpofa(&a[lda+1], lda, n, info);

        if(!*info) {
                for(i=1 ; i<=n ; i++)
                        for(j=1 ; j<i ; j++)
                                a[i+j*lda] = 0.0;
        }
}
