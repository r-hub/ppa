/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DPPFA factors a double symmetric positive definite
 *     matrix stored in packed form.
 *
 *     DPPFA is usually called by DPPCO, but it can be called
 *     directly with a saving in time if  rcond  is not needed.
 *     (time for DPPCO) = (1 + 18/n)*(time for DPPFA).
 *
 *     On Entry
 *
 *        ap      double(n*(n+1)/2)
 *                the packed form of a symmetric matrix  a.  the
 *                columns of the upper triangle are stored sequentially
 *                in a one-dimensional array of length  n*(n+1)/2.
 *                see comments below for details.
 *
 *        n       int
 *                the order of the matrix  a.
 *
 *     On Return
 *
 *        ap      an upper triangular matrix  r , stored in packed
 *                form, so that  a = trans(r)*r.
 *
 *        info    int
 *                = 0  for normal return.
 *                = k  if the leading minor of order  k  is not
 *                     positive definite.
 *
 *
 *     Packed Storage
 *
 *          The following program segment will pack the upper
 *          triangle of a symmetric matrix.
 *
 *                k = 0
 *                do 20 j = 1, n
 *                   do 10 i = 1, j
 *                      k = k + 1
 *                      ap(k) = a(i,j)
 *             10    continue
 *             20 continue
 *
 *     LINPACK.  This version dated 08/14/78.
 *     Cleve Moler, University of New Mexico, Argonne National Lab.
 *     C Translation by Ross Ihaka.
 */

void DPPFA(double *ap, int n, int *info)
{
	int j, jj, k, kj, kk;
	double s, t;

	ap -= 1;

	jj = 0;
	for(j=1 ; j <= n  ; j++) {
		*info = j;
		s = 0.0;
		kj = jj;
		kk = 0;
		for(k=1 ; k <= j-1  ; k++) {
			kj = kj+1;
			t = ap[kj]-DDOT(k-1, &ap[kk+1], 1, &ap[jj+1], 1);
			kk = kk+k;
			t = t/ap[kk];
			ap[kj] = t;
			s = s+t*t;
		}
		jj = jj+j;
		s = ap[jj]-s;
		if(s <= 0.0) return;
		ap[jj] = sqrt(s);
	}
	*info = 0;
	return;
}

int dppfa_(double *ap, int *n, int *info)
{
	DPPFA(ap, *n, info);
}
