/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DPBSL solves the double symmetric positive definite
 *     band system  a*x = b
 *     using the factors computed by DPBCO or DPBFA.
 *
 *     on entry
 *
 *        abd     double(lda, n)
 *                the output from DPBCO or DPBFA.
 *
 *        lda     int
 *                the leading dimension of the array  abd.
 *
 *        n       int
 *                the order of the matrix  a.
 *
 *        m       int
 *                the number of diagonals above the main diagonal.
 *
 *        b       double(n)
 *                the right hand side vector.
 *
 *     On Return
 *
 *        b       the solution vector  x.
 *
 *     Error Condition
 *
 *        A division by zero will occur if the input factor contains
 *        a zero on the diagonal.  Technically this indicates
 *        singularity but it is usually caused by improper subroutine
 *        arguments.  It will not occur if the subroutines are called
 *        correctly and  info == 0.
 *
 *     To compute  inverse(a) * c  where  c  is a matrix
 *     with  p  columns
 *           dpbco(abd,lda,n,rcond,z,info)
 *           if (rcond is too small.or. info != 0) go to...
 *           do 10 j = 1, p
 *              dpbsl(abd,lda,n,c(1,j))
 *        10 continue
 *
 *     LINPACK.  This version dated 08/14/78.
 *     Cleve Moler, University of New Mexico, Argonne National Lab.
 *     C Translation by Ross Ihaka.
 */

void DPBSL(double *abd, int lda, int n, int m, double *b)
{
	double t;
	int k, kb, la, lb, lm;

	abd -= (lda+1);
	b -= 1;

	/* solve trans(r)*y = b */

	for(k=1 ; k <= n  ; k++) {
		lm = imin(k-1, m);
		la = m+1-lm;
		lb = k-lm;
		t = DDOT(lm, &abd[la+k*lda], 1, &b[lb], 1);
		b[k] = (b[k]-t)/abd[m+1+k*lda];
	}

	/* solve r*x = y */

	for(kb=1 ; kb <= n  ; kb++) {
		k = n+1-kb;
		lm = imin(k-1, m);
		la = m+1-lm;
		lb = k-lm;
		b[k] = b[k]/abd[m+1+k*lda];
		t = -b[k];
		DAXPY(lm, t, &abd[la+k*lda], 1, &b[lb], 1);
	}
	return;
}

int dpbsl_(double *abd, int *lda, int *n, int *m, double *b)
{
	DPBSL(abd, *lda, *n, *m, b);
}
