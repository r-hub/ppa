/*
 *	LMINFL computes basic quantities useful for computing
 *	regression diagnostics.
 *
 *	On Entry
 *
 *	   x	   double[ldx,k]
 *		   the QR decomposition as computed by dqrdc or dqrdc2.
 *
 *	   ldx	   int
 *		   the leading dimension of the array x.
 *
 *	   n	   int
 *		   the number of rows of the matrix x.
 *
 *	   k	   int
 *		   the number of columns in the matrix k.
 *
 *	   qraux   double[k]
 *		   auxiliary information about the QR decomposition.
 *
 *	   b	   double[k]
 *		   the least-squares parameter estimates.
 *
 *	On Return
 *
 *	   hat	   double[n]
 *		   the diagonal of the hat matrix.
 *
 *	   coef	   double[n,p]
 *		   a matrix which has as i-th row contains the estimated
 *		   regression coefficients when the i-th case is omitted
 *		   from the regression.
 *
 *	   sigma   double[n]
 *		   the i-th element of sigma contains an estimate
 *		   of the residual standard deviation for the model with
 *		   the i-th case omitted.
 *
 *	This version dated Aug 24, 1996.
 *	Ross Ihaka, University of Auckland.
 */

#include "Linpack.h"

void LMINFL(double *x, int ldx, int n, int k, double *qraux,
	double *b, double *resid, double *hat, double *coef, double *sigma)
{
	int i, j, info;
	double sum, denom;

		/* hat matrix diagonal */

	for(i=0 ; i<n ; i++)
		hat[i] = 0;
	
	for(j=0 ; j<k ; j++) {
		for(i=0 ; i<n ; i++)
			sigma[i] = 0;
		sigma[j] = 1;
		DQRSL(x, ldx, n, k, qraux,
			sigma, sigma, (double*)0,
			(double*)0, (double*)0, (double*)0,
			10000, &info);
		for(i=0 ; i<n ; i++)
			hat[i] += sigma[i]*sigma[i];
	}

		/* changes in the estimated coefficients */

	for(i=0 ; i<n ; i++) {
		for(j=0 ; j<n ; j++)
			sigma[j] = 0;
		sigma[i] = resid[i]/(1.0 - hat[i]);
		DQRSL(x, ldx, n, k, qraux,
			sigma, (double*)0, sigma,
			(double*)0, (double*)0, (double*)0,
			1000, &info);
		DTRSL(x, ldx, k, sigma, 1, &info);
		for(j=0 ; j<k ; j++)
			coef[i+j*n] = sigma[j];
	}

		/* Estimated residual standard deviation */

	denom = (n - k - 1);
	sum = 0;
	for(i=0 ; i<n ; i++)
		sum += resid[i]*resid[i];

	for(i=0 ; i<n ; i++)
		sigma[i] = sqrt((sum - resid[i]*resid[i]/(1-hat[i]))/denom);
}

int lminfl_(double *x, int *ldx, int *n, int *k, double *qraux,
	double *b, double *resid, double *hat, double *coef, double *sigma)
{
	LMINFL(x, *ldx, *n, *k, qraux, b, resid, hat, coef, sigma);
}
