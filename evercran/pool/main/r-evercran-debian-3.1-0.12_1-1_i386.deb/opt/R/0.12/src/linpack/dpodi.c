/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DPODI computes the determinant and inverse of a certain
 *     double symmetric positive definite matrix (see below)
 *     using the factors computed by DPOCO, DPOFA or DQRDC.
 *
 *     On Entry
 *
 *        a       double(lda, n)
 *                the output  a  from DPOCO or DPOFA
 *                or the output  x  from DQRDC.
 *
 *        lda     int
 *                the leading dimension of the array  a.
 *
 *        n       int
 *                the order of the matrix  a.
 *
 *        job     int
 *                = 11   both determinant and inverse.
 *                = 01   inverse only.
 *                = 10   determinant only.
 *
 *     On Return
 *
 *        a       If DPOCO or DPOFA was used to factor  a  then
 *                dpodi produces the upper half of inverse(a).
 *                if DQRDC was used to decompose  x  then
 *                dpodi produces the upper half of inverse(trans(x)*x)
 *                where trans(x) is the transpose.
 *                elements of  a  below the diagonal are unchanged.
 *                if the units digit of job is zero,  a  is unchanged.
 *
 *        det     double(2)
 *                determinant of  a  or of  trans(x)*x  if requested.
 *                otherwise not referenced.
 *                determinant = det(1) * 10.0**det(2)
 *                with  1.0 .le. det(1) .lt. 10.0
 *                or  det(1) .eq. 0.0.
 *
 *     Error Condition
 *
 *        a division by zero will occur if the input factor contains
 *        a zero on the diagonal and the inverse is requested.
 *        it will not occur if the subroutines are called correctly
 *        and if DPOCO or DPOFA has set info .eq. 0.
 *
 *     LINPACK.  This version dated 08/14/78.
 *     Cleve Moler, University of New Mexico, Argonne National Lab.
 *     C Translation by Ross Ihaka.
 */

void DPODI(double *a, int lda, int n, double *det, int job)
{
	double s, t;
	int i, j, jm1, k, kp1;

	a -= (lda+1);
	det -= 1;

	/* compute determinant */

	if(job/10 != 0) {
		det[1] = 1.0;
		det[2] = 0.0;
		s = 10.0;
		for(i=1 ; i <= n  ; i++) {
			det[1] = fsquare(a[i+i*lda])*det[1];
			if(det[1] == 0.0)
				break;
			while (det[1] < 1.0) {
				det[1] = s*det[1];
				det[2] = det[2]-1.0;
			}
			while (det[1] >= s) {
				det[1] = det[1]/s;
				det[2] = det[2]+1.0;
			}
		}
	}

	/* compute inverse(r) */

	if(job%10 != 0) {
		for(k=1 ; k <= n  ; k++) {
			a[k+k*lda] = 1.0/a[k+k*lda];
			t = -a[k+k*lda];
			DSCAL(k-1, t, &a[1+k*lda], 1);
			kp1 = k+1;
			if(n >= kp1)
				for(j=kp1 ; j <= n  ; j++) {
					t = a[k+j*lda];
					a[k+j*lda] = 0.0;
					DAXPY(k, t, &a[1+k*lda], 1, &a[1+j*lda], 1);
				}
		}

		/* form  inverse(r) * trans(inverse(r)) */

		for(j=1 ; j <= n  ; j++) {
			jm1 = j-1;
			if(jm1 >= 1)
				for(k=1 ; k <= jm1  ; k++) {
					t = a[k+j*lda];
					DAXPY(k, t, &a[1+j*lda], 1, &a[1+k*lda], 1);
				}
			t = a[j+j*lda];
			DSCAL(j, t, &a[1+j*lda], 1);
		}
	}
	return;
}

int dpodi_(double *a, int *lda, int *n, double *det, int *job)
{
	DPODI(a, *lda, *n, det, *job);
}
