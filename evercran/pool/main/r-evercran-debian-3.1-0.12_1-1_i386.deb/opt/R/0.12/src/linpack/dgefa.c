/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DGEFA factors a double matrix by Gaussian elimination.
 *
 *     DGEFA is usually called by DGECO, but it can be called
 *     directly with a saving in time if  rcond  is not needed.
 *     (time for DGECO) = (1 +9/n)*(time for DGEFA) .
 *
 *     On Entry
 *
 *        a       double(lda, n)
 *                the matrix to be factored.
 *
 *        lda     int
 *                the leading dimension of the array  a .
 *
 *        n       int
 *                the order of the matrix  a .
 *
 *     On Return
 *
 *        a       an upper triangular matrix and the multipliers
 *                which were used to obtain it.
 *                the factorization can be written  a = l*u  where
 *                l  is a product of permutation and unit lower
 *                triangular matrices and  u  is upper triangular.
 *
 *        ipvt    int(n)
 *                an int vector of pivot indices.
 *
 *        info    int*
 *                = 0  normal value.
 *                = k  if  u(k,k) == 0.0 .  this is not an error
 *                     condition for this subroutine, but it does
 *                     indicate that dgesl or dgedi will divide by zero
 *                     if called.  use  rcond  in dgeco for a reliable
 *                     indication of singularity.
 *
 *     LINPACK. This version dated 08/14/78 .
 *     Cleve Moler, University of New Mexico, Argonne National Lab.
 *     C Translation by Ross Ihaka.
 */

void DGEFA(double *a, int lda, int n, int *ipvt, int *info)
{
	double t;
	int j, k, kp1, l, nm1;

	a -= (lda+1);
	ipvt -= 1;

	/* Gaussian elimination with partial pivoting */

	*info = 0;
	nm1 = n-1;
	if(nm1 >= 1)
		for(k=1 ; k <= nm1  ; k++) {
			kp1 = k+1;

			/* find l = pivot index */

			l = IDAMAX(n-k+1, &a[k+k*lda], 1)+k-1;
			ipvt[k] = l;

			/* zero pivot implies this column */
			/* already triangularized */

			if(a[l+k*lda] == 0.0)
				*info = k;
			else {

				/* interchange if necessary */

				if(l != k) {
					t = a[l+k*lda];
					a[l+k*lda] = a[k+k*lda];
					a[k+k*lda] = t;
				}

				/* compute multipliers */

				t = -1.0/a[k+k*lda];
				DSCAL(n-k, t, &a[k+1+k*lda], 1);

				/* row elimination with column indexing */

				for(j=kp1 ; j <= n  ; j++) {
					t = a[l+j*lda];
					if(l != k) {
						a[l+j*lda] = a[k+j*lda];
						a[k+j*lda] = t;
					}
					DAXPY(n-k, t, &a[k+1+k*lda], 1, &a[k+1+j*lda], 1);
				}
			}
		}
	ipvt[n] = n;
	if(a[n+n*lda] == 0.0)
		*info = n;
	return;
}

int dgefa_(double *a, int *lda, int *n, int *ipvt, int *info)
{
	DGEFA(a, *lda, *n, ipvt, info);
}
