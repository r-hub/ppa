		/* IRIX Releases 5.2 and 5.3 */

#ifndef _PLATFORM_H_
#define _PLATFORM_H_

#define Irix
#define Unix
/* #define Readline			/* uncomment for GNU readline support */
#define PosixArith
#define DLSupport
#define DLNoSymUnderscore
#define Proctime
#define F77_SYMBOL(x)	x ## _
#define F77_QSYMBOL(x)	#x ## "_"

#endif
