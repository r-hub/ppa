/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DCHDC computes the cholesky decomposition of a positive definite
 *     matrix.  A pivoting option allows the user to estimate the
 *     condition of a positive definite matrix or determine the rank
 *     of a positive semidefinite matrix.
 *
 *     On Entry
 *
 *         a      double(lda,p).
 *                a contains the matrix whose decomposition is to
 *                be computed.  only the upper half of a need be stored.
 *                the lower part of the array a is not referenced.
 *
 *         lda    int.
 *                lda is the leading dimension of the array a.
 *
 *         p      int.
 *                p is the order of the matrix.
 *
 *         work   double.
 *                work is a work array.
 *
 *         jpvt   int(p).
 *                jpvt contains ints that control the selection
 *                of the pivot elements, if pivoting has been requested.
 *                each diagonal element a(k,k)
 *                is placed in one of three classes according to the
 *                value of jpvt(k).
 *
 *                   if jpvt(k) > 0, then x(k) is an initial
 *                                      element.
 *
 *                   if jpvt(k) == 0, then x(k) is a free element.
 *
 *                   if jpvt(k) < 0, then x(k) is a final element.
 *
 *                before the decomposition is computed, initial elements
 *                are moved by symmetric row and column interchanges to
 *                the beginning of the array a and final
 *                elements to the end.  both initial and final elements
 *                are frozen in place during the computation and only
 *                free elements are moved.  at the k-th stage of the
 *                reduction, if a(k,k) is occupied by a free element
 *                it is interchanged with the largest free element
 *                a(l,l) with l >= k.  jpvt is not referenced if
 *                job == 0.
 *
 *        job     int.
 *                job is an int that initiates column pivoting.
 *                if job == 0, no pivoting is done.
 *                if job != 0, pivoting is done.
 *
 *     On Return
 *
 *         a      a contains in its upper half the cholesky factor
 *                of the matrix a as it has been permuted by pivoting.
 *
 *         jpvt   jpvt(j) contains the index of the diagonal element
 *                of a that was moved into the j-th position,
 *                provided pivoting was requested.
 *
 *         info   contains the index of the last positive diagonal
 *                element of the cholesky factor.
 *
 *     for positive definite matrices info = p is the normal return.
 *     for pivoting with positive semidefinite matrices info will
 *     in general be less than p.  however, info may be greater than
 *     the rank of a, since rounding error can cause an otherwise zero
 *     element to be positive. indefinite systems will always cause
 *     info to be less than p.
 *
 *     LINPACK. This version dated 08/14/78.
 *     J.J. Dongarra and G.W. Stewart, Argonne National Laboratory and
 *     University of Maryland.
 *     C Translation by Ross Ihaka.
 */

#define a(i,j)	a[i+(j)*lda]
#define work(i)	work[i]
#define jpvt(i)	jpvt[i]

void DCHDC(double *a, int lda, int p, double *work, int *jpvt, int job, int *info)
{
	int pu, pl, plp1, i, j, jp, jt, k, kb, km1, kp1, l, maxl;
	double temp;
	double maxdia;
	int swapk, negk;

	a -= (lda+1);
	work -= 1;
	jpvt -= 1;

	pl = 1;
	pu = 0;
	*info = p;
	if(job != 0) {

		/* pivoting has been requested. rearrange the */
		/* the elements according to jpvt. */

		for(k=1 ; k <= p  ; k++) {
			swapk = jpvt(k) > 0;
			negk = jpvt(k) < 0;
			jpvt(k) = k;
			if(negk)
				jpvt(k) = -jpvt(k);
			if(swapk) {
				if(k != pl) {
					DSWAP(pl-1, &a(1, k), 1, &a(1, pl), 1);
					temp = a(k, k);
					a(k, k) = a(pl, pl);
					a(pl, pl) = temp;
					plp1 = pl+1;
					if(p >= plp1)
						for(j=plp1 ; j <= p ; j++) 
							if(j < k) {
								temp = a(pl, j);
								a(pl, j) = a(j, k);
								a(j, k) = temp;
							}
							else if(j != k) {
								temp = a(k, j);
								a(k, j) = a(pl, j);
								a(pl, j) = temp;
							}
					jpvt(k) = jpvt(pl);
					jpvt(pl) = k;
				}
				pl = pl+1;
			}
		}
		pu = p;
		if(p >= pl)
			for(kb=pl ; kb <= p  ; kb++) {
				k = p-kb+pl;
				if(jpvt(k) < 0) {
					jpvt(k) = -jpvt(k);
					if(pu != k) {
						DSWAP(k-1, &a(1, k), 1, &a(1, pu), 1);
						temp = a(k, k);
						a(k, k) = a(pu, pu);
						a(pu, pu) = temp;
						kp1 = k+1;
						if(p >= kp1)
							for(j=kp1 ; j <= p ; j++) 
								if(j < pu) {
									temp = a(k, j);
									a(k, j) = a(j, pu);
									a(j, pu) = temp;
								}
								else if(j != pu) {
									temp = a(k, j);
									a(k, j) = a(pu, j);
									a(pu, j) = temp;
								}
						jt = jpvt(k);
						jpvt(k) = jpvt(pu);
						jpvt(pu) = jt;
					}
					pu = pu-1;
				}
			}
	}
	for(k=1 ; k <= p  ; k++) {

		/* reduction loop. */

		maxdia = a(k, k);
		kp1 = k+1;
		maxl = k;

		/* determine the pivot element. */

		if(k >= pl && k < pu)
			for(l=kp1 ; l <= pu ; l++) 
				if(a(l, l) > maxdia) {
					maxdia = a(l, l);
					maxl = l;
				}

		/* quit if the pivot element is not positive. */

		if(maxdia <= 0.0) {
			*info = k-1;
			return;
		}
		if(k != maxl) {

			/* start the pivoting and update jpvt. */

			km1 = k-1;
			DSWAP(km1, &a(1, k), 1, &a(1, maxl), 1);
			a(maxl, maxl) = a(k, k);
			a(k, k) = maxdia;
			jp = jpvt(maxl);
			jpvt(maxl) = jpvt(k);
			jpvt(k) = jp;
		}

		/* reduction step. pivoting is contained across the rows. */

		work(k) = sqrt(a(k, k));
		a(k, k) = work(k);
		if(p >= kp1)
			for(j=kp1 ; j <= p  ; j++) {
				if(k != maxl)
					if(j < maxl) {
						temp = a(k, j);
						a(k, j) = a(j, maxl);
						a(j, maxl) = temp;
					}
					else if(j != maxl) {
						temp = a(k, j);
						a(k, j) = a(maxl, j);
						a(maxl, j) = temp;
					}
				a(k, j) = a(k, j)/work(k);
				work(j) = a(k, j);
				temp = -a(k, j);
				DAXPY(j-k, temp, &work(kp1), 1, &a(kp1, j), 1);
			}
	}
	return;
}

int dchdc_(double *a, int *lda, int *p, double *work, int *jpvt, int *job, int *info)
{
	DCHDC(a, *lda, *p, work, jpvt, *job, info);
}
