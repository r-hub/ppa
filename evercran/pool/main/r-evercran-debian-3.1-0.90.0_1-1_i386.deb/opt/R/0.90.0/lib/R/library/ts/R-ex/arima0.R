###--- >>> `arima0' <<<----- ARIMA Modelling of Time Series -- Preliminary Version

	## alias	 help(arima0)
	## alias	 help(arima0.diag)
	## alias	 help(print.arima0)
	## alias	 help(predict.arima0)

##___ Examples ___:

data(lh)
arima0(lh, order=c(1,0,0))
arima0(lh, order=c(3,0,0))
arima0(lh, order=c(1,0,1))
predict(arima0(lh, order=c(3,0,0)), n.ahead=12)

data(USAccDeaths)
fit <- arima0(USAccDeaths, order=c(0,1,1), seasonal=list(order=c(0,1,1)))
fit
predict(fit, n.ahead=6)

data(LakeHuron)
arima0(LakeHuron, order=c(2,0,0), xreg=1:98)

## Keywords: 'ts'.


