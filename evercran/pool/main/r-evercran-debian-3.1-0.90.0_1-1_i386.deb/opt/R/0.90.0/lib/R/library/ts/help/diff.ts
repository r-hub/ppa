

   diff.ts(ts)                                  R Documentation

   [1mdiff method for ts objects[0m

   [1mDescription:[0m

        `diff' method for `ts' objects.

   [1mUsage:[0m

        diff.ts(x, lag=1, differences=1)

   [1mSee Also:[0m

        `diff'

