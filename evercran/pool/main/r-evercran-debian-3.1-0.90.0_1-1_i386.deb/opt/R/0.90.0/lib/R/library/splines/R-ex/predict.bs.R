###--- >>> `predict.bs' <<<----- Evaluate a predefined spline basis at new values

	## alias	 help(predict.bs)
	## alias	 help(predict.ns)

##___ Examples ___:

library(splines)
data(women)
basis <- ns(women$height, df = 5)
newX <- seq(58, 72, len = 51)
# evaluate the basis at the new data
predict(basis, newX)



