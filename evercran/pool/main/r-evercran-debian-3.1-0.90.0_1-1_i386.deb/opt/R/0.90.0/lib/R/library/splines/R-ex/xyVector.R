###--- >>> `xyVector' <<<----- Construct an xyVector object

	## alias	 help(xyVector)
	## alias	 help(as.data.frame.xyVector)
	## alias	 help(print.xyVector)
	## alias	 help(plot.xyVector)

##___ Examples ___:

library( splines )
data( women )
ispl <- interpSpline( weight ~ height, women )
weights <- predict( ispl, seq( 55, 75, len = 51 ))
class( weights )
plot( weights, type = "l", xlab = "height", ylab = "weight" )
points( women$height, women$weight )
weights

## Keywords: 'models '.


