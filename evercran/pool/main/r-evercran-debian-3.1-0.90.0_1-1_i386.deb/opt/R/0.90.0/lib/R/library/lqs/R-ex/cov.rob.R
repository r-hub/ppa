###--- >>> `cov.rob' <<<----- Resistant Estimation of Multivariate Location and Scatter

	## alias	 help(cov.rob)
	## alias	 help(cov.mve)
	## alias	 help(cov.mcd)

##___ Examples ___:

data(stackloss)
.Random.seed <- 1:4
cov.rob(stackloss)
cov.rob(stack.x, method="mcd", nsamp="exact")

## Keywords: 'robust', 'multivariate'.


