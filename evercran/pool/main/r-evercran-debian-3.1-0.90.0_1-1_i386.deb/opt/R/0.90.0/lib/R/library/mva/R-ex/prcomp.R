###--- >>> `prcomp' <<<----- Principal Components Analysis

	## alias	 help(prcomp)
	## alias	 help(plot.prcomp)
	## alias	 help(print.prcomp)
	## alias	 help(summary.prcomp)
	## alias	 help(print.summary.prcomp)

##___ Examples ___:

## the variances of the variables in the
## USArrests data vary by orders of magnitude
data(USArrests)
prcomp(USArrests)
prcomp(USArrests, scale = TRUE)
plot(prcomp(USArrests))
summary(prcomp(USArrests))



