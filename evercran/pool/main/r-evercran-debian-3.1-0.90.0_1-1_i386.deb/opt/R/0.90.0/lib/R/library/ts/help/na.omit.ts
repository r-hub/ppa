

   na.omit.ts(ts)                               R Documentation

   [1mNA Handling Routines for Time Series[0m

   [1mDescription:[0m

        For `na.omit.ts', initial and final segments with miss-
        ing values in one or more of the series are omitted.
        `Internal' missing values will lead to failure.

        For `na.contiguous' the longest consecutive stretch of
        non-missing values is used. (In the event of a tie, the
        first such stretch.)

   [1mUsage:[0m

        na.contiguous(frame)
        na.omit.ts(frame)

   [1mArguments:[0m

      frame: a univariate or multivariate time series.

   [1mValue:[0m

        A time series without missing values. The class of
        `frame' will be preserved.

   [1mAuthor(s):[0m

        B. D. Ripley

   [1mSee Also:[0m

        `na.omit', `na.fail'

   [1mExamples:[0m

        data(BJsales)
        sales1 <- ts.union(BJsales, lead3=lag(BJsales.lead, -3))
        na.omit.ts(sales1)

        data(presidents)
        na.contiguous(presidents)

