###--- >>> `asVector' <<<----- Coerce an object to a vector

	## alias	 help(asVector.xyVector)

##___ Examples ___:

library( splines )
data( women )
ispl <- interpSpline( weight ~ height,  women )
pred <- predict(ispl)
class(pred)
str(pred)
asVector(pred)

## Keywords: 'models'.


