###--- >>> `as.hclust' <<<----- Convert objects to class hclust

	## alias	 help(as.hclust)
	## alias	 help(as.hclust.twins)

##___ Examples ___:

##Don't run: 
##D x <- matrix(rnorm(30), ncol=3)
##D hc <- hclust(dist(x), method="complete")
##D 
##D library(cluster)
##D ag <- agnes(x, method="complete")
##D 
##D x11()
##D par(mfrow=c(1,2))
##D plot(hc)
##D mtext("hclust", side=1)
##D plot(as.hclust(ag))
##D mtext("agnes", side=1)


## Keywords: 'multivariate', 'cluster'.


