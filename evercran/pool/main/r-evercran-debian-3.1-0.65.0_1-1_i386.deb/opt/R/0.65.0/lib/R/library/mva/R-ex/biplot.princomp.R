###--- >>> `biplot.princomp' <<<----- Biplot for Principal Components

	## alias	 help(biplot.princomp)

##___ Examples ___:

data(USArrests)
biplot(princomp(USArrests))

## Keywords: 'multivariate', 'hplot'.


