#include "Mathlib.h"

double cube(double x)
{
	return x * x * x;
}
