/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995, 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*------------------------------------------------------------------------------

Contexts:

A linked-list of execution contexts is kept so that control-flow constructs
like "next", "break" and "return" will work.  It is also used for error
returns to top-level.

	context[k] -> context[k-1] -> ... -> context[0]
	^					^
	R_GlobalContext				R_ToplevelContext

Contexts are allocated on the stack as the evaluator invokes itself
recursively.  The memory is reclaimed naturally on return through the
recursions (the R_GlobalContext pointer needs adjustment).

A context contains the following information:

	nextcontext	the next level context
	cjmpbuf		longjump information for non-local return
	cstacktop	the current level of the pointer protection stack
	callflag	the context "type"
	cenvir		closure environments (closures only)
			the environment the closure was called from (sysparent)
	parentcall	the call (name of function) that was active
			when the closure was called
	cloenv		for closures, the environment of the closure.
	conexit		code for on.exit calls, to be executed in cenvir
			at exit from the closure (normal or abnormal).
	cend		a pointer to function which executes if there is
			non-local return (i.e. an error)

Context types can be one of:

	CTXT_TOPLEVEL	The toplevel context
	CTXT_BREAK	target for "break"
	CTXT_NEXT	target for "next"
	CTXT_LOOP	target for either "break" or "next"
	CTXT_RETURN	target for "return" (i.e. a closure)
	CTXT_CCODE	other functions that need clean up if an error occurs

A context is created with a call to

	void begincontext(RCNTXT *cptr, int flags, SEXP sysparent, SEXP env)

which sets up the context pointed to by cptr in the appropriate way.
When the context goes "out-of-scope" a call to 

	void endcontext(RCNTXT *cptr)

restores the previous context (i.e. it adjusts the R_GlobalContext pointer).

The non-local jump to a given context takes place in a call to

	void findcontext(int mask, SEXP val)

This causes "val" to be stuffed into a globally accessable place and
then a search to take place back through the context list for an
appropriate context.  The kind of context sort is determined by the
value of "mask".  The value of mask should be the logical OR of all
the context types desired.

The value of "mask" is returned as the value of the setjump call at the
level longjumped to.  This is used to distinguish between break and
next actions.

Contexts can be used as a wrapper around functions that create windows or
open files. These can then be shut/closed gracefully if an error occurs.

------------------------------------------------------------------------------*/

#include "Defn.h"

static void jumpfun(RCNTXT *, int, SEXP);

/* begincontext - begin an execution context */
void begincontext(RCNTXT * cptr, int flags, SEXP sysparent, SEXP syscall, SEXP env)
{
	cptr->nextcontext = R_GlobalContext;
	cptr->cstacktop = R_PPStackTop;
	cptr->callflag = flags;
	cptr->cenvir = sysparent;
	cptr->parentcall = syscall;
	cptr->cloenv = env;
	cptr->conexit = NULL;
	cptr->cend = NULL;
	R_GlobalContext = cptr;
}

/* endcontext - end an execution context */
void endcontext(RCNTXT * cptr)
{
	int savevis = R_Visible;
	if (cptr->cloenv != R_NilValue && cptr->conexit)
		eval(cptr->conexit, cptr->cloenv);
	R_Visible = savevis;
	R_GlobalContext = cptr->nextcontext;
}

/* findcontext - find the correct context */
void findcontext(int mask, SEXP val)
{
	RCNTXT *cptr;

	cptr = R_GlobalContext;

	if (mask & CTXT_LOOP) {		/* break/next */
		if (cptr->callflag & CTXT_LOOP)
			jumpfun(cptr, mask, val);
		else
			error("No loop to break from, jumping to top level\n");
	}
	else {				/* return */
		for (cptr = R_GlobalContext; cptr; cptr = cptr->nextcontext)
			if (cptr->callflag == CTXT_RETURN)
				jumpfun(cptr, mask, val);
		error("No function to return from, jumping to top level\n");
	}
}

/* jumpfun - jump to the named context */
static void jumpfun(RCNTXT * cptr, int mask, SEXP val)
{
	R_PPStackTop = cptr->cstacktop;
	R_ReturnedValue = val;
	if (cptr != R_ToplevelContext)
		R_GlobalContext = cptr->nextcontext;
	else
		R_GlobalContext = R_ToplevelContext;
	longjmp(cptr->cjmpbuf, mask);
}

/*
 * sysparent - look back up the context stack until the nth closure 
 * context and return that cenvir (sysparent)
 */
SEXP sysparent(int n)
{
	RCNTXT *cptr;

	cptr = R_GlobalContext;
	while (cptr != R_ToplevelContext) {
		if (cptr->callflag == CTXT_RETURN)
			if (n == 1)
				return (cptr->cenvir);
			else
				n--;
		cptr = cptr->nextcontext;
	}
	if(n == 1) return R_GlobalEnv;
	else error("sys.parent: not that many enclosing functions\n");
	/*NOTREACHED*/
}

SEXP do_sysparent(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	int n;
	checkArity(op, args);
	n = asInteger(CAR(args));
	if(n == NA_INTEGER || n < 0)
		errorcall(call, "invalid number of environment levels\n");
	return sysparent(n);
}

SEXP parentcall(int n)
{
        RCNTXT *cptr;

        cptr = R_GlobalContext;
        while (cptr != R_ToplevelContext) {
                if (cptr->callflag == CTXT_RETURN)
                        if (n == 1)
                                return (cptr->parentcall);
                        else
                                n--;
                cptr = cptr->nextcontext;
        }
        error("parentcall: not that many enclosing functions\n");
        /*NOTREACHED*/
}

SEXP do_parentcall(SEXP call, SEXP op, SEXP args, SEXP rho)
{
        int n;
        checkArity(op, args);
        n = asInteger(CAR(args));
        if(n == NA_INTEGER || n < 0)
                errorcall(call, "invalid number of environment levels\n");
        return parentcall(n);
}

