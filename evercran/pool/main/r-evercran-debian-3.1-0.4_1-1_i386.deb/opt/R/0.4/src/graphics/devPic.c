/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995, 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Graphics.h"

static char *filename;
static int landscape;
static double width;
static double height;
static double pagewidth;
static double pageheight;

static char *pstart[] = {
#include "devPostScript.h"
	NULL
};

static FILE *psfp;

static void SetFontMag(double mag)
{
}

static int lty;		/* set below */

static unsigned char
	short_dash_list[] = { 4, 4 },
	dotted_list[]     = { 1, 3 },
	dot_dash_list[]   = { 4, 3, 1, 3 },
	long_dash_list[]  = { 7, 4};

static void SetLineType(int newlty)
{
	if(newlty != lty)
		switch(newlty) {
			case 1:
				lty = newlty;
				fprintf(psfp,"[] 0 setdash\n");
				break;
			case 2:
				lty = newlty;
				fprintf(psfp,"[4 4] 0 setdash\n");
				break;
			case 3:
				lty = newlty;
				fprintf(psfp,"[1 3] 0 setdash\n");
				break;
			case 4:
				lty = newlty;
				fprintf(psfp,"[4 3 1 3] 0 setdash\n");
				break;
			case 5:
				lty = newlty;
				fprintf(psfp,"[7 4] 0 setdash\n");
				break;
			default:
				break;
		}
}


					/* Initialize the device */
static int PS_Open(void)
{
	int i;
	if(!(psfp = fopen(filename, "w"))) return 0;
	fprintf(psfp, "%%!PS-Adobe-1.0\n");
	fprintf(psfp, "%%%%DocumentFonts: Helvetica\n");
	fprintf(psfp, "%%%%Title: R Graphics Output\n");
	fprintf(psfp, "%%%%Creator: R Software\n");
	fprintf(psfp, "%%%%Pages: (atend)\n");
	fprintf(psfp, "%%%%BoundingBox: %d %d %d %d\n",
		GP->left/100, GP->bottom/100, GP->right/100, GP->top/100);
	fprintf(psfp, "%%%%EndComments\n");
	if(landscape)
		fprintf(psfp, "%.2f 0 translate 90 rotate\n", 72 * pageheight);
	fprintf(psfp, "/Helvetica findfont %.2f scalefont setfont\n", 10.0);
	fprintf(psfp, "0.5 setlinewidth\n");
	fprintf(psfp, "gsave\n");
	for( i=0 ; pstart[i] ; i++ )
		fprintf(psfp, "%s\n",pstart[i]);
	fprintf(psfp, "%%%%EndProlog\n");
	fprintf(psfp, "%%%%Page: 1 1\n");
}

					/* Set the clipping rectangle */
static void PS_Clip(int x0, int x1, int y0, int y1)
{
	fprintf(psfp, "%.2f %.2f %.2f %.2f c\n", 0.01*x0, 0.01*y0, 0.01*x1, 0.01*y1);
}

					/* Interactive Resize */
static void PS_Resize()
{
}

/* set below */
static pageno;
					/* Start a new page */
static void PS_NewPlot()
{
	++pageno;
	fprintf(psfp, "showpage\n");
	fprintf(psfp, "%%%%Page: %d %d\n", pageno, pageno);
	fprintf(psfp, "grestore gsave\n");
}

					/* Close down the driver */
static void PS_Close(void)
{
	fprintf(psfp, "showpage\n");
	fprintf(psfp, "%%%%Trailer\n");
	fprintf(psfp, "%%%%Pages: %d\n", pageno);
	fclose(psfp);
}


static double xlast;
static double ylast;

static void PS_MoveTo(int x, int y)
{
	fprintf(psfp, "%.2f %.2f m\n", 0.01*x, 0.01*y);
	xlast = x;
	ylast = y;
}

static void PS_Dot(void)
{
}

static void PS_LineTo(int x, int y)
{
	SetLineType(GP->lty);
	fprintf(psfp, "%.2f %.2f l\n", 0.01*x, 0.01*y);
}

static void PS_LStart()
{
	fprintf(psfp, "newpath\n");
}

static void PS_LEnd()
{
	fprintf(psfp, "stroke\n");
}


static void PS_Rect(int x0, int y0, int x1, int y1, int fill)
{
	SetLineType(GP->lty);
	fprintf(psfp, "%.2f %.2f %.2f %.2f r\n", 0.01*x0, 0.01*y0, 0.01*x1, 0.01*y1);
}

static void PS_Polygon(int n, int *x, int *y, col, int border)
{
}

static void pstext(char *str)
{
	fputc('(', psfp);
	for( ; *str ; str++)
		switch(*str) {
			case '\n':
				fprintf(psfp, "\\n");
				break;
			case '-':
				fprintf(psfp, "\\261");
				break;
			case '(':
			case ')':
				fprintf(psfp, "\\%c", *str);
				break;
			default:
				fputc(*str, psfp);
				break;
		}
	fputc(')', psfp);
}

/* set below */
static double cex;

static void PS_Text(char *str, double xc, double yc)
{
	if(cex != GP->cex) {
		cex = GP->cex;
		fprintf(psfp, "/Helvetica findfont %.2f scalefont setfont\n", cex*10.0);
	}
	pstext(str);
	fprintf(psfp," %.2f %.2f t\n", xc, yc);
}

static void PS_RText(char *str, double xc, double yc, int rot)
{
	if(cex != GP->cex) {
		cex = GP->cex;
		fprintf(psfp, "/Helvetica findfont %.2f scalefont setfont\n", cex*10.0);
	}
	pstext(str);
	fprintf(psfp," %.2f %.2f %d tr\n", xc, yc, rot);
}

static int PS_Locator(int *x, int *y)
{
}

/* Set Graphics mode - not needed for PS */
static void PS_Mode(int mode)
{
}

/* GraphicsInteraction() for the Mac */
static void PS_Hold()
{
}

#define A4 1

PSDeviceDriver(char *file, double *parm)
{
	double xoff, yoff;
	int page = A4;
	DevInit = 0;

	filename = file;
	width = parm[0];
	height = parm[1];
	if(width < 3.0 || width > 12.0)
		width = 6.0;
	if(height < 3.0 || height > 12.o)
		height = 6.0;

	DevOpen = PIC_Open;
	DevClose = PIC_Close;
	DevResize = PIC_Resize;
	DevNewPlot = PIC_NewPlot;
	DevClip = PIC_Clip;
	DevStartPath = PIC_LStart;
	DevEndPath = PIC_LEnd;
	DevMoveTo = PIC_MoveTo;
	DevLineTo = PIC_LineTo;
	DevText = PIC_Text;
	DevRText = PIC_RText;
	DevDot = PIC_Dot;
	DevRect = PIC_Rect;
	DevLocator = PIC_Locator;
	DevMode = PIC_Mode;
	DevHold = PIC_Hold;

		/* Screen Dimensions in Pixels */

	GP->left = 0;			/* left */
	GP->right = 1000 * width; 	/* right */
	GP->bottom = 0 * yoff;		/* bottom */
	GP->top = 1000 * height;	/* top */

	if( ! PIC_Open() ) return 0;


		/* Nominal Character Sizes in Pixels */

	GP->cra[0] =  8.0 * 1000.0;
	GP->cra[1] =  9.6 * 1000.0;

		/* Character Addressing Offsets */

	GP->xCharOffset =  0.5;
	GP->yCharOffset =  0.5;

			/* Inches per Raster Unit */

	GP->ipr[0] = 1.0/1000.0;
	GP->ipr[1] = 1.0/1000.0;

	GP->canResizePlot = 0;
	GP->canChangeFont = 0;
	GP->canRotateText = 0;
	GP->canResizeText = 1;
	GP->canClip = 1;

	lty = 1;
	pageno = 1;
	cex = 1.0;

	DevInit = 1;
	return 1;
}
