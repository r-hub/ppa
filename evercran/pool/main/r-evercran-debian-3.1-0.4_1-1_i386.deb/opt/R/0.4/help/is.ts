

[1mts                       [22mTime-Series                     [1mts[0m

     ts(x, start, end, frequency)
     as.ts(x)
     is.ts(x)

[1mARGUMENTS[0m

x         the observed time-series values.

start     the time of the first observation.

end       the time of the last observation.

frequency the number of observations per unit of time.

[1mDESCRIPTION[0m

     ts  creates a time series variable.  Time series repre-
     sent data which has been sampled at  equispaced  points
     in time.

     frequency is used when the series is sampled an integer
     number of times in the unit time interval.   For  exam-
     ple,  one could use a value of 7 for frequency when the
     data are sampled daily, and the natural time period  is
     a week, or 12 when the data are sampled monthly and the
     natural time period is a year.

     start and end can either be integers  which  correspond
     to  natural  time  units,  or  vectors of two integers,
     which give a natural time unit and a  (1-based)  number
     of samples into the time unit.

     as.ts  and  is.ts  respectively  coerce  a vecor into a
     time-series and  test  whether  an  object  is  a  time
     series.

[1mSEE ALSO[0m

     time, start, end, frequency.

[1mEXAMPLES[0m

     # start date - July 1954
     x <- ts(x, start=c(1954,7), frequency=12)

