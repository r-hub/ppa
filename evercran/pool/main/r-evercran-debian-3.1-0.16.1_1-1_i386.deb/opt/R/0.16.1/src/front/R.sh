#!/bin/sh
# Shell wrapper for R executable.
# Just sets a few environment items

RHOME=R_HOME_DIR
export RHOME

if [ "$1" = "SHLIB" ]
then
	shift
	exec sh $RHOME/etc/SHLIB $*
fi

if [ "$1" = "COMPILE" ]
then
	shift
	exec sh $RHOME/etc/COMPILE $*
fi

# Default Printer Paper Size
# Choose one of the following
# R_PAPERSIZE="a4"
# R_PAPERSIZE="letter"
# R_PAPERSIZE="none"
R_PAPERSIZE=a4
export R_PAPERSIZE

# Default Print Command
# Choose one of the following
# R_PRINTCMD="lpr"
# R_PRINTCMD="lp"
R_PRINTCMD=
export R_PRINTCMD

exec $RHOME/bin/R.binary $*
