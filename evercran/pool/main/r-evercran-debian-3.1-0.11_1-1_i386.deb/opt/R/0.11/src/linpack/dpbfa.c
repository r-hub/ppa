/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DPBFA factors a double symmetric positive definite
 *     matrix stored in band form.
 *
 *     DPBFA is usually called by DPBCO, but it can be called
 *     directly with a saving in time if  rcond  is not needed.
 *
 *     On Entry
 *
 *        abd     double(lda, n)
 *                the matrix to be factored.  the columns of the upper
 *                triangle are stored in the columns of abd and the
 *                diagonals of the upper triangle are stored in the
 *                rows of abd.  see the comments below for details.
 *
 *        lda     int
 *                the leading dimension of the array  abd.
 *                lda must be >= m + 1.
 *
 *        n       int
 *                the order of the matrix  a.
 *
 *        m       int
 *                the number of diagonals above the main diagonal.
 *                0 <= m < n.
 *
 *     On Return
 *
 *        abd     an upper triangular matrix  r, stored in band
 *                form, so that  a = trans(r)*r.
 *
 *        info    int
 *                = 0  for normal return.
 *                = k  if the leading minor of order  k  is not
 *                     positive definite.
 *
 *     Band Storage
 *
 *           if  a  is a symmetric positive definite band matrix,
 *           the following program segment will set up the input.
 *
 *                   m = (band width above diagonal)
 *                   do 20 j = 1, n
 *                      i1 = imax(1, j-m)
 *                      do 10 i = i1, j
 *                         k = i-j+m+1
 *                         abd(k,j) = a(i,j)
 *                10    continue
 *                20 continue
 *
 *     LINPACK.  This version dated 08/14/78.
 *     Cleve Moler, University of New Mexico, Argonne National Lab.
 *     C Translation by Ross Ihaka.
 */

void DPBFA(double *abd, int lda, int n, int m, int *info)
{
	double s, t;
	int ik, j, jk, k, mu;

	abd -= (lda+1);

	for(j=1 ; j <= n  ; j++) {
		*info = j;
		s = 0.0;
		ik = m+1;
		jk = imax(j-m, 1);
		mu = imax(m+2-j, 1);
		if(m >= mu)
			for(k=mu ; k <= m  ; k++) {
				t = abd[k+j*lda]-DDOT(k-mu, &abd[ik+jk*lda], 1, &abd[mu+j*lda], 1);
				t = t/abd[m+1+jk*lda];
				abd[k+j*lda] = t;
				s = s+t*t;
				ik = ik-1;
				jk = jk+1;
			}
		s = abd[m+1+j*lda]-s;
		if(s <= 0.0)
			return;
		abd[m+1+j*lda] = sqrt(s);
	}
	*info = 0;
	return;
}

int dpbfa_(double *abd, int *lda, int *n, int *m, int *info)
{
	DPBFA(abd, *lda, *n, *m, info);
}
