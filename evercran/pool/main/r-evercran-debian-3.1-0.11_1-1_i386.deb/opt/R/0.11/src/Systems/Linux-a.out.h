		/* Linux a.out */

#ifndef _PLATFORM_H_
#define _PLATFORM_H_

#define Linux
#define Unix
#define PosixArith
#define DLSupport
#define Proctime
#define F77_SYMBOL(x)	x ## _
#define F77_QSYMBOL(x)	#x ## "_"

#endif
