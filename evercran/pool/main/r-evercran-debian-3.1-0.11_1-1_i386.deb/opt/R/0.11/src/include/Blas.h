#ifndef _BLAS_H_
#define _BLAS_H_

#include <Mathlib.h>

extern double DASUM(int, double*, int);
extern void DAXPY(int, double, double*, int, double*, int);
extern void  COPY(int, double*, int, double*, int);
extern double DDOT(int, double*, int, double*, int);
extern double DMACH(int);
extern double DNRM2(int, double*, int);
extern void DROT(int, double*, int, double*, int, double, double);
extern void DROTG(double*, double*, double*, double*);
extern void DSCAL(int, double, double*, int);
extern void DSWAP(int, double*, int, double*, int);
extern int IDAMAX(int, double*, int);

#endif
