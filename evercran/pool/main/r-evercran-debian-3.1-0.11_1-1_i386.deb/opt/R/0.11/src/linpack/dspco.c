/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DSPCO factors a double symmetric matrix stored in
 *     packed form by elimination with symmetric pivoting and estimates
 *     the condition of the matrix.
 *
 *     If  rcond  is not needed, DSPFA is slightly faster.
 *     To solve  a*x = b, follow DSPCO by DSPSL.
 *     To compute  inverse(a)*c, follow DSPCO by DSPSL.
 *     To compute  inverse(a), follow DSPCO by DSPDI.
 *     To compute  determinant(a), follow DSPCO by DSPDI.
 *     To compute  inertia(a), follow DSPCO by DSPDI.
 *
 *     On Entry
 *
 *        ap      double (n*(n+1)/2)
 *                the packed form of a symmetric matrix  a.  the
 *                columns of the upper triangle are stored sequentially
 *                in a one-dimensional array of length  n*(n+1)/2.
 *                see comments below for details.
 *
 *        n       int
 *                the order of the matrix  a.
 *
 *     Output
 *
 *        ap      a block diagonal matrix and the multipliers which
 *                were used to obtain it stored in packed form.
 *                the factorization can be written  a = u*d*trans(u)
 *                where  u  is a product of permutation and unit
 *                upper triangular matrices, trans(u) is the
 *                transpose of  u, and  d  is block diagonal
 *                with 1 by 1 and 2 by 2 blocks.
 *
 *        kpvt    int(n)
 *                an int vector of pivot indices.
 *
 *        rcond   double
 *                an estimate of the reciprocal condition of  a.
 *                for the system  a*x = b, relative perturbations
 *                in  a  and  b  of size  epsilon  may cause
 *                relative perturbations in  x  of size  epsilon/rcond.
 *                if  rcond  is so small that the int expression
 *                           1.0 + rcond == 1.0
 *                is true, then  a  may be singular to working
 *                precision.  in particular,  rcond  is zero  if
 *                exact singularity is detected or the estimate
 *                underflows.
 *
 *        z       double(n)
 *                a work vector whose contents are usually unimportant.
 *                if  a  is close to a singular matrix, then  z  is
 *                an approximate null vector in the sense that
 *                norm(a*z) = rcond*norm(a)*norm(z).
 *
 *     Packed Storage
 *
 *          The following program segment will pack the upper
 *          triangle of a symmetric matrix.
 *
 *                k = 0
 *                do 20 j = 1, n
 *                   do 10 i = 1, j
 *                      k = k + 1
 *                      ap(k) = a(i,j)
 *             10    continue
 *             20 continue
 *
 *     LINPACK. This version dated 08/14/78.
 *     Cleve Moler, University of New Mexico, Argonne National Lab.
 *     C Translation by Ross Ihaka.
 */

#define ap(i)	ap[i]
#define kpvt(i)	kpvt[i]
#define z(i)	z[i]

void DSPCO(double *ap, int n, int *kpvt, double *rcond, double *z)
{
	double ak, akm1, bk, bkm1, denom, ek, t;
	double anorm, s, ynorm;
	int i, ij, ik, ikm1, ikp1, info, j, jm1, j1;
	int k, kk, km1k, km1km1, kp, kps, ks;

	ap -= 1;
	kpvt -= 1;
	z -= 1;

	/* find norm of a using only upper half */

	j1 = 1;
	for(j=1 ; j <= n  ; j++) {
		z(j) = DASUM(j, &ap(j1), 1);
		ij = j1;
		j1 = j1+j;
		jm1 = j-1;
		if(jm1 >= 1)
			for(i=1 ; i <= jm1  ; i++) {
				z(i) = z(i)+fabs(ap(ij));
				ij = ij+1;
			}
	}
	anorm = 0.0;
	for(j=1 ; j <= n ; j++) 
		anorm = fmax(anorm, z(j));

	/* factor */

	DSPFA(&ap(1), n, &kpvt(1), &info);

	/* rcond = 1/(norm(a)*(estimate of norm(inverse(a)))). */
	/* estimate = norm(z)/norm(y) where  a*z = y  and  a*y = e. */
	/* the components of  e  are chosen to cause maximum local */
	/* growth in the elements of w  where  u*d*w = e. */
	/* the vectors are frequently rescaled to avoid overflow. */

	/* solve u*d*w = e */

	ek = 1.0;
	for(j=1 ; j <= n ; j++) 
		z(j) = 0.0;
	k = n;
	ik = (n*(n-1))/2;
	while (k != 0) {
		kk = ik+k;
		ikm1 = ik-(k-1);
		ks = 1;
		if(kpvt(k) < 0)
			ks = 2;
		kp = abs(kpvt(k));
		kps = k+1-ks;
		if(kp != kps) {
			t = z(kps);
			z(kps) = z(kp);
			z(kp) = t;
		}
		if(z(k) != 0.0)
			ek = fsign(ek, z(k));
		z(k) = z(k)+ek;
		DAXPY(k-ks, z(k), &ap(ik+1), 1, &z(1), 1);
		if(ks != 1) {
			if(z(k-1) != 0.0)
				ek = fsign(ek, z(k-1));
			z(k-1) = z(k-1)+ek;
			DAXPY(k-ks, z(k-1), &ap(ikm1+1), 1, &z(1), 1);
		}
		if(ks != 2) {
			if(fabs(z(k)) > fabs(ap(kk))) {
				s = fabs(ap(kk))/fabs(z(k));
				DSCAL(n, s, &z(1), 1);
				ek = s*ek;
			}
			if(ap(kk) != 0.0)
				z(k) = z(k)/ap(kk);
			if(ap(kk) == 0.0)
				z(k) = 1.0;
		}
		else {
			km1k = ik+k-1;
			km1km1 = ikm1+k-1;
			ak = ap(kk)/ap(km1k);
			akm1 = ap(km1km1)/ap(km1k);
			bk = z(k)/ap(km1k);
			bkm1 = z(k-1)/ap(km1k);
			denom = ak*akm1-1.0;
			z(k) = (akm1*bk-bkm1)/denom;
			z(k-1) = (ak*bkm1-bk)/denom;
		}
		k = k-ks;
		ik = ik-k;
		if(ks == 2)
			ik = ik-(k+1);
	}
	s = 1.0/DASUM(n, &z(1), 1);
	DSCAL(n, s, &z(1), 1);

	/* solve trans(u)*y = w */

	k = 1;
	ik = 0;
	while (k <= n) {
		ks = 1;
		if(kpvt(k) < 0)
			ks = 2;
		if(k != 1) {
			z(k) = z(k)+DDOT(k-1, &ap(ik+1), 1, &z(1), 1);
			ikp1 = ik+k;
			if(ks == 2)
				z(k+1) = z(k+1)+DDOT(k-1, &ap(ikp1+1), 1, &z(1), 1);
			kp = abs(kpvt(k));
			if(kp != k) {
				t = z(k);
				z(k) = z(kp);
				z(kp) = t;
			}
		}
		ik = ik+k;
		if(ks == 2)
			ik = ik+(k+1);
		k = k+ks;
	}
	s = 1.0/DASUM(n, &z(1), 1);
	DSCAL(n, s, &z(1), 1);

	ynorm = 1.0;

	/* solve u*d*v = y */

	k = n;
	ik = n*(n-1)/2;
	while (k != 0) {
		kk = ik+k;
		ikm1 = ik-(k-1);
		ks = 1;
		if(kpvt(k) < 0)
			ks = 2;
		if(k != ks) {
			kp = abs(kpvt(k));
			kps = k+1-ks;
			if(kp != kps) {
				t = z(kps);
				z(kps) = z(kp);
				z(kp) = t;
			}
			DAXPY(k-ks, z(k), &ap(ik+1), 1, &z(1), 1);
			if(ks == 2)
				DAXPY(k-ks, z(k-1), &ap(ikm1+1), 1, &z(1), 1);
		}
		if(ks != 2) {
			if(fabs(z(k)) > fabs(ap(kk))) {
				s = fabs(ap(kk))/fabs(z(k));
				DSCAL(n, s, &z(1), 1);
				ynorm = s*ynorm;
			}
			if(ap(kk) != 0.0)
				z(k) = z(k)/ap(kk);
			if(ap(kk) == 0.0)
				z(k) = 1.0;
		}
		else {
			km1k = ik+k-1;
			km1km1 = ikm1+k-1;
			ak = ap(kk)/ap(km1k);
			akm1 = ap(km1km1)/ap(km1k);
			bk = z(k)/ap(km1k);
			bkm1 = z(k-1)/ap(km1k);
			denom = ak*akm1-1.0;
			z(k) = (akm1*bk-bkm1)/denom;
			z(k-1) = (ak*bkm1-bk)/denom;
		}
		k = k-ks;
		ik = ik-k;
		if(ks == 2)
			ik = ik-(k+1);
	}
	s = 1.0/DASUM(n, &z(1), 1);
	DSCAL(n, s, &z(1), 1);
	ynorm = s*ynorm;

	/* solve trans(u)*z = v */

	k = 1;
	ik = 0;
	while (k <= n) {
		ks = 1;
		if(kpvt(k) < 0)
			ks = 2;
		if(k != 1) {
			z(k) = z(k)+DDOT(k-1, &ap(ik+1), 1, &z(1), 1);
			ikp1 = ik+k;
			if(ks == 2)
				z(k+1) = z(k+1)+DDOT(k-1, &ap(ikp1+1), 1, &z(1), 1);
			kp = abs(kpvt(k));
			if(kp != k) {
				t = z(k);
				z(k) = z(kp);
				z(kp) = t;
			}
		}
		ik = ik+k;
		if(ks == 2)
			ik = ik+(k+1);
		k = k+ks;
	}

	/* make znorm = 1.0 */

	s = 1.0/DASUM(n, &z(1), 1);
	DSCAL(n, s, &z(1), 1);
	ynorm = s*ynorm;

	if(anorm != 0.0)
		*rcond = ynorm/anorm;
	else
		*rcond = 0.0;
	return;
}

int dspco_(double *ap, int *n, int *kpvt, double *rcond, double *z)
{
	DSPCO(ap, *n, kpvt, rcond, z);
}
