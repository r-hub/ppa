/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DQRSL applies the output of DQRDC to compute coordinate
 *     transformations, projections, and least squares solutions.
 *     For k <= min(n,p), let xk be the matrix
 *
 *            xk = (x(jpvt(1)),x(jpvt(2)),...,x(jpvt(k)))
 *
 *     formed from columnns jpvt(1),...,jpvt(k) of the original
 *     n x p matrix x that was input to DQRDC (if no pivoting was
 *     done, xk consists of the first k columns of x in their
 *     original order).  DQRDC produces a factored orthogonal matrix q
 *     and an upper triangular matrix r such that
 *
 *              xk = q * (r)
 *                       (0)
 *
 *     this information is contained in coded form in the arrays
 *     x and qraux.
 *
 *     On Entry
 *
 *        x      double(ldx,p).
 *               x contains the output of DQRDC.
 *
 *        ldx    int.
 *               ldx is the leading dimension of the array x.
 *
 *        n      int.
 *               n is the number of rows of the matrix xk.  it must
 *               have the same value as n in DQRDC.
 *
 *        k      int.
 *               k is the number of columns of the matrix xk.  k
 *               must nnot be greater than min(n,p), where p is the
 *               same as in the calling sequence to DQRDC.
 *
 *        qraux  double(p).
 *               qraux contains the auxiliary output from DQRDC.
 *
 *        y      double(n)
 *               y contains an n-vector that is to be manipulated
 *               by DQRSL.
 *
 *        job    int.
 *               job specifies what is to be computed.  job has
 *               the decimal expansion abcde, with the following
 *               meaning.
 *
 *                    if a!=0, compute qy.
 *                    if b,c,d, or e != 0, compute qty.
 *                    if c!=0, compute b.
 *                    if d!=0, compute rsd.
 *                    if e!=0, compute xb.
 *
 *               note that a request to compute b, rsd, or xb
 *               automatically triggers the computation of qty, for
 *               which an array must be provided in the calling
 *               sequence.
 *
 *     On Return
 *
 *        qy     double(n).
 *               qy conntains q*y, if its computation has been
 *               requested.
 *
 *        qty    double(n).
 *               qty contains trans(q)*y, if its computation has
 *               been requested.  here trans(q) is the
 *               transpose of the matrix q.
 *
 *        b      double(k)
 *               b contains the solution of the least squares problem
 *
 *                    minimize norm2(y - xk*b),
 *
 *               if its computation has been requested.  (note that
 *               if pivoting was requested in DQRDC, the j-th
 *               component of b will be associated with column jpvt(j)
 *               of the original matrix x that was input into DQRDC.)
 *
 *        rsd    double(n).
 *               rsd contains the least squares residual y - xk*b,
 *               if its computation has been requested.  rsd is
 *               also the orthogonal projection of y onto the
 *               orthogonal complement of the column space of xk.
 *
 *        xb     double(n).
 *               xb contains the least squares approximation xk*b,
 *               if its computation has been requested.  xb is also
 *               the orthogonal projection of y onto the column space
 *               of x.
 *
 *        info   int.
 *               info is zero unless the computation of b has
 *               been requested and r is exactly singular.  in
 *               this case, info is the index of the first zero
 *               diagonal element of r and b is left unaltered.
 *
 *     The parameters qy, qty, b, rsd, and xb are not referenced
 *     if their computation is not requested and in this case
 *     can be replaced by dummy variables in the calling program.
 *     To save storage, the user may in some cases use the same
 *     array for different parameters in the calling sequence.  A
 *     frequently occuring example is when one wishes to compute
 *     any of b, rsd, or xb and does not need y or qty.  In this
 *     case one may identify y, qty, and one of b, rsd, or xb, while
 *     providing separate arrays for anything else that is to be
 *     computed.  Thus the calling sequence
 *
 *          DQRSL(x,ldx,n,k,qraux,y,dum,y,b,y,dum,110,info)
 *
 *     will result in the computation of b and rsd, with rsd
 *     overwriting y.  More generally, each item in the following
 *     list contains groups of permissible identifications for
 *     a single callinng sequence.
 *
 *          1. (y,qty,b) (rsd) (xb) (qy)
 *
 *          2. (y,qty,rsd) (b) (xb) (qy)
 *
 *          3. (y,qty,xb) (b) (rsd) (qy)
 *
 *          4. (y,qy) (qty,b) (rsd) (xb)
 *
 *          5. (y,qy) (qty,rsd) (b) (xb)
 *
 *          6. (y,qy) (qty,xb) (b) (rsd)
 *
 *     In any group the value returned in the array allocated to
 *     the group corresponds to the last member of the group.
 *
 *     LINPACK. This version dated 08/14/78.
 *     G.W. Stewart, University of Maryland, Argonne National Lab.
 *     C Translation by Ross Ihaka.
 */

#define x(i,j)		x[i+(j)*ldx]
#define qraux(i)	qraux[i]
#define y(i)		y[i]
#define qy(i)		qy[i]
#define qty(i)		qty[i]
#define b(i)		b[i]
#define rsd(i)		rsd[i]
#define xb(i)		xb[i]

void DQRSL(double *x, int ldx, int n, int k, double *qraux, double *y, double *qy, double *qty, double *b, double *rsd, double *xb, int job, int *info)
{
	int i, j, jj, ju, kp1;
	double t, temp;
	int cb, cqy, cqty, cr, cxb;

	x -= (ldx+1);
	qraux -= 1;
	y -= 1;
	qy -= 1;
	qty -= 1;
	b -= 1;
	rsd -= 1;
	xb -= 1;

	/* set info flag. */

	*info = 0;

	/* determine what is to be computed. */

	cqy = job/10000 != 0;
	cqty = (job % 10000) != 0;
	cb = (job % 1000)/100 != 0;
	cr = (job % 100)/10 != 0;
	cxb = (job % 10) != 0;
	ju = imin(k, n-1);

	/* special action when n=1. */

	if(ju == 0) {
		if(cqy)
			qy(1) = y(1);
		if(cqty)
			qty(1) = y(1);
		if(cxb)
			xb(1) = y(1);
		if(cb) {
			if(x(1, 1) != 0.0)
				b(1) = y(1)/x(1, 1);
			else
				*info = 1;
		}
		if(cr)
			rsd(1) = 0.0;
	}
	else {

		/* set up to compute qy or qty. */

		if(cqy)
			DCOPY(n, &y(1), 1, &qy(1), 1);
		if(cqty)
			DCOPY(n, &y(1), 1, &qty(1), 1);
		if(cqy)

			/* compute qy. */

			for(jj=1 ; jj <= ju  ; jj++) {
				j = ju-jj+1;
				if(qraux(j) != 0.0) {
					temp = x(j, j);
					x(j, j) = qraux(j);
					t = -DDOT(n-j+1, &x(j, j), 1, &qy(j), 1)/x(j, j);
					DAXPY(n-j+1, t, &x(j, j), 1, &qy(j), 1);
					x(j, j) = temp;
				}
			}
		if(cqty)

			/* compute trans(q)*y. */

			for(j=1 ; j <= ju ; j++) 
				if(qraux(j) != 0.0) {
					temp = x(j, j);
					x(j, j) = qraux(j);
					t = -DDOT(n-j+1, &x(j, j), 1, &qty(j), 1)/x(j, j);
					DAXPY(n-j+1, t, &x(j, j), 1, &qty(j), 1);
					x(j, j) = temp;
				}

			/* set up to compute b, rsd, or xb. */

		if(cb)
			DCOPY(k, &qty(1), 1, &b(1), 1);
		kp1 = k+1;
		if(cxb)
			DCOPY(k, &qty(1), 1, &xb(1), 1);
		if(cr && k < n)
			DCOPY(n-k, &qty(kp1), 1, &rsd(kp1), 1);
		if(cxb && kp1 <= n)
			for(i=kp1 ; i <= n ; i++) 
				xb(i) = 0.0;
		if(cr)
			for(i=1 ; i <= k ; i++) 
				rsd(i) = 0.0;
		if(cb) {

			/* compute b. */

			for(jj=1 ; jj <= k  ; jj++) {
				j = k-jj+1;
				if(x(j, j) == 0.0) {
					*info = j;
					goto L20;
				}
				b(j) = b(j)/x(j, j);
				if(j != 1) {
					t = -b(j);
					DAXPY(j-1, t, &x(1, j), 1, &b(1), 1);
				}
			}
		}
	L20:	if(cr || cxb)

			/* compute rsd or xb as required. */

			for(jj=1 ; jj <= ju  ; jj++) {
				j = ju-jj+1;
				if(qraux(j) != 0.0) {
					temp = x(j, j);
					x(j, j) = qraux(j);
					if(cr) {
						t = -DDOT(n-j+1, &x(j, j), 1, &rsd(j), 1)/x(j, j);
						DAXPY(n-j+1, t, &x(j, j), 1, &rsd(j), 1);
					}
					if(cxb) {
						t = -DDOT(n-j+1, &x(j, j), 1, &xb(j), 1)/x(j, j);
						DAXPY(n-j+1, t, &x(j, j), 1, &xb(j), 1);
					}
					x(j, j) = temp;
				}
			}
	}
	return;
}

int dqrsl_(double *x, int *ldx, int *n, int *k, double *qraux, double *y, double *qy, double *qty, double *b, double *rsd, double *xb, int *job, int *info)
{
	DQRSL(x, *ldx, *n, *k, qraux, y, qy, qty, b, rsd, xb, *job, info);
}
