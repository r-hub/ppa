		/* Linux ELF */

#ifndef _PLATFORM_H_
#define _PLATFORM_H_

/* Note definition of DLNoSymUnderscore for ELF */

#define Linux
#define Unix
#define PosixArith
#define DLSupport
#define DLNoSymUnderscore
#define Proctime
#define F77_SYMBOL(x)	x ## _
#define F77_QSYMBOL(x)	#x ## "_"

#endif
