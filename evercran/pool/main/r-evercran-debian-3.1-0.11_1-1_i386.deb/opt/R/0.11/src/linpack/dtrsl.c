/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DTRSL solves systems of the form
 *
 *                   t * x = b
 *     or
 *                   trans(t) * x = b
 *
 *     where t is a triangular matrix of order n. here trans(t)
 *     denotes the transpose of the matrix t.
 *
 *     On Entry
 *
 *         t         double(ldt,n)
 *                   t contains the matrix of the system. the zero
 *                   elements of the matrix are not referenced, and
 *                   the corresponding elements of the array can be
 *                   used to store other information.
 *
 *         ldt       int
 *                   ldt is the leading dimension of the array t.
 *
 *         n         int
 *                   n is the order of the system.
 *
 *         b         double(n).
 *                   b contains the right hand side of the system.
 *
 *         job       int
 *                   job specifies what kind of system is to be solved.
 *                   if job is
 *
 *                        00   solve t*x=b, t lower triangular,
 *                        01   solve t*x=b, t upper triangular,
 *                        10   solve trans(t)*x=b, t lower triangular,
 *                        11   solve trans(t)*x=b, t upper triangular.
 *
 *     On Return
 *
 *         b         b contains the solution, if info .eq. 0.
 *                   otherwise b is unaltered.
 *
 *         info      int*
 *                   info contains zero if the system is nonsingular.
 *                   otherwise info contains the index of
 *                   the first zero diagonal element of t.
 *
 *     LINPACK. This version dated 08/14/78 .
 *     G. W. Stewart, University of Maryland, Argonne National Lab.
 *     C Translation by Ross Ihaka.
 */

void DTRSL(double *t, int ldt, int n, double *b, int job, int *info)
{
	double temp;
	int kase, j, jj;

	t -= (ldt+1);
	b -= 1;

	/* check for zero diagonal elements. */

	for(j=1 ; j <= n ; j++) 
		if(t[j+j*ldt] == 0.0)
			return;
	info = 0;

	/* determine the task and go to it. */

	kase = 1;
	if(job%10 != 0)
		kase = 2;
	if((job%100)/10 != 0)
		kase = kase+2;
	switch(kase) {;
		case 1:
			b[1] = b[1]/t[1+1*ldt];
			if(n >= 2)
				for(j=2 ; j <= n  ; j++) {
					temp = -b[j-1];
					DAXPY(n-j+1, temp, &t[j+(j-1)*ldt], 1, &b[j], 1);
					b[j] = b[j]/t[j+j*ldt];
				}
			break;
		case 2:
			b[n] = b[n]/t[n+n*ldt];
			if(n >= 2)
				for(jj=2 ; jj <= n  ; jj++) {
					j = n-jj+1;
					temp = -b[j+1];
					DAXPY(j, temp, &t[1+(j+1)*ldt], 1, &b[1], 1);
					b[j] = b[j]/t[j+j*ldt];
				}
			break;
		case 3:
			b[n] = b[n]/t[n+n*ldt];
			if(n >= 2)
				for(jj=2 ; jj <= n  ; jj++) {
					j = n-jj+1;
					b[j] = b[j]-DDOT(jj-1, &t[j+1+j*ldt], 1, &b[j+1], 1);
					b[j] = b[j]/t[j+j*ldt];
				}
			break;
		case 4:
			b[1] = b[1]/t[1+1*ldt];
			if(n >= 2)
				for(j=2 ; j <= n  ; j++) {
					b[j] = b[j]-DDOT(j-1, &t[1+j*ldt], 1, &b[1], 1);
					b[j] = b[j]/t[j+j*ldt];
				}
	}
	return;
}

int dtrsl_(double *t, int *ldt, int *n, double *b, int *job, int *info)
{
	DTRSL(t, *ldt, *n, b, *job, info);
}
