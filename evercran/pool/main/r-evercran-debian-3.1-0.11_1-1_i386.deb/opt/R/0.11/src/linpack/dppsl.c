/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DPPSL solves the double symmetric positive definite
 *     system a * x = b
 *     using the factors computed by DPPCO or DPPFA.
 *
 *     On Entry
 *
 *        ap      double(n*(n+1)/2)
 *                the output from dppco or dppfa.
 *
 *        n       int
 *                the order of the matrix  a.
 *
 *        b       double(n)
 *                the right hand side vector.
 *
 *     On Return
 *
 *        b       the solution vector  x.
 *
 *     Error Condition
 *
 *        A division by zero will occur if the input factor contains
 *        a zero on the diagonal.  Technically this indicates
 *        singularity but it is usually caused by improper subroutine
 *        arguments.  It will not occur if the subroutines are called
 *        correctly and  info .eq. 0.
 *
 *     To compute  inverse(a) * c  where  c  is a matrix
 *     with  p  columns
 *           DPPCO(ap,n,rcond,z,info)
 *           if (rcond is too small .or. info .ne. 0) go to ...
 *           do 10 j = 1, p
 *              DPPSL(ap,n,c(1,j))
 *        10 continue
 *
 *     LINPACK.  This version dated 08/14/78.
 *     Cleve Moler, University of New Mexico, Argonne National Lab.
 *     C Translation by Ross Ihaka.
 */

void DPPSL(double *ap, int n, double *b)
{
	int k, kb, kk;
	double t;

	ap -= 1;
	b -= 1;

	kk = 0;
	for(k=1 ; k <= n  ; k++) {
		t = DDOT(k-1, &ap[kk+1], 1, &b[1], 1);
		kk = kk+k;
		b[k] = (b[k]-t)/ap[kk];
	}
	for(kb=1 ; kb <= n  ; kb++) {
		k = n+1-kb;
		b[k] = b[k]/ap[kk];
		kk = kk-k;
		t = -b[k];
		DAXPY(k-1, t, &ap[kk+1], 1, &b[1], 1);
	}
	return;
}

int dppsl_(double *ap, int *n, double *b)
{
	DPPSL(ap, *n, b);
}
