/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DGEDI computes the determinant and inverse of a matrix
 *     using the factors computed by DGECO or DGEFA.
 *
 *     On Entry
 *
 *        a       double(lda, n)
 *                the output from dgeco or dgefa.
 *
 *        lda     int
 *                the leading dimension of the array  a .
 *
 *        n       int
 *                the order of the matrix  a .
 *
 *        ipvt    int(n)
 *                the pivot vector from dgeco or dgefa.
 *
 *        work    double(n)
 *                work vector.  contents destroyed.
 *
 *        job     int
 *                = 11   both determinant and inverse.
 *                = 01   inverse only.
 *                = 10   determinant only.
 *
 *     On Return
 *
 *        a       inverse of original matrix if requested.
 *                otherwise unchanged.
 *
 *        det     double(2)
 *                determinant of original matrix if requested.
 *                otherwise not referenced.
 *                determinant = det(1) * 10.0**det(2)
 *                with  1.0 <= fabs(det(1)) < 10.0
 *                or  det(1) == 0.0 .
 *
 *     Error Condition
 *
 *        A division by zero will occur if the input factor contains
 *        a zero on the diagonal and the inverse is requested.
 *        It will not occur if the subroutines are called correctly
 *        and if DGECO has set rcond > 0.0 or DGEFA has set
 *        info == 0.
 *
 *     LINPACK. this version dated 08/14/78 .
 *     Cleve Moler, University of New Mexico, Argonne National Lab.
 *     C translation by Ross Ihaka.
 */

void DGEDI(double *a, int lda, int n, int *ipvt, double *det, double *work, int job)
{
	double t, ten;
	int i, j, k, kb, kp1, l, nm1;

	a -= (lda+1);
	ipvt -= 1;
	det -= 1;
	work -= 1;

	/* compute determinant */

	if(job/10 != 0) {
		det[1] = 1.0;
		det[2] = 0.0;
		ten = 10.0;
		for(i=1 ; i <= n  ; i++) {
			if(ipvt[i] != i)
				det[1] = -det[1];
			det[1] = a[i+i*lda]*det[1];
			if(det[1] == 0.0)
				break;
			while (fabs(det[1]) < 1.0) {
				det[1] = ten*det[1];
				det[2] = det[2]-1.0;
			}
			while (fabs(det[1]) >= ten) {
				det[1] = det[1]/ten;
				det[2] = det[2]+1.0;
			}
		}
	}

	/* compute inverse(u) */

	if(job%10 != 0) {
		for(k=1 ; k <= n  ; k++) {
			a[k+k*lda] = 1.0/a[k+k*lda];
			t = -a[k+k*lda];
			DSCAL(k-1, t, &a[1+k*lda], 1);
			kp1 = k+1;
			if(n >= kp1)
				for(j=kp1 ; j <= n  ; j++) {
					t = a[k+j*lda];
					a[k+j*lda] = 0.0;
					DAXPY(k, t, &a[1+k*lda], 1, &a[1+j*lda], 1);
				}
		}

		/* form inverse(u)*inverse(l) */

		nm1 = n-1;
		if(nm1 >= 1)
			for(kb=1 ; kb <= nm1  ; kb++) {
				k = n-kb;
				kp1 = k+1;
				for(i=kp1 ; i <= n  ; i++) {
					work[i] = a[i+k*lda];
					a[i+k*lda] = 0.0;
				}
				for(j=kp1 ; j <= n  ; j++) {
					t = work[j];
					DAXPY(n, t, &a[1+j*lda], 1, &a[1+k*lda], 1);
				}
				l = ipvt[k];
				if(l != k)
					DSWAP(n, &a[1+k*lda], 1, &a[1+l*lda], 1);
			}
	}
	return;
}

int dgedi_(double *a, int *lda, int *n, int *ipvt, double *det, double *work, int *job)
{
	DGEDI(a, *lda, *n, ipvt, det, work, *job);
}
