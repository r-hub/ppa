/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995, 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"
static SEXP cbind(SEXP, SEXPTYPE);
static SEXP rbind(SEXP, SEXPTYPE);
extern SEXP do_unlist(SEXP, SEXP, SEXP, SEXP);

	/* NOTE ON FACTORS */
	/* For us, c(factor1, factor2) is legal only if factor1 */
	/* and factor2 are either both ordered or both unordered */
	/* and have the same levels.  Any attempt at combining */
	/* factors with anything else is stamped on. */

char *funs[] = {"c", "cbind", "rbind" };
	
static void badfactors(int whichop)
{
	error("non-combinable factors in \"%s\"\n", funs[whichop]);
}

static void badtypes(int whichop)
{
	error("non-combinable data types in \"%s\"\n", funs[whichop]);
}

static void nonconform(whichop)
{
	error("non-conformable arguments in \"%s\"\n", funs[whichop]);
}

	/* This code establishes the return type for */
	/* the functions  unlist, c, cbind, and rbind */
	/* and also determines whether the returned */
	/* object is to have a names attribute. */

static int HasNames(SEXP x)
{
	if(isVector(x) && !isNull(getAttrib(x, R_NamesSymbol)))
		return 1;
	else if(isList(x)) {
		while(!isNull(x)) {
			if(!isNull(TAG(x))) return 1;
			x = CDR(x);
		}
	}
	return 0;
}

static int ans_flags;
static SEXP ans_ptr;
static int ans_length;
static SEXP ans_names;
static int ans_nnames;

static void answertype(SEXP x, int recurse, int usenames)
{
	SEXP t;
	ans_flags = 0;
	ans_length = 0;
	ans_nnames = 0;
	for (t=x ; t != R_NilValue; t = CDR(t)) {
		if (usenames && !ans_nnames) {
			if (!isNull(TAG(t))) ans_nnames = 1;
			else ans_nnames = HasNames(CAR(t));
		}
		if (!isNull(CAR(t))) {
			switch (TYPEOF(CAR(t))) {
			case NILSXP:
				break;
			case LGLSXP:
				ans_flags |= 1;
				ans_length += LENGTH(CAR(t));
				break;
			case FACTSXP:
				ans_flags |= 2;
				ans_length += LENGTH(CAR(t));
				break;
			case ORDSXP:
				ans_flags |= 4;
				ans_length += LENGTH(CAR(t));
				break;
			case INTSXP:
				ans_flags |= 8;
				ans_length += LENGTH(CAR(t));
				break;
			case REALSXP:
				ans_flags |= 16;
				ans_length += LENGTH(CAR(t));
				break;
			case STRSXP:
				ans_flags |= 32;
				ans_length += LENGTH(CAR(t));
				break;
			case LISTSXP:
				if(recurse) answertype(CAR(t), recurse, usenames);
				else {
					ans_flags |= 64;
					ans_length += length(CAR(t));
				}
				break;
			default:
				ans_flags |= 64;
				ans_length += 1;
				break;
			}
		}
	}
}

	/* The following blocks of code are used to coerce */
	/* arguments to the appropriate type for inclusion */
	/* in the returned value. */

static void listanswer(SEXP x, int recurse)
{
	int i;

	switch(TYPEOF(x)) {
	case NILSXP:
		break;
	case LGLSXP:
	case INTSXP:
		for(i=0 ; i<LENGTH(x) ; i++) {
			CAR(ans_ptr) = allocVector(TYPEOF(x), 1);
			INTEGER(CAR(ans_ptr))[0] = INTEGER(x)[i];
			ans_ptr = CDR(ans_ptr);
		}
		break;
	case FACTSXP:
	case ORDSXP:
		for(i=0 ; i<LENGTH(x) ; i++) {
			CAR(ans_ptr) = allocVector(TYPEOF(x), 1);
			LEVELS(CAR(ans_ptr)) = LEVELS(x);
			setAttrib(CAR(ans_ptr), R_LevelsSymbol, getAttrib(x, R_LevelsSymbol));
			INTEGER(CAR(ans_ptr))[0] = INTEGER(x)[i];
			ans_ptr = CDR(ans_ptr);
		}
		break;
	case REALSXP:
		for(i=0 ; i<LENGTH(x) ; i++) {
			CAR(ans_ptr) = allocVector(REALSXP, 1);
			REAL(CAR(ans_ptr))[0] = REAL(x)[i];
			ans_ptr = CDR(ans_ptr);
		}
		break;
	case STRSXP:
		for(i=0 ; i<LENGTH(x) ; i++) {
			CAR(ans_ptr) = allocVector(STRSXP, 1);
			STRING(CAR(ans_ptr))[0] = STRING(x)[i];
			ans_ptr = CDR(ans_ptr);
		}
		break;
	case LISTSXP:
		if(recurse) {
			while(x != R_NilValue) {
				listanswer(CAR(x), recurse);
				x = CDR(x);
			}
		}
		else {
			while(x != R_NilValue) {
				CAR(ans_ptr) = duplicate(CAR(x));
				TAG(ans_ptr) = TAG(x);
				ans_ptr = CDR(ans_ptr);
				x = CDR(x);
			}
		}
		break;
	default:
		CAR(ans_ptr) = duplicate(x);
		ans_ptr = CDR(ans_ptr);
		break;
	}
}

static void stringanswer(SEXP x)
{
	int i, nx;

	switch(TYPEOF(x)) {
	case NILSXP:
		break;
	case LISTSXP:
		while(x != R_NilValue) {
			stringanswer(CAR(x));
			x = CDR(x);
		}
		break;
	default:
		PROTECT(x = coerceVector(x, STRSXP));
		nx = LENGTH(x);  
		for (i = 0; i < nx; i++)
			STRING(ans_ptr)[ans_length++] = STRING(x)[i];
		UNPROTECT(1);
		break;
	}
}

static void integeranswer(SEXP x)
{
	int i, nx;

	switch(TYPEOF(x)) {
	case NILSXP:
		break;
	case LISTSXP:
		while(x != R_NilValue) {
			integeranswer(CAR(x));
			x = CDR(x);
		}
		break;
	default:
		nx = LENGTH(x);  
		for (i = 0; i < nx; i++)
			INTEGER(ans_ptr)[ans_length++] = INTEGER(x)[i];
		break;
	}
}

static void realanswer(SEXP x)
{
	int i, nx, xi;

	switch(TYPEOF(x)) {
	case NILSXP:
		break;
	case LISTSXP:
		while(x != R_NilValue) {
			realanswer(CAR(x));
			x = CDR(x);
		}
		break;
	case REALSXP:
		nx = LENGTH(x);  
		for (i = 0; i < nx; i++)
			REAL(ans_ptr)[ans_length++] = REAL(x)[i];
		break;
	default:
		nx = LENGTH(x);  
		for (i = 0; i < nx; i++) {
			xi = INTEGER(x)[i];
			if(xi == NA_INTEGER) REAL(ans_ptr)[ans_length++] = NA_REAL;
			else REAL(ans_ptr)[ans_length++] = xi;
		}
		break;
	}
}

static SEXP TagName(SEXP tag, int i)
{
	SEXP ans;
	if(i) {
		ans = allocString(strlen(CHAR(PRINTNAME(tag)))+IndexWidth(i));
		sprintf(CHAR(ans), "%s%d", CHAR(PRINTNAME(tag)), i);
	}
	else {
		ans = allocString(strlen(CHAR(PRINTNAME(tag))));
		strcpy(CHAR(ans), CHAR(PRINTNAME(tag)));
	}
	return ans;
}

static void ExtractNames(SEXP args, int recurse)
{
	SEXP blank, s;
	int i;

	PROTECT(blank=mkChar(""));

	while(args != R_NilValue) {
		if(isNull(CAR(args))) {
		}
		else if(isVector(CAR(args))) {
			if(!isNull(TAG(args))) {
				switch(length(CAR(args))) {
				case 0:
					break;
				case 1:
					STRING(ans_names)[ans_nnames++] = TagName(TAG(args), 0);
					break;
				default:
					for(i=0 ; i<length(CAR(args)) ; i++)
						STRING(ans_names)[ans_nnames++] = TagName(TAG(args), i+1);
				}
			}
			else {
				if(isNull(s = getAttrib(CAR(args), R_NamesSymbol))) {
					for(i=0 ; i<length(CAR(args)) ; i++)
						STRING(ans_names)[ans_nnames++] = blank;
				}
				else {
					for(i=0 ; i<length(CAR(args)) ; i++)
						STRING(ans_names)[ans_nnames++] = STRING(s)[i];
				}
			}
		}
		else if(isList(CAR(args))) {
			if(recurse) {
				ExtractNames(CAR(args), recurse);
			}
			else {
				s = CAR(args);
				while(s != R_NilValue) {
					if(!isNull(TAG(s)))
						STRING(ans_names)[ans_nnames++] = TAG(s);
					else
						STRING(ans_names)[ans_nnames++] = blank;
					s = CDR(s);
				}
			}
		}
		else {
			if(!isNull(TAG(args)))
				STRING(ans_names)[ans_nnames++] = TAG(args);
			else
				STRING(ans_names)[ans_nnames++] = blank;
		}
		args = CDR(args);
	}
	if(ans_nnames != ans_length) {
		printf("INTERNAL ERROR: ans_nnames = %d    ans_length = %d\n", ans_nnames, ans_length);
		error("incorrect names vector length\n");
	}
	UNPROTECT(1);
}

	/* do_c provides the internal code for both "c" and "unlist". */
	/* The only real difference is the value of the "recursive" */
	/* argument which is FALSE by default for "c" and TRUE by */
	/* default for "unlist". */

SEXP do_c(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP ans, t;
	int i, k, mode, n, recurse, usenames;

	checkArity(op, args);

	recurse = asLogical(CADR(args));
	if(recurse == NA_INTEGER) recurse = 0;

	usenames = asLogical(CADDR(args));
	if(usenames == NA_INTEGER) usenames = 1;

	args = CAR(args);

	answertype(args, recurse, usenames);

		/* If there was a non-vector argument encountered */
		/* (perhaps a list if recursive=F) then we must */
		/* return a list.  Otherwise, if there was a character */
		/* mode argument we must return a character vector. */
		/* and otherwise, we use the natural coersion. */
		/* The exception is "factor" vectors.  These can */
		/* only be combined with factors of exactly the */
		/* same "orderedness", number of levels and */
		/* levels themselves. */

	mode = NILSXP;
	if (ans_flags & 64) mode = LISTSXP;
	else if (ans_flags & 32) mode = STRSXP;
	else {
		if (ans_flags & 1)
			mode = LGLSXP;
		if (ans_flags & 2) {
			if(ans_flags != 2) badtypes(PRIMVAL(op));
			t = CDR(args);
			while(t != R_NilValue) {
				if(!factorsConform(CAR(args), CAR(t)))
					badfactors(PRIMVAL(op));
				t = CDR(t);
			}
			mode = FACTSXP;
		}
		if (ans_flags & 4) {
			if(ans_flags != 4) badtypes(PRIMVAL(op));
			while(t != R_NilValue) {
				if(!factorsConform(CAR(args), CAR(t)))
					badfactors(PRIMVAL(op));
				t = CDR(t);
			}
			mode = ORDSXP;
		}
		if (ans_flags & 8)
			mode = INTSXP;
		if (ans_flags & 16)
			mode = REALSXP;
	}
	PROTECT(ans = allocVector(mode, ans_length));
	ans_ptr = ans;
	ans_length = 0;

	if (mode == LISTSXP) {
		if(!recurse) {
			while(args != R_NilValue) {
				listanswer(CAR(args), 0);
				args = CDR(args);
			}
		}
		else listanswer(CAR(args), recurse);
	}
	else if(mode == STRSXP)
		stringanswer(args);
	else if(mode == REALSXP)
		realanswer(args);
	else
		integeranswer(args);
	if(mode == FACTSXP || mode == ORDSXP) {
		LEVELS(ans) = LEVELS(CAR(args));
		setAttrib(ans, R_LevelsSymbol, getAttrib(CAR(args), R_LevelsSymbol));
	}
	if(ans_nnames && ans_length > 0) {
		PROTECT(ans_names = allocVector(STRSXP, ans_length));
		ans_nnames = 0;
		ExtractNames(args, recurse);
		setAttrib(ans, R_NamesSymbol, ans_names);
		UNPROTECT(1);
	}
	UNPROTECT(1);
	return ans;
}

	/* Unlike S, we don't propagate attributes on */
	/* arrays in bind.  This only makes sense if */
	/* they are identical and who wants to check. */

SEXP do_bind(SEXP call, SEXP op, SEXP args, SEXP env)
{
	int i, k, n;
	int flags, mode, recurse;
	SEXP t, u, result, top, tmp;

	ans_length = 0;
	ans_flags = 0;
	answertype(args, 0, 0);

	if (ans_length == 0)
		return R_NilValue;

	if (ans_flags >= 64) {
		if (ans_flags & 64)
			mode = LISTSXP;
	}
	else if (ans_flags >= 32) {
		if (ans_flags & 32)
			mode = STRSXP;
	}
	else {
		if (ans_flags & 1)
			mode = LGLSXP;
		if (ans_flags & 2) {
			if(ans_flags != 2) badtypes(PRIMVAL(op));
			t = CDR(args);
			while(t != R_NilValue) {
				if(!factorsConform(CAR(args), CAR(t)))
					badfactors(PRIMVAL(op));
				t = CDR(t);
			}
			mode = FACTSXP;
		}
		if (ans_flags & 4) {
			if(ans_flags != 4) badtypes(PRIMVAL(op));
			while(t != R_NilValue) {
				if(!factorsConform(CAR(args), CAR(t)))
					badfactors(PRIMVAL(op));
				t = CDR(t);
			}
			mode = ORDSXP;
		}
		if (ans_flags & 8)
			mode = INTSXP;
		if (ans_flags & 16)
			mode = REALSXP;
	}

	switch(mode) {
		case NILSXP:
		case LGLSXP:
		case FACTSXP:
		case ORDSXP:
		case INTSXP:
		case REALSXP:
		case CPLXSXP:
		case STRSXP:
			break;
		default:
			errorcall(call, "cannot create a matrix from these types\n");
	}
	
	switch (PRIMVAL(op)) {
	case 1:
		return cbind(args, mode);
	case 2:
		return rbind(args, mode);
	}
}

SEXP cbind(SEXP args, SEXPTYPE mode)
{
	int k, i, rows = 0, cols = 0, mrows = 0, idx, n;
	SEXP t, u, result, dims;

	for (t = args; t != R_NilValue; t = CDR(t)) {
		if (!isNull(CAR(t))) {
			dims = getAttrib(CAR(t), R_DimSymbol);
			if (dims != R_NilValue) {
				cols += INTEGER(dims)[1];
				if (mrows == 0)
					mrows = INTEGER(dims)[0];
				else if (mrows != INTEGER(dims)[0])
					nonconform(1);
			}
			else {
				cols++;
				rows = (rows > length(CAR(t))) ? rows : length(CAR(t));
			}
		}
	}
	if (mrows != 0) {
		if (rows != 0 && rows != 1 && rows != mrows)
			nonconform(1);
		else
			rows = mrows;
	}
	PROTECT(result = allocMatrix(mode, rows, cols));
	n = 0;

	if (mode == STRSXP) {
		for (t = args; t != R_NilValue; t = CDR(t)) {
			if (!isNull(CAR(t))) {
				u = CAR(t) = coerceVector(CAR(t), STRSXP);
				k = LENGTH(u);
				idx = (!isArray(CAR(t))) ? rows : k;
				for (i = 0; i < idx; i++)
					STRING(result)[n++] = STRING(u)[i % k];
			}
		}
	}
	else {
		for (t = args; t != R_NilValue; t = CDR(t)) {
			if (!isNull(CAR(t))) {
				u = CAR(t);
				k = LENGTH(u);
				idx = (!isArray(CAR(t))) ? rows : k;
				if (TYPEOF(u) <= INTSXP) {
					if (mode <= INTSXP) {
						for (i = 0; i < idx; i++)
							INTEGER(result)[n++] = INTEGER(u)[i % k];
					}
					else {
						for (i = 0; i < idx; i++)
							REAL(result)[n++] = (INTEGER(u)[i % k]) == NA_INTEGER ? NA_REAL : INTEGER(u)[i % k];
					}
				}
				else {
					for (i = 0; i < idx; i++)
						REAL(result)[n++] = REAL(u)[i % k];
				}
			}
		}
	}
	if(mode == FACTSXP || mode == ORDSXP) {
		LEVELS(result) = LEVELS(CAR(args));
		setAttrib(result, R_LevelsSymbol, getAttrib(CAR(args), R_LevelsSymbol));
	}
	UNPROTECT(1);
	return result;
}

SEXP rbind(SEXP args, SEXPTYPE mode)
{
	int i, j, k, rows = 0, cols = 0, mcols = 0, rowctr = 0, mrows = 0;
	SEXP t, u, result, dims;

	for (t = args; t != R_NilValue; t = CDR(t)) {
		if (!isNull(CAR(t))) {
			dims = getAttrib(CAR(t), R_DimSymbol);
			if (dims != R_NilValue) {
				rows += INTEGER(dims)[0];
				if (mcols == 0)
					mcols = INTEGER(dims)[1];
				if (mcols != INTEGER(dims)[1])
					error("rbind: number of cols must be equal for all matrices\n");
			}
			else {
				rows++;
				cols = (cols > length(CAR(t))) ? cols : length(CAR(t));
			}
		}
	}
	if (mcols != 0)
		cols = mcols;
	PROTECT(result = allocMatrix(mode, rows, cols));
	rowctr = 0;
	if (mode == STRSXP) {
		for (t = args; t != R_NilValue; t = CDR(t)) {
			if (!isNull(CAR(t))) {
				CAR(t) = coerceVector(CAR(t), STRSXP);
				u = CAR(t);
				k = LENGTH(u);
				mrows = (isArray(u)) ? nrows(u) : 1;
				for (i = 0; i < mrows; i++)
					for (j = 0; j < cols; j++)
						STRING(result)[i + rowctr + (j * rows)] = STRING(u)[(i + j * mrows) % k];
				rowctr += mrows;
			}
		}
		UNPROTECT(1);
		return result;
	}
	for (t = args; t != R_NilValue; t = CDR(t)) {
		if (!isNull(CAR(t))) {
			u = CAR(t);
			k = LENGTH(u);
			mrows = (isArray(u)) ? nrows(u) : 1;
			if (TYPEOF(u) <= INTSXP) {
				if (mode <= INTSXP) {
					for (i = 0; i < mrows; i++)
						for (j = 0; j < cols; j++)
							INTEGER(result)[i + rowctr + (j * rows)] = INTEGER(u)[(i + j * mrows) % k];
					rowctr += mrows;
				}
				else {
					for (i = 0; i < mrows; i++)
						for (j = 0; j < cols; j++)
							REAL(result)[i + rowctr + (j * rows)] = (INTEGER(u)[(i + j * mrows) % k]) == NA_INTEGER ? NA_REAL : INTEGER(u)[(i + j * mrows) % k];
					rowctr += mrows;
				}
			}
			else {
				for (i = 0; i < mrows; i++)
					for (j = 0; j < cols; j++)
						REAL(result)[i + rowctr + (j * rows)] = REAL(u)[(i + j * mrows) % k];
				rowctr += mrows;
			}
		}
	}
	if(mode == FACTSXP || mode == ORDSXP) {
		LEVELS(result) = LEVELS(CAR(args));
		setAttrib(result, R_LevelsSymbol, getAttrib(CAR(args), R_LevelsSymbol));
	}
	UNPROTECT(1);
	return result;
}
