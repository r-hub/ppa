/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DSPFA factors a double symmetric matrix stored in
 *     packed form by elimination with symmetric pivoting.
 *
 *     To solve  a*x = b, follow DSPFA by DSPSL.
 *     To compute  inverse(a)*c, follow DSPFA by DSPSL.
 *     To compute  determinant(a), follow DSPFA by DSPDI.
 *     To compute  inertia(a), follow DSPFA by DSPDI.
 *     To compute  inverse(a), follow DSPFA by DSPDI.
 *
 *     On Entry
 *
 *        ap      double (n*(n+1)/2)
 *                the packed form of a symmetric matrix  a.  the
 *                columns of the upper triangle are stored sequentially
 *                in a one-dimensional array of length  n*(n+1)/2.
 *                see comments below for details.
 *
 *        n       int
 *                the order of the matrix  a.
 *
 *     Output
 *
 *        ap      a block diagonal matrix and the multipliers which
 *                were used to obtain it stored in packed form.
 *                the factorization can be written  a = u*d*trans(u)
 *                where  u  is a product of permutation and unit
 *                upper triangular matrices, trans(u) is the
 *                transpose of  u, and  d  is block diagonal
 *                with 1 by 1 and 2 by 2 blocks.
 *
 *        kpvt    int(n)
 *                an int vector of pivot indices.
 *
 *        info    int
 *                = 0  normal value.
 *                = k  if the k-th pivot block is singular. this is
 *                     not an error condition for this subroutine,
 *                     but it does indicate that DSPSL or DSPDI may
 *                     divide by zero if called.
 *
 *     Packed Storage
 *
 *          The following program segment will pack the upper
 *          triangle of a symmetric matrix.
 *
 *                k = 0
 *                do 20 j = 1, n
 *                   do 10 i = 1, j
 *                      k = k + 1
 *                      ap(k)  = a(i,j)
 *             10    continue
 *             20 continue
 *
 *     LINPACK. This version dated 08/14/78.
 *     James Bunch, Univ. Calif. San Diego, Argonne Nat. Lab.
 *     C Translation by Ross Ihaka.
 */

#define ap(i)	ap[i]
#define kpvt(i)	kpvt[i]

#define FALSE	0
#define TRUE	1

void DSPFA(double *ap, int n, int *kpvt, int *info)
{
	double ak, akm1, bk, bkm1, denom, mulk, mulkm1, t;
	double absakk, alpha, colmax, rowmax;
	int ij, ijj, ik, ikm1, im, imax, imaxp1, imim, imj, imk;
	int j, jj, jk, jkm1, jmax, jmim, k, kk, km1, km1k, km1km1, km2, kstep;
	int swap;

	/* initialize */

	ap -= 1;
	kpvt -= 1;

	/* alpha is used in choosing pivot block size. */

	alpha = (1.0+sqrt(17.0))/8.0;

	*info = 0;

	/* main loop on k, which goes from n to 1. */

	k = n;
	ik = (n*(n-1))/2;
	for(;;) {

		/* leave the loop if k=0 or k=1. */

		if(k == 0)
			return;
		if(k <= 1)
			break;

		/* this section of code determines the kind of */
		/* elimination to be performed.  when it is completed, */
		/* kstep will be set to the size of the pivot block, and */
		/* swap will be set toTRUE if an interchange is */
		/* required. */

		km1 = k-1;
		kk = ik+k;
		absakk = fabs(ap(kk));

		/* determine the largest off-diagonal element in */
		/* column k. */

		imax = IDAMAX(k-1, &ap(ik+1), 1);
		imk = ik+imax;
		colmax = fabs(ap(imk));
		if(absakk >= alpha*colmax) {
			kstep = 1;
			swap =FALSE;
		}
		else {

			/* determine the largest off-diagonal element in */
			/* row imax. */

			rowmax = 0.0;
			imaxp1 = imax+1;
			im = imax*(imax-1)/2;
			imj = im+2*imax;
			for(j=imaxp1 ; j <= k  ; j++) {
				rowmax = fmax(rowmax, fabs(ap(imj)));
				imj = imj+j;
			}
			if(imax != 1) {
				jmax = IDAMAX(imax-1, &ap(im+1), 1);
				jmim = jmax+im;
				rowmax = fmax(rowmax, fabs(ap(jmim)));
			}
			imim = imax+im;
			if(fabs(ap(imim)) >= alpha*rowmax) {
				kstep = 1;
				swap =TRUE;
			}
			else if(absakk < alpha*colmax*colmax/rowmax) {
				kstep = 2;
				swap = imax != km1;
			}
			else {
				kstep = 1;
				swap =FALSE;
			}
		}
		if(fmax(absakk, colmax) == 0.0) {

			/* column k is zero.  set info and iterate the loop. */

			kpvt(k) = k;
			*info = k;
		}
		else if(kstep == 2) {

			/* 2 x 2 pivot block. */

			km1k = ik+k-1;
			ikm1 = ik-(k-1);
			if(swap) {

				/* perform an interchange. */

				DSWAP(imax, &ap(im+1), 1, &ap(ikm1+1), 1);
				imj = ikm1+imax;
				for(jj=imax ; jj <= km1  ; jj++) {
					j = km1+imax-jj;
					jkm1 = ikm1+j;
					t = ap(jkm1);
					ap(jkm1) = ap(imj);
					ap(imj) = t;
					imj = imj-(j-1);
				}
				t = ap(km1k);
				ap(km1k) = ap(imk);
				ap(imk) = t;
			}

			/* perform the elimination. */

			km2 = k-2;
			if(km2 != 0) {
				ak = ap(kk)/ap(km1k);
				km1km1 = ikm1+k-1;
				akm1 = ap(km1km1)/ap(km1k);
				denom = 1.0-ak*akm1;
				ij = ik-(k-1)-(k-2);
				for(jj=1 ; jj <= km2  ; jj++) {
					j = km1-jj;
					jk = ik+j;
					bk = ap(jk)/ap(km1k);
					jkm1 = ikm1+j;
					bkm1 = ap(jkm1)/ap(km1k);
					mulk = (akm1*bk-bkm1)/denom;
					mulkm1 = (ak*bkm1-bk)/denom;
					t = mulk;
					DAXPY(j, t, &ap(ik+1), 1, &ap(ij+1), 1);
					t = mulkm1;
					DAXPY(j, t, &ap(ikm1+1), 1, &ap(ij+1), 1);
					ap(jk) = mulk;
					ap(jkm1) = mulkm1;
					ijj = ij+j;
					ij = ij-(j-1);
				}
			}

			/* set the pivot array. */

			kpvt(k) = 1-k;
			if(swap)
				kpvt(k) = -imax;
			kpvt(k-1) = kpvt(k);
		}
		else {

			/* 1 x 1 pivot block. */

			if(swap) {

				/* perform an interchange. */

				DSWAP(imax, &ap(im+1), 1, &ap(ik+1), 1);
				imj = ik+imax;
				for(jj=imax ; jj <= k  ; jj++) {
					j = k+imax-jj;
					jk = ik+j;
					t = ap(jk);
					ap(jk) = ap(imj);
					ap(imj) = t;
					imj = imj-(j-1);
				}
			}

			/* perform the elimination. */

			ij = ik-(k-1);
			for(jj=1 ; jj <= km1  ; jj++) {
				j = k-jj;
				jk = ik+j;
				mulk = -ap(jk)/ap(kk);
				t = mulk;
				DAXPY(j, t, &ap(ik+1), 1, &ap(ij+1), 1);
				ijj = ij+j;
				ap(jk) = mulk;
				ij = ij-(j-1);
			}

			/* set the pivot array. */

			kpvt(k) = k;
			if(swap)
				kpvt(k) = imax;
		}
		ik = ik-(k-1);
		if(kstep == 2)
			ik = ik-(k-2);
		k = k-kstep;
	}
	kpvt(1) = 1;
	if(ap(1) == 0.0)
		*info = 1;
	return;
}

int dspfa_(double *ap, int *n, int *kpvt, int *info)
{
	DSPFA(ap, *n, kpvt, info);
}
