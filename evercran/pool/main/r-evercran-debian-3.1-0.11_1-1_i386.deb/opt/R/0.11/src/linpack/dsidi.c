/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DSIDI computes the determinant, inertia and inverse
 *     of a double symmetric matrix using the factors from
 *     DSIFA.
 *
 *     On Entry
 *
 *        a       double(lda,n)
 *                the output from DSIFA.
 *
 *        lda     int
 *                the leading dimension of the array a.
 *
 *        n       int
 *                the order of the matrix a.
 *
 *        kpvt    int(n)
 *                the pivot vector from DSIFA.
 *
 *        work    double(n)
 *                work vector.  contents destroyed.
 *
 *        job     int
 *                job has the decimal expansion  abc  where
 *                   if  c != 0, the inverse is computed,
 *                   if  b != 0, the determinant is computed,
 *                   if  a != 0, the inertia is computed.
 *
 *                for example, job = 111  gives all three.
 *
 *     On Return
 *
 *        Variables not requested by job are not used.
 *
 *        a      contains the upper triangle of the inverse of
 *               the original matrix.  the strict lower triangle
 *               is never referenced.
 *
 *        det    double(2)
 *               determinant of original matrix.
 *               determinant = det(1) * 10.0**det(2)
 *               with 1.0 <= fabs(det(1)) < 10.0
 *               or det(1) = 0.0.
 *
 *        inert  int(3)
 *               the inertia of the original matrix.
 *               inert(1)  =  number of positive eigenvalues.
 *               inert(2)  =  number of negative eigenvalues.
 *               inert(3)  =  number of zero eigenvalues.
 *
 *     Error Condition
 *
 *        A division by zero may occur if the inverse is requested
 *        and  DSICO  has set rcond == 0.0
 *        or  DSIFA  has set  info != 0.
 *
 *     LINPACK. This version dated 08/14/78.
 *     James Bunch, Univ. Calif. San Diego, Argonne Nat. Lab
 *     C Translation by Ross Ihaka.
 */

#define a(i,j)		a[i+(j)*lda]
#define kpvt(i)		kpvt[i]
#define det(i)		det[i]
#define inert(i)	inert[i]
#define work(i)		work[i]

void DSIDI(double *a, int lda, int n, int *kpvt, double *det, int *inert, double *work, int job)
{
	double akkp1, temp;
	double ten, d, t, ak, akp1;
	int j, jb, k, km1, ks, kstep;
	int noinv, nodet, noert;

	a -= (lda+1);
	kpvt -= 1;
	det -= 1;
	inert -= 1;
	work -= 1;

	noinv = (job % 10) == 0;
	nodet = (job % 100)/10 == 0;
	noert = (job % 1000)/100 == 0;

	if(!nodet || !noert) {
		if(!noert) {
			inert(1) = 0;
			inert(2) = 0;
			inert(3) = 0;
		}
		if(!nodet) {
			det(1) = 1.0;
			det(2) = 0.0;
			ten = 10.0;
		}
		t = 0.0;
		for(k=1 ; k <= n  ; k++) {
			d = a(k, k);

			/* check if 1 by 1 */

			if(kpvt(k) <= 0)

				/* 2 by 2 block */
				/* use det (d  s)  =  (d/t * c - t) * t,  t = fabs(s) */
				/* (s  c) */
				/* to avoid underflow/overflow troubles. */
				/* take two passes through scaling.  use  t  for flag. */

				if(t != 0.0) {
					d = t;
					t = 0.0;
				}
				else {
					t = fabs(a(k, k+1));
					d = (d/t)*a(k+1, k+1)-t;
				}

			if(!noert) {
				if(d > 0.0)
					inert(1) = inert(1)+1;
				if(d < 0.0)
					inert(2) = inert(2)+1;
				if(d == 0.0)
					inert(3) = inert(3)+1;
			}

			if(!nodet) {
				det(1) = d*det(1);
				if(det(1) != 0.0) {
					while (fabs(det(1)) < 1.0) {
						det(1) = ten*det(1);
						det(2) = det(2)-1.0;
					}
					while (fabs(det(1)) >= ten) {
						det(1) = det(1)/ten;
						det(2) = det(2)+1.0;
					}
				}
			}
		}
	}

	/* compute inverse(a) */

	if(!noinv) {
		k = 1;
		while (k <= n) {
			km1 = k-1;
			if(kpvt(k) >= 0) {

				/* 1 by 1 */

				a(k, k) = 1.0/a(k, k);
				if(km1 >= 1) {
					DCOPY(km1, &a(1, k), 1, &work(1), 1);
					for(j=1 ; j <= km1  ; j++) {
						a(j, k) = DDOT(j, &a(1, j), 1, &work(1), 1);
						DAXPY(j-1, work(j), &a(1, j), 1, &a(1, k), 1);
					}
					a(k, k) = a(k, k)+DDOT(km1, &work(1), 1, &a(1, k), 1);
				}
				kstep = 1;
			}
			else {

				/* 2 by 2 */

				t = fabs(a(k, k+1));
				ak = a(k, k)/t;
				akp1 = a(k+1, k+1)/t;
				akkp1 = a(k, k+1)/t;
				d = t*(ak*akp1-1.0);
				a(k, k) = akp1/d;
				a(k+1, k+1) = ak/d;
				a(k, k+1) = -akkp1/d;
				if(km1 >= 1) {
					DCOPY(km1, &a(1, k+1), 1, &work(1), 1);
					for(j=1 ; j <= km1  ; j++) {
						a(j, k+1) = DDOT(j, &a(1, j), 1, &work(1), 1);
						DAXPY(j-1, work(j), &a(1, j), 1, &a(1, k+1), 1);
					}
					a(k+1, k+1) = a(k+1, k+1)+DDOT(km1, &work(1), 1, &a(1, k+1), 1);
					a(k, k+1) = a(k, k+1)+DDOT(km1, &a(1, k), 1, &a(1, k+1), 1);
					DCOPY(km1, &a(1, k), 1, &work(1), 1);
					for(j=1 ; j <= km1  ; j++) {
						a(j, k) = DDOT(j, &a(1, j), 1, &work(1), 1);
						DAXPY(j-1, work(j), &a(1, j), 1, &a(1, k), 1);
					}
					a(k, k) = a(k, k)+DDOT(km1, &work(1), 1, &a(1, k), 1);
				}
				kstep = 2;
			}

			/* swap */

			ks = abs(kpvt(k));
			if(ks != k) {
				DSWAP(ks, &a(1, ks), 1, &a(1, k), 1);
				for(jb=ks ; jb <= k  ; jb++) {
					j = k+ks-jb;
					temp = a(j, k);
					a(j, k) = a(ks, j);
					a(ks, j) = temp;
				}
				if(kstep != 1) {
					temp = a(ks, k+1);
					a(ks, k+1) = a(k, k+1);
					a(k, k+1) = temp;
				}
			}
			k = k+kstep;
		}
	}
	return;
}

int dsidi_(double *a, int *lda, int *n, int *kpvt, double *det, int *inert, double *work, int *job)
{
	DSIDI(a, *lda, *n, kpvt, det, inert, work, *job);
}
