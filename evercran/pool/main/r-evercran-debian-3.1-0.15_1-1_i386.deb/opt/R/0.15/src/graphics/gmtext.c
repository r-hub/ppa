/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995, 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Graphics.h"

#define XINVFMAP(x) ((x - GP->fig2dev.ax)/GP->fig2dev.bx)
#define YINVFMAP(y) ((y - GP->fig2dev.ay)/GP->fig2dev.by)

void GMtext(char *str, int side, double line, int outer, double at)
{
	double a, x, y;
	int xpdsave;

	if(outer) {
		switch(side) {
		case 1:
			y = yChartoNDC(GP->cexbase*GP->mex*(GP->oma[0]-line+1));
			x = at;
			a = 0.0;
			break;
		case 2:
			x = xChartoNDC(GP->cexbase*GP->mex*(GP->oma[1]-line));
			y = at;
			a = 90.0;
			break;
		case 3:
			y = 1.0-yChartoNDC(GP->cexbase*GP->mex*(GP->oma[2]-line));
			x = at;
			a = 0.0;
			break;
		case 4:
			x = 1.0-xChartoNDC(GP->cexbase*GP->mex*(GP->oma[3]-line));
			y = at;
			a = 270.0;
			break;
		}
		x = DP->ndc2dev.ax + DP->ndc2dev.bx * x;
		y = DP->ndc2dev.ay + DP->ndc2dev.by * y;
		x = XINVFMAP(x);
		y = YINVFMAP(y);
		GText(x, y, str, GP->adj, 0.0, a);
	}
	else {
		switch(side) {
		case 1:
			y = yChartoInch(GP->cexbase*GP->mex*(line+1-GP->yLineBias));
			y = GP->plt[2] - yInchtoFig(y);
			x = XMAP(at);
			a = 0.0;
			break;
		case 2:
			x = xChartoInch(GP->cexbase*GP->mex*(line+GP->yLineBias));
			x = GP->plt[0] - xInchtoFig(x);
			y = YMAP(at);
			a = 90.0;
			break;
		case 3:
			y = yChartoInch(GP->cexbase*GP->mex*(line+GP->yLineBias));
			y = GP->plt[3] + yInchtoFig(y);
			x = XMAP(at);
			a = 0.0;
			break;
		case 4:
			x = xChartoInch(GP->cexbase*GP->mex*(line-GP->yLineBias));
			x = GP->plt[1] + xInchtoFig(x);
			y = YMAP(at);
			a = 270.0;
			break;
		}
		GText(x, y, str, GP->adj, 0.0, a);
	}
}
