###--- >>> `stepfun' <<<----- Step Functions

	## alias	 help(stepfun)
	## alias	 help(is.stepfun)
	## alias	 help(print.stepfun)
	## alias	 help(summary.stepfun)
	## alias	 help(knots)
	## alias	 help(knots.stepfun)

##___ Examples ___:

y0 <- c(1,2,4,3)
sfun0  <- stepfun(1:3, y0, f = 0)
sfun.2 <- stepfun(1:3, y0, f = .2)
sfun1  <- stepfun(1:3, y0, f = 1)
sfun0
summary(sfun0)
summary(sfun.2)

x0 <- seq(0.5,3.5, by = 0.25)
rbind(x=x0, f.f0 = sfun0(x0), f.f02= sfun.2(x0), f.f1 = sfun1(x0))

## Keywords: 'dplot'.


