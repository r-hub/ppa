###--- >>> `lag' <<<----- Lag a Time Series

	## alias	 help(lag)
	## alias	 help(lag.default)

##___ Examples ___:

data(UKLungDeaths)
lag(ldeaths, 12) # starts one year earlier

## Keywords: 'ts'.


