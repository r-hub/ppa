#define R_VERSION 65793
#define R_Version(v,p,s) (((v) * 65536) + ((p) * 256) + (s))
#define R_MAJOR  "1"
#define R_MINOR  "1.1"
#define R_STATUS ""
#define R_YEAR   "2000"
#define R_MONTH  "August"
#define R_DAY    "15"
