###--- >>> `ar.ols' <<<----- Fit Autoregressive Models to Time Series by OLS

	## alias	 help(ar.ols)

##___ Examples ___:

data(lh)
ar(lh, method="burg")
ar.ols(lh)
ar.ols(lh, FALSE, 4) # fit ar(4)

data(BJsales)
ar.ols(ts.union(BJsales, BJsales.lead))

data(EuStockMarkets)
x <- diff(log(EuStockMarkets))
ar.ols(x, order.max=6, demean=FALSE, intercept=TRUE)

## Keywords: 'ts'.


