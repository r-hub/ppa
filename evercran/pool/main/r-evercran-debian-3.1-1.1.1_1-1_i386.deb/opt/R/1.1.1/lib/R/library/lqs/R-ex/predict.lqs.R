###--- >>> `predict.lqs' <<<----- Predict from an lqs Fit

	## alias	 help(predict.lqs)

##___ Examples ___:

data(stackloss)
set.seed(123)
fm <- lqs(stack.loss ~ ., data = stackloss, method = "S", nsamp = "exact")
predict(fm, stackloss)

## Keywords: 'models'.


