###--- >>> `cov.rob' <<<----- Resistant Estimation of Multivariate Location and Scatter

	## alias	 help(cov.rob)
	## alias	 help(cov.mve)
	## alias	 help(cov.mcd)

##___ Examples ___:

data(stackloss)
set.seed(123)
cov.rob(stackloss)
cov.rob(stack.x, method = "mcd", nsamp = "exact")

## Keywords: 'robust', 'multivariate'.


