###--- >>> `PP.test' <<<----- Phillips-Perron Unit Root Test

	## alias	 help(PP.test)

##___ Examples ___:

x <- rnorm(1000)
PP.test(x)
y <- cumsum(x) # has unit root
PP.test(y)

## Keywords: 'ts'.


