###--- >>> `window' <<<----- Time Windows

	## alias	 help(window)
	## alias	 help(window.default)
	## alias	 help(window.ts)

##___ Examples ___:

data(presidents)
sixties <- window(presidents, 1960, c(1969,4))

## Keywords: 'ts'.


