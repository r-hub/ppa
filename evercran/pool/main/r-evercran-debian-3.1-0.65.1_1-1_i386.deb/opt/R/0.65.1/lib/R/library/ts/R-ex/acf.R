###--- >>> `acf' <<<----- Autocovariance and Autocorrelation Function Estimation

	## alias	 help(acf)
	## alias	 help(ccf)
	## alias	 help(pacf)
	## alias	 help(pacf.ts)
	## alias	 help(pacf.mts)
	## alias	 help(plot.acf)

##___ Examples ___:

## Examples from Venables & Ripley
data(lh)
acf(lh)
acf(lh, type="covariance")
pacf(lh)

data(UKLungDeaths)
acf(ldeaths)
acf(ldeaths, ci.type="ma")
acf(ts.union(mdeaths, fdeaths))
ccf(mdeaths, fdeaths) # just the cross-correlations.

## Keywords: 'ts'.


