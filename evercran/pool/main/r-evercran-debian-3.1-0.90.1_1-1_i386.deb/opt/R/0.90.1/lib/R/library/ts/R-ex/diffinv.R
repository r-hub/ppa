###--- >>> `diffinv' <<<----- Discrete Integrals: Inverse of Differencing

	## alias	 help(diffinv)
	## alias	 help(diffinv.ts)
	## alias	 help(diffinv.default)
	## alias	 help(diffinv.vec)

##___ Examples ___:

s <- 1:10
d <- diff(s)
diffinv(d,xi=1)

## Keywords: 'ts'.


