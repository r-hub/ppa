###--- >>> `cpgram' <<<----- Plot Cumulative Periodogram

	## alias	 help(cpgram)

##___ Examples ___:

par(pty="s", mfrow=c(1,2))
data(lh)
cpgram(lh)
lh.ar <- ar(lh, order.max=9)
cpgram(lh.ar$resid, main="AR(3) fit to lh")

data(UKLungDeaths)
cpgram(ldeaths)

## Keywords: 'ts', 'hplot'.


