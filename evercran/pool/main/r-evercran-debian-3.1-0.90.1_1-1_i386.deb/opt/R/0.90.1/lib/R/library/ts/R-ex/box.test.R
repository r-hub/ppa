###--- >>> `Box.test' <<<----- Box--Pierce and Ljung--Box Tests

	## alias	 help(Box.test)

##___ Examples ___:

x <- rnorm (100)
Box.test (x, lag = 1)
Box.test (x, lag = 1, type="Ljung")

## Keywords: 'ts'.


