###--- >>> `bs' <<<----- Generate a Basis for Polynomial Splines

	## alias	 help(bs)

##___ Examples ___:

library(splines)
data(women)
bs(women$height, df = 5)
summary(fm1 <- lm(weight ~ bs(height, df = 5), data = women))



