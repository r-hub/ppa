###--- >>> `splineOrder' <<<----- Determine the Order of a Spline

	## alias	 help(splineOrder)
	## alias	 help(splineOrder.bSpline)
	## alias	 help(splineOrder.polySpline)

##___ Examples ___:

library( splines )
data( women )
splineOrder( interpSpline( weight ~ height, women ) )

## Keywords: 'models '.


