/* src/include/Rconfig.h.  Generated automatically by configure.  */
			/* Dear Emacs, I'm -*- C -*- code .. */
#ifndef RCONFIG_H_
#define RCONFIG_H_

#define Unix

/* AIX at least. */
#ifndef _ALL_SOURCE
/* #undef _ALL_SOURCE */
#endif

/* alloca */
/* #undef C_ALLOCA */
#define HAVE_ALLOCA 1
#define HAVE_ALLOCA_H 1

/* Define to empty if the keyword does not work.  */
/* #undef const */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* (Long) Integers */
#define SIZEOF_LONG 4

/* Floating Point Arithmetic */
#define HAVE_MATHERR 1		/* System V */
#define HAVE_ISNAN 1		/* IEEE Arith indicator */
#define HAVE_FINITE 1

/* #undef HAVE_FLOATINGPOINT_H */
#define HAVE_FPU_CONTROL_H 1
/* #undef HAVE_IEEEFP_H */		/* "-Wall" */
#define HAVE_IEEE754_H 1		/* Linux */

#ifdef HAVE_ISNAN
#ifdef HAVE_FINITE
#define IEEE_754
#endif
#endif

/* Signal Handler Type */
#define RETSIGTYPE void

/* Process ID */
/* #undef pid_t */
/* Object size */
/* #undef size_t */
/* Fix a GCC bug on AIX? */
/* #undef blkcnt_t */

/* Define if you have <sys/wait.h> that is POSIX.1 compatible.  */
#define HAVE_SYS_WAIT_H 1

/* Dynamic Linking */
/* #undef HAVE_DL_H */		/* hpux */
#define HAVE_DLFCN_H 1		/* Everything else */

/* ELF Binary Format */
#define HAVE_ELF_H 1

/* Process Timing */
#define HAVE_TIMES 1
#define HAVE_SYS_TIME_H 1
#define HAVE_SYS_TIMES_H 1
#define TIME_WITH_SYS_TIME 1

/* XDR Library Available */
#define HAVE_RPC_RPC_H 1
#define HAVE_RPC_XDR_H 1

/* HDF5 Library Available */
/* #undef HAVE_HDF5 */

/* General String Comparison */
#define HAVE_STRCOLL 1

/* Inverse Hyperbolics */
#define HAVE_ASINH 1
#define HAVE_ACOSH 1
#define HAVE_ATANH 1

/* Unix commands through a subshell */
#define HAVE_SYSTEM 1

/* IEEE Rounding */
#define HAVE_RINT 1

/* HPUX rint is broken */
/* #undef USE_BUILTIN_RINT */

/* POSIX Regular Expressions Available */
#define HAVE_REGCOMP 1

/* Compatibility for "memmove" on older BSD platforms */
#define HAVE_MEMMOVE 1
#define HAVE_MEMCPY 1
#define HAVE_BCOPY 1

/* POSIX.1 sigsetjmp/siglongjmp available */
#define HAVE_POSIX_SETJMP 1

/* Some Linux systems may need this */
/* #undef NEED___SETFPUCW */

/* Fortran and C Links */
#define HAVE_F77_UNDERSCORE 1

#ifdef HAVE_F77_UNDERSCORE
#define F77_SYMBOL(x)	x ## _
#define F77_QSYMBOL(x)	#x ## "_"
#else
#define F77_SYMBOL(x)	x
#define F77_QSYMBOL(x)	#x
#endif

/* GNU Readline Library */
#define HAVE_LIBREADLINE 1
#define HAVE_READLINE_HISTORY_H 1
#define HAVE_READLINE_READLINE_H 1

/* Miscellaneous */
#define HAVE_LOCALE_H 1
#define HAVE_SYS_STAT_H 1
#define HAVE_SYS_TYPES_H 1
#define HAVE_UNISTD_H 1

/* Dirent stuff */
#define HAVE_DIRENT_H 1
/* #undef HAVE_SYS_NDIR_H */
/* #undef HAVE_SYS_DIR_H */
/* #undef HAVE_NDIR_H */

/* Bug Workarounds */
/* #undef HAVE_OSF_SPRINTF_BUG */
/* #undef CALLOC_BROKEN */
/* #undef FINITE_BROKEN */
/* #undef LOG_BROKEN */

/* Some platforms other than ELF drop the leading _ */
/* #undef HAVE_NO_SYMBOL_UNDERSCORE */
#ifndef HAVE_NO_SYMBOL_UNDERSCORE
#ifdef HAVE_ELF_H
#define HAVE_NO_SYMBOL_UNDERSCORE
#endif
#endif

/* SunOS 4 is famous for broken header files */
/* #undef SunOS4 */
#ifdef SunOS4
# ifndef NULL
#  define	NULL		0
# endif
# ifndef RAND_MAX
#  define	RAND_MAX	32767
# endif
#endif /* SunOS4 */

/* Printing Command */
#define R_PRINTCMD	""

/* Getting the working directory */
#define HAVE_GETCWD 1

/* Maximal length of an entire file name */
#define HAVE_SYS_PARAM_H 1

/* for platform.c to put in .Platform */
#ifdef Unix
#define OSTYPE      "unix"
#define FILESEP     "/"
#define SHLIBEXT    "so"
#define DYNLOADEXT  "." ## SHLIBEXT
#endif

#ifdef Macintosh
#define OSTYPE      "mac"
#define FILESEP     ":"
#define DYNLOADEXT  ".dll"
#endif

#ifdef Win32
#define OSTYPE      "windows"
#define FILESEP     "/"
#define DYNLOADEXT  ".dll"
#endif

#define R_PLATFORM	"i686-unknown-linux"
#define R_CPU		"i686"
#define R_VENDOR	"unknown"
#define R_OS		"linux"

#endif
