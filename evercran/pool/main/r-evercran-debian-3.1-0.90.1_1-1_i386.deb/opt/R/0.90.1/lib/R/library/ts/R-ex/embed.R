###--- >>> `embed' <<<----- Embedding a Time Series

	## alias	 help(embed)

##___ Examples ___:

x <- 1:10
embed (x, 3)

## Keywords: 'ts'.


