###--- >>> `kmeans' <<<----- K-Means Clustering

	## alias	 help(kmeans)

##___ Examples ___:

# a 2-dimensional example
x <- rbind(matrix(rnorm(100,sd=0.3),ncol=2),
           matrix(rnorm(100,mean=1,sd=0.3),ncol=2))
cl <- kmeans(x,2,20)
plot(x, col = cl$cluster)
points(cl$centers,col = 1:2,pch = 8)

## Keywords: 'multivariate', 'cluster'.


