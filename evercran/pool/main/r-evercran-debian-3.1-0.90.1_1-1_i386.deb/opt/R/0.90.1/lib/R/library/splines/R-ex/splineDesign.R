###--- >>> `splineDesign' <<<----- Design Matrix for B-splines

	## alias	 help(splineDesign)
	## alias	 help(spline.des)

##___ Examples ___:

library( splines )
splineDesign(knots = 1:10, x = 4:7)

## Keywords: 'models '.


