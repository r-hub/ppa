#!/bin/sh
# Shell wrapper of R executable.
# Putting extra arguments into environment variables
#	-v : Size of VECTOR heap in MBytes [= 1024^2 bytes]
#	-n : Size of LANGUAGE (cons-cell) heap * [4-words = 16-bytes]
#
#

RHOME=R_HOME_DIR
export RHOME

# Default Printer Paper Size
# Choose one of the following
# R_PAPERSIZE="a4"
# R_PAPERSIZE="letter"
# R_PAPERSIZE="none"
R_PAPERSIZE=a4
export R_PAPERSIZE

# Default Print Command
# Choose one of the following
# R_PRINTCMD="lpr"
# R_PRINTCMD="lp"
R_PRINTCMD=
export R_PRINTCMD

args=""

for i in $*
do
	case $i in
	-v*)	R_VSIZE=`echo $i | sed 's/-v//'`; export R_VSIZE;;
	-n*)	R_NSIZE=`echo $i | sed 's/-n//'`; export R_NSIZE;;
	*)	args="$args $i"
	esac
done

exec $RHOME/bin/R.binary $args
