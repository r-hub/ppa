#define R_VERSION 65537
#define R_Version(v,p,s) (((v) * 65536) + ((p) * 256) + (s))
#define R_MAJOR  "1"
#define R_MINOR  "0.1"
#define R_STATUS ""
#define R_YEAR   "2000"
#define R_MONTH  "April"
#define R_DAY    "14"
