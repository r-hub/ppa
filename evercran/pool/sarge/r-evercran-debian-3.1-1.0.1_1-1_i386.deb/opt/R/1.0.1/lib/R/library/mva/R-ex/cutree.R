###--- >>> `cutree' <<<----- Cut a tree into groups of data

	## alias	 help(cutree)

##___ Examples ___:

require(mva)
data(USArrests)

hc <- hclust(dist(USArrests))

cutree(hc, k=2:5)
cutree(hc, h=250)

## Keywords: 'multivariate', 'cluster'.


