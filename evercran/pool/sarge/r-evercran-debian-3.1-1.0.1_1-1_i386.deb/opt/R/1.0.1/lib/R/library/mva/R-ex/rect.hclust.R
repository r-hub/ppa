###--- >>> `rect.hclust' <<<----- Draw Rectangles Around Hierarchical Clusters

	## alias	 help(rect.hclust)

##___ Examples ___:

library(mva)
data(USArrests)
hca <- hclust(dist(USArrests))
plot(hca)
rect.hclust(hca, k=3, border="red")
x <- rect.hclust(hca, h=50, which=c(2,7), border=3:4)
x

## Keywords: 'aplot', 'cluster'.


