###--- >>> `na.omit.ts' <<<----- NA Handling Routines for Time Series

	## alias	 help(na.omit.ts)
	## alias	 help(na.contiguous)

##___ Examples ___:

data(BJsales)
sales1 <- ts.union(BJsales, lead3 = lag(BJsales.lead, -3))
na.omit.ts(sales1)

data(presidents)
na.contiguous(presidents)

## Keywords: 'ts'.


