###--- >>> `splineKnots' <<<----- Knot Vector from a Spline

	## alias	 help(splineKnots)
	## alias	 help(splineKnots.spline)

##___ Examples ___:

library( splines )
data( women )
ispl <- interpSpline( weight ~ height, women )
splineKnots( ispl )

## Keywords: 'models'.


