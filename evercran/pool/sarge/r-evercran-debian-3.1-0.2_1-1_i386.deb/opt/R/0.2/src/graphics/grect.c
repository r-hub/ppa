/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995, 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Graphics.h"

int ValidColor(int);

void GRect(double x0, double y0, double x1, double y1, int col, int border)
{
	/* For efficiency save/restore color in the calling code */

	if(ValidColor(col)) {
		GP->col = col;
		DevRect((int)XFMAP(x0), (int)YFMAP(y0),
			(int)XFMAP(x1), (int)YFMAP(y1), 1);
	}
	if(ValidColor(border)){
		GP->col = border;
		GStartPath();
		GMoveTo(x0, y0);
		GLineTo(x1, y0);
		GLineTo(x1, y1);
		GLineTo(x0, y1);
		GLineTo(x0, y0);
		GEndPath();
	}
}
