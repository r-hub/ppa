/* SCCS: @(#)charmatch.c	1.1  1/26/90 */
/*
** The working part of the charmatch function in S
*/
#include <string.h>

charmatch(input, n_input, target, n_target, result)
char *input[], *target[];
long *n_input, *n_target;
long result[];
{
    register int i,j, k;
    register int match;
    int  temp, perfect;

    for (i=0; i<*n_input; i++) {
	temp = strlen(input[i]);
	match= -1;  perfect=0;
	for (j=0; j< *n_target; j++) {
	    k = strncmp(input[i], target[j], temp);
	    if (k==0) {
		if (strlen(target[j]) == temp) {
		    if (perfect==1) match=0;
		    else {
			perfect=1;
			match = j+1;
			}
		    }
		else if (perfect==0) {
		    if (match== -1)  match=j+1;
		    else             match=0;
		    }
		}
	    }
	result[i] = match;
	}
    }
