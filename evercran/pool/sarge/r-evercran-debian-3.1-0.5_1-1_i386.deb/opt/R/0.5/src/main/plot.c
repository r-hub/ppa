/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995, 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"
#include "Graphics.h"

	/* Coordinate Mappings */
	/* Linear/Logarithmic Scales */

static double (*xt) (double);
static double (*yt) (double);

static double Log10(double x)
{
	return (x == NA_REAL || x <= 0.0) ? NA_REAL : log10(x);
}

static double Ident(double x)
{
	return x;
}


void NewFrameConfirm()
{
	int c;
	REprintf("Next plot? ");
	while((c = cget()) != '\n' && c != EOF)
		;
}


/* Device Startup */
SEXP do_device(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP s;
	char *device;
	int i, ncpars, nnpars;
	char *cpars[20];
	double *npars;

		/* NO GARBAGE COLLECTS ALLOWED HERE*/
		/* WE ARE USING REAL POINTERS */
		/* SWITCH TO R_ALLOCING IF NECESSARY */

	checkArity(op, args);

	s = CAR(args);
	if (!isString(s) || length(s) <= 0)
		errorcall(call, "device name must be a character string\n");
	device = CHAR(STRING(s)[0]);

	s = CADR(args);
	if (!isString(s) || length(s) > 20)
		errorcall(call, "invalid device driver parameters\n");
	ncpars = LENGTH(s);
	for(i=0 ; i<LENGTH(s) ; i++)
		cpars[i] = CHAR(STRING(s)[i]);

	s = CADDR(args);
	if (!isReal(CADDR(args)))
		errorcall(call, "width and height must be numeric\n");
	nnpars = LENGTH(s);

	if( !strcmp(device,"X11") )
		for(i=0 ; i<nnpars ; i++ ) 
			if( REAL(s)[i] <= 0 || REAL(s)[i] == NA_REAL )
				errorcall(call, "invalid device driver parameter\n");
	npars = REAL(s);

	if (!SetDevice(device, cpars, ncpars, npars, nnpars))
		errorcall(call, "unable to start device %s\n", device);

	xt = Ident;
	yt = Ident;
	return CAR(args);
}


	/* GetPar is intended for looking through a list */
	/* typically that bound to ... for a particular */
	/* parameter value.  This is easier than trying */
	/* to match every graphics parameter in argument */
	/* lists and passing them explicitly. */

SEXP GetPar(char *which, SEXP parlist)
{
	SEXP w, p;
	w = install(which);
	for(p=parlist ; p!=R_NilValue ; p=CDR(p)) {
		if(TAG(p) == w)
			return CAR(p);
	}
	return R_NilValue;
}

SEXP FixupPch(SEXP pch)
{
	int i, n;
	SEXP ans;

	if(length(pch) == 0) {
		ans = allocVector(INTSXP, n=1);
		INTEGER(ans)[0] = GP->pch;
	}
	else if(isList(pch)) {
		ans = allocVector(INTSXP, n=length(pch));
		for(i=0 ; pch != R_NilValue ;  pch = CDR(pch))
			INTEGER(ans)[i++] = asInteger(CAR(pch));
	}
	else if(isInteger(pch)) {
		ans = allocVector(INTSXP, n=length(pch));
		for(i=0 ; i<n ; i++)
			INTEGER(ans)[i] = INTEGER(pch)[i];
	}
	else if(isReal(pch)) {
		ans = allocVector(INTSXP, n=length(pch));
		for(i=0 ; i<n ; i++)
			INTEGER(ans)[i] = (REAL(pch)[i] == NA_REAL) ?
						NA_INTEGER : REAL(pch)[i];
	}
	else if(isString(pch)) {
		ans = allocVector(INTSXP, n=length(pch));
		for(i=0 ; i<n ; i++)
			INTEGER(ans)[i] = CHAR(STRING(pch)[i])[0];
	}
	else error("invalid plotting symbol\n");
	for(i=0 ; i<n ; i++) {
		if(INTEGER(ans)[i] < 0 || INTEGER(ans)[i] > 255)
			INTEGER(ans)[i] = GP->pch;
	}
	return ans;
}

SEXP FixupLty(SEXP lty)
{
	int i, n;
	SEXP ans;
	if(length(lty) == 0) {
		ans = allocVector(INTSXP, 1);
		INTEGER(ans)[0] = GP->lty;
	}
	else {
		ans = allocVector(INTSXP, n=length(lty));
		for(i=0 ; i<n; i++)
			INTEGER(ans)[i] = LTYpar(lty, i);
	}
	return ans;
}

SEXP FixupFont(SEXP font)
{
	int i, k, n;
	SEXP ans;
	if(length(font) == 0) {
		ans = allocVector(INTSXP, 1);
		INTEGER(ans)[0] = NA_INTEGER;
	}
	else if(isInteger(font)) {
		ans = allocVector(INTSXP, n=length(font));
		for(i=0 ; i<n; i++) {
			k = INTEGER(font)[i];
			if(k < 1 || k > 4) k = NA_INTEGER;
			INTEGER(ans)[i] = k;
		}
	}
	else if(isReal(font)) {
		ans = allocVector(INTSXP, n=length(font));
		for(i=0 ; i<n; i++) {
			k = REAL(font)[i];
			if(k < 1 || k > 4) k = NA_INTEGER;
			INTEGER(ans)[i] = k;
		}
	}
	else error("invalid font specification\n");
	return ans;
}

SEXP FixupCol(SEXP col)
{
	int i, n;
	SEXP ans, pcol;

	if(length(col) == 0) {
		ans = allocVector(INTSXP, 1);
		INTEGER(ans)[0] = NA_INTEGER;
	}
	else if(isList(col)) {
		ans = allocVector(INTSXP, n=length(col));
		for(i=0 ; i<n; i++) {
			INTEGER(ans)[i] = RGBpar(CAR(col), 0);
			col = CDR(col);
		}
	}
	else {
		ans = allocVector(INTSXP, n=length(col));
		for(i=0 ; i<n; i++)
			INTEGER(ans)[i] = RGBpar(col, i);
	}
	return ans;
}

SEXP FixupCex(SEXP cex)
{
	SEXP ans;
	int i, n;
	double c;

	if(length(cex) == 0) {
		ans = allocVector(REALSXP, 1);
		REAL(ans)[0] = NA_REAL;
	}
	else if(isReal(cex)) {
		ans = allocVector(REALSXP, n=length(cex));
		for(i=0 ; i<n; i++) {
			c = REAL(cex)[i];
			if(c == NA_REAL || c <= 0)
				c = NA_REAL;
			REAL(ans)[i] = c;
		}
	}
	else if(isInteger(cex)) {
		ans = allocVector(REALSXP, n=length(cex));
		for(i=0 ; i<n; i++) {
			c = INTEGER(cex)[i];
			if(c == NA_INTEGER || c <= 0)
				c = NA_REAL;
			REAL(ans)[i] = c;
		}
	}
	return ans;
}

	/* plot.new() -- create a new plot */

SEXP do_plot_new(SEXP call, SEXP op, SEXP args, SEXP env)
{
	int ask, asksave;
	checkArity(op, args);
	ask = asLogical(CAR(args));	
	if(ask == NA_LOGICAL) ask = DP->ask;
	asksave = GP->ask;
	GP->ask = ask;
	GNewPlot();
	DP->xlog = GP->xlog = 0;
	DP->ylog = GP->ylog = 0;
	xt = Ident;
	yt = Ident;
	GP->ask = asksave;
	return R_NilValue;
}


	/* plot.window(xlim, ylim, log) -- define world coordinates */

SEXP do_plot_window(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP xlim, ylim, log;
	double xmin, xmax, ymin, ymax;
	char *p;

	checkArity(op, args);

	xlim = CAR(args);
	if(!isNumeric(xlim) || LENGTH(xlim) != 2)
		errorcall(call, "invalid xlim\n");
	args = CDR(args);

	ylim = CAR(args);
	if(!isNumeric(ylim) || LENGTH(ylim) != 2)
		errorcall(call, "invalid ylim\n");
	args = CDR(args);

	log = CAR(args);
	if (!isString(log))
		error("invalid \"log=\" specification\n");
	p = CHAR(STRING(log)[0]);
	while (*p) {
		switch (*p) {
		case 'x':
			DP->xlog = GP->xlog = 1;
			xt = Log10;
			break;
		case 'y':
			DP->ylog = GP->ylog = 1;
			yt = Log10;
			break;
		default:
			error("invalid \"log=\" specification\n");
		}
		p++;
	}

	if(isInteger(xlim)) {
		if(INTEGER(xlim)[0] == NA_INTEGER || INTEGER(xlim)[1] == NA_INTEGER)
			errorcall(call, "NAs not allowed in xlim\n");
		xmin = INTEGER(xlim)[0];
		xmax = INTEGER(xlim)[1];
	}
	else {
		if(REAL(xlim)[0] == NA_REAL || REAL(xlim)[1] == NA_REAL)
			errorcall(call, "NAs not allowed in xlim\n");
		xmin = REAL(xlim)[0];
		xmax = REAL(xlim)[1];
	}
	if(isInteger(ylim)) {
		if(INTEGER(ylim)[0] == NA_INTEGER || INTEGER(ylim)[1] == NA_INTEGER)
			errorcall(call, "NAs not allowed in ylim\n");
		ymin = INTEGER(ylim)[0];
		ymax = INTEGER(ylim)[1];
	}
	else {
		if(REAL(ylim)[0] == NA_REAL || REAL(ylim)[1] == NA_REAL)
			errorcall(call, "NAs not allowed in ylim\n");
		ymin = REAL(ylim)[0];
		ymax = REAL(ylim)[1];
	}
	GScale(xmin, xmax, 1);
	GScale(ymin, ymax, 2);
	GMapping(0);
	GMapWin2Fig();
	return R_NilValue;
}

	/* axis(which, at, labels, ...) -- draw an axis */

SEXP do_axis(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP at, lab, lty, fg, col, cex, font;
	int i, n, nc, which, xpdsave;
	int colsave, fontsave, ltysave;
	double cexsave, x, y, xc, yc, xtk, ytk, tnew, tlast, cwid;
	double gap, labw;

	if(length(args) < 3)
		errorcall(call, "too few arguments");

		/* Named Arguments */

	which = asInteger(CAR(args));
	if (which < 1 || which > 4)
		errorcall(call, "invalid axis number\n");
	args = CDR(args);
	
	internalTypeCheck(call, at = CAR(args), REALSXP);
	args = CDR(args);

	internalTypeCheck(call, lab = CAR(args), STRSXP);
	if (LENGTH(at) != LENGTH(lab))
		errorcall(call, "location and label lengths differ\n");
	n = LENGTH(at);
	args = CDR(args);

		/* Graphical Parameters */

	PROTECT(lty = FixupLty(GetPar("lty", args)));
	if(INTEGER(lty)[0] == NA_INTEGER) INTEGER(lty)[0] = LTY_SOLID;
 
	PROTECT(fg = FixupCol(GetPar("fg", args)));
	if(INTEGER(fg)[0] == NA_INTEGER) INTEGER(fg)[0] = GP->fg;
 
	PROTECT(col = FixupCol(GetPar("col.axis", args)));
	if(INTEGER(col)[0] == NA_INTEGER) INTEGER(col)[0] = GP->colaxis;
 
	PROTECT(cex = FixupCex(GetPar("cex.axis", args)));
	if(REAL(cex)[0] == NA_REAL) REAL(cex)[0] = GP->cexaxis;

	PROTECT(font = FixupFont(GetPar("font.axis", args)));
	if(INTEGER(font)[0] == NA_INTEGER) INTEGER(font)[0] = GP->fontaxis;

	ltysave = GP->lty;
	colsave = GP->col;
	cexsave = GP->cex;
	fontsave = GP->font;
	xpdsave = GP->xpd;
	GP->font = INTEGER(font)[0];
	GP->cex = GP->cexbase * REAL(cex)[0];
	GP->xpd = 1;

		/* Compute the ticksize in NDC units */

	xc = fabs(GP->mex * GP->cexbase * GP->cra[1] * GP->asp / GP->fig2dev.bx);
	yc = fabs(GP->mex * GP->cexbase * GP->cra[1] / GP->fig2dev.by);
	xtk = 0.5 * xc;
	ytk = 0.5 * yc;
	x = GP->plt[0];
	y = GP->plt[2];

	GMode(1);
	switch (which) {
	case 1:
	case 3:
		if (which == 3) {
			y = GP->plt[3];
			ytk = -ytk;
		}
		GP->col = INTEGER(fg)[0];
		GStartPath();
		GMoveTo(XMAP(xt(REAL(at)[0])), y);
		GLineTo(XMAP(xt(REAL(at)[n - 1])), y);
		for (i = 0; i < n; i++) {
			x = XMAP(xt(REAL(at)[i]));
			if (GP->plt[0] <= x && x <= GP->plt[1]) {
				GMoveTo(x, y);
				GLineTo(x, y - ytk);
			}
		}
		GEndPath();
		GP->col = INTEGER(col)[0];
		tlast = -1.0;
		gap = GStrWidth("m", 2);	/* FIXUP x/y distance */
		for (i = 0; i < n; i++) {
			x = XMAP(xt(REAL(at)[i]));
			labw = GStrWidth(CHAR(STRING(lab)[i]), 2);
			tnew = x - 0.5 * labw;
			if (tnew - tlast >= gap) {
				GMtext(CHAR(STRING(lab)[i]), which, GP->mgp[1], 0, xt(REAL(at)[i]));
				tlast = x + 0.5 *labw;
			}
		}
		break;
	case 2:
	case 4:
		if (which == 4) {
			x = GP->plt[1];
			xtk = -xtk;
		}
		GP->col = INTEGER(fg)[0];
		GStartPath();
		GMoveTo(x, YMAP(yt(REAL(at)[0])));
		GLineTo(x, YMAP(yt(REAL(at)[n - 1])));
		for (i = 0; i < n; i++) {
			y = YMAP(yt(REAL(at)[i]));
			if (GP->plt[2] <= y && y <= GP->plt[3]) {
				GMoveTo(x, y);
				GLineTo(x - xtk, y);
			}
		}
		GEndPath();
		GP->col = INTEGER(col)[0];
		gap = GStrWidth("m", 2);
		gap = yInchtoFig(xFigtoInch(gap));
		tlast = -1.0;
		cwid = GP->cex * fabs(GP->cra[0] / GP->ndc2dev.by);
		for (i = 0; i < n; i++) {
			y = YMAP(yt(REAL(at)[i]));
			labw = GStrWidth(CHAR(STRING(lab)[i]), 2);
			labw = yInchtoFig(xFigtoInch(labw));
			tnew = y - 0.5 * labw;
			if (tnew - tlast >= gap) {
				GMtext(CHAR(STRING(lab)[i]), which, GP->mgp[1], 0, yt(REAL(at)[i]));
				tlast = y + 0.5 *labw;
			}
		}
		break;
	}
	GMode(0);
	GP->lty = ltysave;
	GP->cex = cexsave;
	GP->col = colsave;
	GP->font = fontsave;
	GP->xpd = xpdsave;
	UNPROTECT(5);
	return R_NilValue;
}

	/* plot.xy(xy, type, ...) -- plot points or lines */

SEXP do_plot_xy(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP sxy, sx, sy, pch, cex, col, lty, par;
	double *x, *y, xold, yold, xx, yy;
	double cexsave;
	int type, ltysave, colsave;
	int i, n, npch, ncex, ncol, nlty;

	if(length(args) < 2)
		errorcall(call, "too few arguments\n");

		/* Named Arguments */

	sxy = CAR(args);
	if (!isList(sxy) || length(sxy) < 2)
		errorcall(call, "invalid plotting structure\n");
	internalTypeCheck(call, sx = CAR(sxy), REALSXP);
	internalTypeCheck(call, sy = CADR(sxy), REALSXP);
	if (LENGTH(sx) != LENGTH(sy))
		error("x and y lengths differ for plot\n");
	n = LENGTH(sx);
	args = CDR(args);

	if(isNull(CAR(args))) type = 'p';
	else {
		if(isString(CAR(args)) && LENGTH(CAR(args)) == 1)
			type = CHAR(STRING(CAR(args))[0])[0];
		else errorcall(call, "invalid plot type\n");
	}
	args = CDR(args);

		/* Graphical Parameters */
		
	PROTECT(pch = FixupPch(GetPar("pch", args)));
	npch = length(pch);

	PROTECT(lty = FixupLty(GetPar("lty", args)));
	nlty = length(lty);

	PROTECT(col = FixupCol(GetPar("col", args)));
	ncol = LENGTH(col);

	PROTECT(cex = FixupCex(GetPar("cex", args)));
	ncex = LENGTH(cex);

	x = REAL(sx);
	y = REAL(sy);
	colsave = GP->col;
	ltysave = GP->lty;
	cexsave = GP->cex;

	if(nlty && INTEGER(lty)[0] != NA_INTEGER)
		GP->lty = INTEGER(lty)[0];

	if(ncex && REAL(cex)[0] != NA_REAL)
		GP->cex = GP->cexbase * REAL(cex)[0];
	else
		GP->cex = GP->cexbase;

	GMode(1);

		/* lines and overplotted lines and points */

	if (type == 'l' || type == 'o') {
		GP->col = INTEGER(col)[0];
		if(GP->col == NA_INTEGER) GP->col = colsave;
		xold = NA_REAL;
		yold = NA_REAL;
		GStartPath();
		for (i = 0; i < n; i++) {
			xx = xt(x[i]);
			yy = yt(y[i]);
			if (xold != NA_REAL && yold != NA_REAL && xx != NA_REAL && yy != NA_REAL) {
				GLineTo(XMAP(xx), YMAP(yy));
			}
			else if (xx != NA_REAL && yy != NA_REAL)
				GMoveTo(XMAP(xx), YMAP(yy));
			xold = xx;
			yold = yy;
		}
		GEndPath();
	}

		/* points connected with broken lines */

	if(type == 'b' || type == 'c') {
		double d, f, x0, x1, xc, y0, y1, yc;
		d = 0.5 * GP->cex * GP->cra[1] * GP->ipr[1];
		xc = xNDCtoInch(GP->fig2dev.bx / GP->ndc2dev.bx) * (GP->plt[1] - GP->plt[0]);
		yc = yNDCtoInch(GP->fig2dev.by / GP->ndc2dev.by) * (GP->plt[3] - GP->plt[2]);
		xc = xc / (GP->usr[1] - GP->usr[0]);
		yc = yc / (GP->usr[3] - GP->usr[2]);
		GP->col = INTEGER(col)[0];
		if(GP->col == NA_INTEGER) GP->col = colsave;
		xold = NA_REAL;
		yold = NA_REAL;
		GStartPath();
		for (i = 0; i < n; i++) {
			xx = xt(x[i]);
			yy = yt(y[i]);
			if (xold != NA_REAL && yold != NA_REAL && xx != NA_REAL && yy != NA_REAL) {
				if((f = d/hypot(xc * (xx-xold), yc * (yy-yold))) < 0.5) {
					x0 = xold + f * (xx - xold);
					y0 = yold + f * (yy - yold);
					x1 = xx + f * (xold - xx);
					y1 = yy + f * (yold - yy);
					GMoveTo(XMAP(x0), YMAP(y0));
					GLineTo(XMAP(x1), YMAP(y1));
				}
			}
			xold = xx;
			yold = yy;
		}
		GEndPath();
	}

	if (type == 's') {
		GP->col = INTEGER(col)[0];
		if(GP->col == NA_INTEGER) GP->col = colsave;
		xold = xt(x[0]);
		yold = xt(y[0]);
		GStartPath();
		if (xold != NA_REAL && yold != NA_REAL)
			GMoveTo(XMAP(xold), YMAP(yold));
		for (i = 1; i < n; i++) {
			xx = xt(x[i]);
			yy = yt(y[i]);
			if (xold != NA_REAL && yold != NA_REAL && xx != NA_REAL && yy != NA_REAL) {
				GLineTo(XMAP(xx), YMAP(yold));
				GLineTo(XMAP(xx), YMAP(yy));
			}
			else if (x[i] != NA_REAL && y[i] != NA_REAL)
				GMoveTo(XMAP(xx), YMAP(yy));
			xold = xx;
			yold = yy;
		}
		GEndPath();
	}

	if (type == 'S') {
		GP->col = INTEGER(col)[0];
		if(GP->col == NA_INTEGER) GP->col = colsave;
		xold = xt(x[0]);
		yold = xt(y[0]);
		GStartPath();
		if (xold != NA_REAL && yold != NA_REAL)
			GMoveTo(XMAP(xold), YMAP(yold));
		for (i = 1; i < n; i++) {
			xx = xt(x[i]);
			yy = yt(y[i]);
			if (xold != NA_REAL && yold != NA_REAL && xx != NA_REAL && yy != NA_REAL) {
				GLineTo(XMAP(xold), YMAP(yy));
				GLineTo(XMAP(xx), YMAP(yy));
			}
			else if (x[i] != NA_REAL && y[i] != NA_REAL)
				GMoveTo(XMAP(xx), YMAP(yy));
			xold = xx;
			yold = yy;
		}
		GEndPath();
	}

	if (type == 'h') {
		GP->col = INTEGER(col)[0];
		if(GP->col == NA_INTEGER) GP->col = colsave;
		for (i = 0; i < n; i++) {
			xx = xt(x[i]);
			yy = yt(y[i]);
			if (xx != NA_REAL && yy != NA_REAL) {
				GStartPath();
				GMoveTo(XMAP(xx), YMAP(yt(0.0)));
				GLineTo(XMAP(xx), YMAP(yy));
				GEndPath();
			}
		}
	}

	GP->lty = ltysave;
	if (type == 'p' || type == 'b' || type == 'o') {
		for (i = 0; i < n; i++) {
			xx = xt(x[i]);
			yy = yt(y[i]);
			if (xx != NA_REAL && yy != NA_REAL) {
				GP->col = INTEGER(col)[i % ncol];
				if(GP->col == NA_INTEGER) GP->col = colsave;
				GSymbol(XMAP(xx), YMAP(yy), INTEGER(pch)[i % npch]);
			}
		}
	}
	GMode(0);
	GP->lty = ltysave;
	GP->col = colsave;
	GP->cex = cexsave;
	UNPROTECT(4);
	return R_NilValue;
}

static void xypoints(SEXP call, SEXP args, int *n)
{
	int k;

	if (!isNumeric(CAR(args)) || (k = LENGTH(CAR(args))) <= 0)
		errorcall(call, "first argument invalid\n");
	CAR(args) = coerceVector(CAR(args), REALSXP);
	*n = k;
	args = CDR(args);

	if (!isNumeric(CAR(args)) || (k = LENGTH(CAR(args))) <= 0)
		errorcall(call, "second argument invalid\n");
	CAR(args) = coerceVector(CAR(args), REALSXP);
	if (k > *n) *n = k;
	args = CDR(args);

	if (!isNumeric(CAR(args)) || (k = LENGTH(CAR(args))) <= 0)
		errorcall(call, "third argument invalid\n");
	CAR(args) = coerceVector(CAR(args), REALSXP);
	if (k > *n) *n = k;
	args = CDR(args);

	if (!isNumeric(CAR(args)) || (k = LENGTH(CAR(args))) <= 0)
		errorcall(call, "fourth argument invalid\n");
	CAR(args) = coerceVector(CAR(args), REALSXP);
	if (k > *n) *n = k;
	args = CDR(args);
}

	/* segments(x0, y0, x1, y1, col, lty) */

SEXP do_segments(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP sx0, sy0, sx1, sy1, col, lty;
	double *x0, *x1, *y0, *y1;
	int nx0, nx1, ny0, ny1;
	int i, n, ncol, colsave, nlty, ltysave;

	if(length(args) < 4) errorcall(call, "too few arguments\n");

	xypoints(call, args, &n);

	sx0 = CAR(args); nx0 = length(sx0); args = CDR(args);
	sy0 = CAR(args); ny0 = length(sy0); args = CDR(args);
	sx1 = CAR(args); nx1 = length(sx1); args = CDR(args);
	sy1 = CAR(args); ny1 = length(sy1); args = CDR(args);

	PROTECT(lty = FixupLty(GetPar("lty", args)));
	nlty = length(lty);

	PROTECT(col = FixupCol(GetPar("col", args)));
	ncol = LENGTH(col);

	x0 = REAL(sx0);
	y0 = REAL(sy0);
	x1 = REAL(sx1);
	y1 = REAL(sy1);
	colsave = GP->col;
	ltysave = GP->lty;
	GMode(1);
	for (i = 0; i < n; i++) {
		if (x0[i % nx0] != NA_REAL && y0[i % ny0] != NA_REAL
		    && x1[i % nx1] != NA_REAL && y1[i % ny1] != NA_REAL) {
			GP->col = INTEGER(col)[i % ncol];
			if(GP->col == NA_INTEGER) GP->col = colsave;
			GP->lty = INTEGER(lty)[i % nlty];
			GStartPath();
			GMoveTo(XMAP(x0[i % nx0]), YMAP(y0[i % ny0]));
			GLineTo(XMAP(x1[i % nx1]), YMAP(y1[i % ny1]));
			GEndPath();
		}
	}
	GMode(0);
	GP->col = colsave;
	GP->lty = ltysave;
	UNPROTECT(2);
	return R_NilValue;
}

	/* rect(xl, yb, xr, yt, col, border) */

SEXP do_rect(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP sxl, sxr, syb, syt, col, lty, border;
	double *xl, *xr, *yb, *yt;
	int i, n, nxl, nxr, nyb, nyt;
	int ncol, nlty, nborder;
	int colsave, ltysave;

	if(length(args) < 4) errorcall(call, "too few arguments\n");
	xypoints(call, args, &n);

	sxl = CAR(args); nxl = length(sxl); args = CDR(args);
	syb = CAR(args); nyb = length(syb); args = CDR(args);
	sxr = CAR(args); nxr = length(sxr); args = CDR(args);
	syt = CAR(args); nyt = length(syt); args = CDR(args);

	PROTECT(col = FixupCol(GetPar("col", args)));
	ncol = LENGTH(col);

	PROTECT(border =  FixupCol(GetPar("border", args)));
	nborder = LENGTH(border);

	PROTECT(lty = FixupLty(GetPar("lty", args)));
	nlty = length(lty);

	xl = REAL(sxl);
	xr = REAL(sxr);
	yb = REAL(syb);
	yt = REAL(syt);

	ltysave = GP->lty;
	colsave = GP->col;
	GMode(1);
	for (i = 0; i < n; i++) {
		if (xl[i % nxl] != NA_REAL && yb[i % nyb] != NA_REAL
		    && xr[i % nxr] != NA_REAL && yt[i % nyt] != NA_REAL)
				GRect(XMAP(xl[i % nxl]), YMAP(yb[i % nyb]),
				      XMAP(xr[i % nxr]), YMAP(yt[i % nyt]),
					INTEGER(col)[i % ncol],
					INTEGER(border)[i % nborder]);
	}
	GMode(0);
	GP->col = colsave;
	GP->lty = ltysave;
	UNPROTECT(3);
	return R_NilValue;
}

	/* do_arrows(x0, y0, x1, y1, length, angle, code, col) */

SEXP do_arrows(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP sx0, sx1, sy0, sy1, col, lty;
	double *x0, *x1, *y0, *y1;
	double hlength, angle;
	int code, i, n, nx0, nx1, ny0, ny1;
	int ncol, colsave, nlty, ltysave, xpd;

	if(length(args) < 4) errorcall(call, "too few arguments\n");
	xypoints(call, args, &n);

	sx0 = CAR(args); nx0 = length(sx0); args = CDR(args);
	sy0 = CAR(args); ny0 = length(sy0); args = CDR(args);
	sx1 = CAR(args); nx1 = length(sx1); args = CDR(args);
	sy1 = CAR(args); ny1 = length(sy1); args = CDR(args);

	hlength = asReal(GetPar("length", args));
	if (hlength == NA_REAL || hlength <= 0)
		errorcall(call, "invalid head length\n");

	angle = asReal(GetPar("angle", args));
	if (angle == NA_REAL)
		errorcall(call, "invalid head angle\n");

	code = asInteger(GetPar("code", args));
	if (code == NA_INTEGER || code < 0 || code > 3)
		errorcall(call, "invalid arrow head specification\n");

	PROTECT(col = FixupCol(GetPar("col", args)));
	ncol = LENGTH(col);

	PROTECT(lty = FixupLty(GetPar("lty", args)));
	nlty = length(lty);

	xpd = asLogical(GetPar("xpd", args));
	if(xpd == NA_LOGICAL) xpd = GP->xpd;

	x0 = REAL(sx0);
	y0 = REAL(sy0);
	x1 = REAL(sx1);
	y1 = REAL(sy1);

	colsave = GP->col;
	ltysave = GP->lty;
	GMode(1);
	for (i = 0; i < n; i++) {
		if (x0[i % nx0] != NA_REAL && y0[i % ny0] != NA_REAL
		    && x1[i % nx1] != NA_REAL && y1[i % ny1] != NA_REAL) {
			GP->col = INTEGER(col)[i % ncol];
			if(GP->col == NA_INTEGER) GP->col = colsave;
			if(nlty == 0 || INTEGER(lty)[i % nlty] == NA_INTEGER)
				GP->lty = ltysave;
			else
				GP->lty = INTEGER(lty)[i % nlty];
		}
		GArrow(XMAP(x0[i % nx0]), YMAP(y0[i % ny0]),
		       XMAP(x1[i % nx1]), YMAP(y1[i % ny1]),
		       hlength, angle, code);
	}
	GMode(0);
	GP->col = colsave;
	GP->lty = ltysave;
	UNPROTECT(2);
	return R_NilValue;
}

	/* polygon(x, y, col, border) */

SEXP do_polygon(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP sx, sy, col, border, lty;
	int colsave, ltysave, xpd, xpdsave;
	int nx, ny, ncol, nborder, nlty, *work;
	char *vmax;

	if(length(args) < 2) errorcall(call, "too few arguments\n");

	if (!isNumeric(CAR(args)) || (nx = LENGTH(CAR(args))) <= 0)
		errorcall(call, "first argument invalid\n");
	sx = CAR(args) = coerceVector(CAR(args), REALSXP);
	args = CDR(args);

	if (!isNumeric(CAR(args)) || (ny = LENGTH(CAR(args))) <= 0)
		errorcall(call, "second argument invalid\n");
	sy = CAR(args) = coerceVector(CAR(args), REALSXP);
	args = CDR(args);

	if (ny != nx)
		errorcall(call, "x and y lengths differ in polygon");

	PROTECT(col = FixupCol(GetPar("col", args)));
	ncol = LENGTH(col);

	PROTECT(border = FixupCol(GetPar("border", args)));
	nborder = LENGTH(border);

	PROTECT(lty = FixupLty(GetPar("lty", args)));
	nlty = length(lty);

	xpd = asLogical(GetPar("xpd", args));
	if(xpd == NA_LOGICAL) xpd = GP->xpd;

	colsave = GP->col;
	ltysave = GP->lty;
	xpdsave = GP->xpd;
	GMode(1);
	vmax = vmaxget();
	work = (int*)R_alloc(2*nx, sizeof(int));
	if(INTEGER(lty)[0] == NA_INTEGER) GP->lty = ltysave;
	else GP->lty = INTEGER(lty)[0];
	GPolygon(nx, REAL(sx), REAL(sy), INTEGER(col)[0], INTEGER(border)[0], 1, work);
	vmaxset(vmax);
	GMode(0);
	GP->col = colsave;
	GP->lty = ltysave;
	GP->xpd = xpdsave;
	UNPROTECT(3);
	return R_NilValue;
}

SEXP do_text(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP sx, sy, sxy, txt, adj, cex, col, font;
	int i, n, ncex, ncol, nfont, ntxt;
	double adjx, adjy, cexsave;
	int colsave, fontsave, xpd, xpdsave;
	double *x, *y;
	double xx, yy;

	if(length(args) < 2) errorcall(call, "too few arguments\n");

	sxy = CAR(args);
	if (!isList(sxy) || length(sxy) < 2)
		errorcall(call, "invalid plotting structure\n");
	internalTypeCheck(call, sx = CAR(sxy), REALSXP);
	internalTypeCheck(call, sy = CADR(sxy), REALSXP);
	if (LENGTH(sx) != LENGTH(sy))
		error("x and y lengths differ for plot\n");
	n = LENGTH(sx);
	args = CDR(args);

	internalTypeCheck(call, txt = CAR(args), STRSXP);
	if (LENGTH(txt) <= 0)
		errorcall(call, "zero length \"text\" specified\n");
	args = CDR(args);

	PROTECT(cex = FixupCex(GetPar("cex", args)));
	ncex = LENGTH(cex);

	PROTECT(col = FixupCol(GetPar("col", args)));
	ncol = LENGTH(col);

	PROTECT(font = FixupFont(GetPar("font", args)));
	nfont = LENGTH(font);

	PROTECT(adj = GetPar("adj", args));
	if(isNull(adj) || (isNumeric(adj) && length(adj) == 0)) {
		adjx = GP->adj;
		adjy = GP->yCharOffset;
	}
	else if(isReal(adj)) {
		if(LENGTH(adj) == 1) {
			adjx = REAL(adj)[0];
			adjy = GP->yCharOffset;
		}
		else {
			adjx = REAL(adj)[0];
			adjy = REAL(adj)[1];
		}
	}
	else errorcall(call, "invalid adj value");

	xpd = asLogical(GetPar("xpd", args));
	if(xpd == NA_LOGICAL) xpd = 0;

	x = REAL(sx);
	y = REAL(sy);
	n = LENGTH(sx);
	ntxt = LENGTH(txt);

	cexsave = GP->cex;
	colsave = GP->col;
	fontsave = GP->font;
	xpdsave = GP->xpd;
	GP->xpd = xpd;

	GMode(1);
	for (i = 0; i < n; i++) {
		xx = xt(x[i % n]);
		yy = yt(y[i % n]);
		if (xx != NA_REAL && yy != NA_REAL) {
			if (ncol && INTEGER(col)[i % ncol] != NA_INTEGER)
				GP->col = INTEGER(col)[i % ncol];
			else GP->col = colsave;
			if(ncex && REAL(cex)[i % ncex] != NA_REAL)
				GP->cex = GP->cexbase * REAL(cex)[i % ncex];
			else GP->cex = GP->cexbase;
			if (nfont && INTEGER(font)[i % nfont] != NA_INTEGER)
				GP->font = INTEGER(font)[i % nfont];
			else GP->font = fontsave;
			GText(XMAP(xx), YMAP(yy), CHAR(STRING(txt)[i % ntxt]), adjx, adjy, 0.0);
		}
	}
	GMode(0);
	GP->col = colsave;
	GP->cex = cexsave;
	GP->font = fontsave;
	GP->xpd = xpdsave;
	UNPROTECT(4);
	return R_NilValue;
}

	/* mtext(text, side, line, outer, at) */

SEXP do_mtext(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP adj, cex, col, font, text;
	double line, at, adjx, adjy, cexsave, xpdsave;
	int colsave, fontsave, side, outer;

	if(length(args) < 5) errorcall(call, "too few arguments");

	internalTypeCheck(call, text = CAR(args), STRSXP);
	if (LENGTH(text) <= 0)
		errorcall(call, "zero length \"text\" specified\n");
	args = CDR(args);

	side = asInteger(CAR(args));
	if(side < 1 || side > 4) errorcall(call, "invalid side value\n");
	args = CDR(args);

	line = asReal(CAR(args));
	if(line == NA_REAL || line < 0.0) errorcall(call, "invalid line value\n");
	args = CDR(args);

	outer = asInteger(CAR(args));
	if(outer == NA_INTEGER) outer = 0;
	args = CDR(args);

	at = asReal(CAR(args));
	if(line == NA_REAL || line < 0.0) errorcall(call, "invalid at value\n");
	args = CDR(args);

	cexsave = GP->cex;
	colsave = GP->col;
	fontsave = GP->font;
	xpdsave = GP->xpd;

	PROTECT(adj = GetPar("adj", args));
	if(isNull(adj) || (isNumeric(adj) && length(adj) == 0)) {
		adjx = GP->adj;
		adjy = GP->yCharOffset;
	}
	else if(isReal(adj)) {
		if(LENGTH(adj) == 1) {
			adjx = REAL(adj)[0];
			adjy = GP->yCharOffset;
		}
		else {
			adjx = REAL(adj)[0];
			adjy = REAL(adj)[1];
		}
	}
	else errorcall(call, "invalid adj value");

	PROTECT(cex = FixupCex(GetPar("cex", args)));
	if(REAL(cex)[0] != NA_REAL) GP->cex = GP->cexbase * REAL(cex)[0];
	else GP->cex = GP->cexbase;

	PROTECT(col = FixupCol(GetPar("col", args)));
	if(INTEGER(col)[0] != NA_INTEGER) GP->col = INTEGER(col)[0];

	PROTECT(font = FixupFont(GetPar("font", args)));
	if(INTEGER(font)[0] != NA_INTEGER) GP->font = INTEGER(font)[0];

	GP->xpd = 1;
	GMode(1);
	GMtext(CHAR(STRING(text)[0]), side, line, outer, at);
	GMode(0);
	GP->cex = cexsave;
	GP->col = colsave;
	GP->font = fontsave;
	GP->xpd = xpdsave;
	UNPROTECT(4);
	return R_NilValue;
}

	/* Title(main=NULL, sub=NULL, xlab=NULL, ylab=NULL, ...) */

SEXP do_title(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP main, cexmain, colmain, fontmain;
	SEXP xlab, ylab, cexlab, collab, fontlab;
	SEXP sub, cexsub, colsub, fontsub;
	int colsave, fontsave, xpdsave;
	double cexsave, x, y;

	if(length(args) < 4) errorcall(call, "too few arguments");

	main = sub = xlab = ylab = R_NilValue;

	if (CAR(args) != R_NilValue && LENGTH(CAR(args)) > 0)
		main = STRING(CAR(args))[0];
	args = CDR(args);

	if (CAR(args) != R_NilValue && LENGTH(CAR(args)) > 0)
		sub = STRING(CAR(args))[0];
	args = CDR(args);

	if (CAR(args) != R_NilValue && LENGTH(CAR(args)) > 0)
		xlab = STRING(CAR(args))[0];
	args = CDR(args);

	if (CAR(args) != R_NilValue && LENGTH(CAR(args)) > 0)
		ylab = STRING(CAR(args))[0];
	args = CDR(args);

	PROTECT(cexmain = FixupCex(GetPar("cex.main", args)));
	PROTECT(colmain = FixupCol(GetPar("col.main", args)));
	PROTECT(fontmain = FixupFont(GetPar("font.main", args)));
	PROTECT(cexlab = FixupCex(GetPar("cex.lab", args)));
	PROTECT(collab = FixupCol(GetPar("col.lab", args)));
	PROTECT(fontlab = FixupFont(GetPar("font.lab", args)));
	PROTECT(cexsub = FixupCex(GetPar("cex.sub", args)));
	PROTECT(colsub = FixupCol(GetPar("col.sub", args)));
	PROTECT(fontsub = FixupFont(GetPar("font.sub", args)));

	cexsave = GP->cex;
	colsave = GP->col;
	fontsave = GP->font;
	xpdsave = GP->xpd;
	GP->xpd = 1;

	x = fabs((GP->cra[1] * GP->mex) / GP->fig2dev.bx);
	y = fabs((GP->asp * GP->cra[1] * GP->mex)/GP->fig2dev.by);

	GMode(1);
	if(main != R_NilValue) {
		if(REAL(cexmain)[0] != NA_REAL)
			GP->cex = GP->cexbase * REAL(cexmain)[0];
		else GP->cex = GP->cexbase * GP->cexmain;
		GP->col = INTEGER(colmain)[0];
		if(GP->col == NA_INTEGER) GP->col = GP->colmain;
		GP->font = INTEGER(fontmain)[0];
		if(GP->font == NA_INTEGER) GP->font = GP->fontmain;
		GText(0.5*(GP->plt[0]+GP->plt[1]), 0.5*(GP->plt[3]+1.0),
			CHAR(main), 0.5, 0.5, 0.0);
	}
	if(xlab != R_NilValue || ylab != R_NilValue) {
		if(REAL(cexlab)[0] != NA_REAL)
			GP->cex = GP->cexbase * REAL(cexlab)[0];
		else GP->cex = GP->cexbase * GP->cexlab;
		GP->col = INTEGER(collab)[0];
		if(GP->col == NA_INTEGER) GP->col = GP->collab;
		GP->font = INTEGER(fontlab)[0];
		if(GP->font == NA_INTEGER) GP->font = GP->fontlab;
		if(xlab != R_NilValue)
			GMtext(CHAR(xlab), 1, GP->mgp[0], 0, 0.5*(GP->usr[0]+GP->usr[1]));
		if(ylab != R_NilValue)
			GMtext(CHAR(ylab), 2, GP->mgp[0], 0, 0.5*(GP->usr[2]+GP->usr[3]));
	}
	GMode(0);

	GP->cex = cexsave;
	GP->col = colsave;
	GP->font = fontsave;
	GP->xpd = xpdsave;
	UNPROTECT(9);
	return R_NilValue;
}

SEXP do_abline(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP a, b, h, v, col, lty;
	int i, ncol, nlines, nlty, colsave, ltysave;
	double aa, bb;

	if(length(args) < 4) errorcall(call, "too few arguments\n");

	if((a = CAR(args)) != R_NilValue)
		CAR(args) = a = coerceVector(a, REALSXP);
	args = CDR(args);

	if((b = CAR(args)) != R_NilValue)
		CAR(args) = b = coerceVector(b, REALSXP);
	args = CDR(args);

	if((h = CAR(args)) != R_NilValue)
		CAR(args) = h = coerceVector(h, REALSXP);
	args = CDR(args);

	if((v = CAR(args)) != R_NilValue)
		CAR(args) = v = coerceVector(v, REALSXP);
	args = CDR(args);

	PROTECT(col = FixupCol(GetPar("col", args)));
	ncol = LENGTH(col);

	PROTECT(lty = FixupLty(GetPar("lty", args)));
	nlty = length(lty);

	colsave = GP->col;
	ltysave = GP->lty;
	nlines = 0;

	if (a != R_NilValue) {
		if (b == R_NilValue) {
			if (LENGTH(a) != 2)
				errorcall(call, "invalid a=, b= specification in \"abline\"\n");
			aa = REAL(a)[0];
			bb = REAL(a)[1];
		}
		else {
			aa = asReal(a);
			bb = asReal(b);
		}
		if (aa == NA_REAL || bb == NA_REAL)
			errorcall(call, "\"a\" and \"b\" must be non-missing\n");
		if(GP->col == NA_INTEGER) GP->col = colsave;
		else GP->col = INTEGER(col)[i % ncol];
		if(nlty && INTEGER(lty)[i % nlty] != NA_INTEGER) GP->lty = INTEGER(lty)[i % nlty];
		else GP->lty = ltysave;
		GMode(1);
		GStartPath();
		GMoveTo(XMAP(GP->usr[0]), YMAP(aa + GP->usr[0] * bb));
		GLineTo(XMAP(GP->usr[1]), YMAP(aa + GP->usr[1] * bb));
		GEndPath();
		GMode(0);
		nlines++;
	}
	if (h != R_NilValue) {
		GMode(1);
		for (i = 0; i < LENGTH(h); i++) {
			if(GP->col == NA_INTEGER) GP->col = colsave;
			else GP->col = INTEGER(col)[i % ncol];
			if(nlty && INTEGER(lty)[i % nlty] != NA_INTEGER) GP->lty = INTEGER(lty)[i % nlty];
			else GP->lty = ltysave;
			aa = yt(REAL(h)[i]);
			if (aa != NA_REAL) {
				GStartPath();
				GMoveTo(XMAP(GP->usr[0]), YMAP(aa));
				GLineTo(XMAP(GP->usr[1]), YMAP(aa));
				GEndPath();
			}
			nlines++;
		}
		GMode(0);
	}
	if (v != R_NilValue) {
		GMode(1);
		for (i = 0; i < LENGTH(v); i++) {
			if(GP->col == NA_INTEGER) GP->col = colsave;
			else GP->col = INTEGER(col)[i % ncol];
			if(nlty && INTEGER(lty)[i % nlty] != NA_INTEGER) GP->lty = INTEGER(lty)[i % nlty];
			else GP->lty = ltysave;
			aa = xt(REAL(v)[i]);
			if (aa != NA_REAL) {
				GStartPath();
				GMoveTo(XMAP(aa), YMAP(GP->usr[2]));
				GLineTo(XMAP(aa), YMAP(GP->usr[3]));
				GEndPath();
			}
			nlines++;
		}
		GMode(0);
	}
	GP->col = colsave;
	GP->lty = ltysave;
	UNPROTECT(2);
	return R_NilValue;
}

SEXP do_box(SEXP call, SEXP op, SEXP args, SEXP env)
{
	int bty, btysave, col, colsave, lty, ltysave, xpdsave;

	checkArity(op, args);

	if(isNull(CAR(args))) bty = GP->bty;
	else {
		if(isString(CAR(args)) && LENGTH(CAR(args)) == 1)
			bty = CHAR(STRING(CAR(args))[0])[0];
		else errorcall(call, "invalid box type\n");
		switch(bty) {
		case 'o':
		case 'l':
		case '7':
		case 'c':
		case 'n':
			break;
		default:
			errorcall(call, "invalid box type\n");
		}
	}
	args = CDR(args);


	if(isNull(CAR(args))) lty = GP->lty;
	else lty = LTYpar(CAR(args), 0);
	args = CDR(args);

	if(isNull(CAR(args))) col = GP->fg;
	else col = RGBpar(CAR(args), 0);
	args = CDR(args);

	btysave = GP->bty;
	colsave = GP->col;
	ltysave = GP->lty;
	xpdsave = GP->xpd;
	GP->bty = bty;
	GP->col = col;
	GP->lty = lty;
	GP->xpd = 1;

	GMode(1);
	GBox();
	GMode(0);

	GP->bty = btysave;
	GP->col = colsave;
	GP->lty = ltysave;
	GP->xpd = xpdsave;

	return R_NilValue;
}


SEXP do_locator(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP x, y, nobs, ans;
	int i, n;
	
	checkArity(op, args);
	n = asInteger(CAR(args));
	if(n <= 0 || n == NA_INTEGER)
		error("invalid number of points in locator\n");
	PROTECT(x = allocVector(REALSXP, n));
	PROTECT(y = allocVector(REALSXP, n));
	PROTECT(nobs=allocVector(INTSXP,1));
	i = 0;
	
	GMode(2);
	while(i < n) {
		if(!GLocator(&(REAL(x)[i]), &(REAL(y)[i]), 1))
			break;
		i += 1;
	}
	GMode(0);
	INTEGER(nobs)[0] = i;
	while(i < n) {
		REAL(x)[i] = NA_REAL;
		REAL(y)[i] = NA_REAL;
		i += 1;
	}
	ans = allocList(3);
	UNPROTECT(3);
	CAR(ans) = x;
	CADR(ans) = y;
	CADDR(ans) = nobs;
	return ans;
}

#define THRESHOLD	0.25

#ifdef Macintosh
double hypot(double x, double y)
{
	return sqrt(x*x+y*y);
}
#endif

SEXP do_identify(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP ans, x, y, l, ind, pos;
	double xi, yi, xp,  yp, d, dmin, offset;
	int i, imin, k, n;

	checkArity(op, args);
	x = CAR(args);
	y = CADR(args);
	l = CADDR(args);
	if(!isReal(x) || !isReal(y) || !isString(l))
		errorcall(call, "incorrect argument type\n");
	if(LENGTH(x) != LENGTH(y) || LENGTH(x) != LENGTH(l))
		errorcall(call, "different argument lengths\n");
	n = LENGTH(x);
	if(n <= 0) {
		R_Visible = 0;
		return NULL;
	}

	offset = xChartoInch(0.5);
	PROTECT(ind = allocVector(LGLSXP, n));
	PROTECT(pos = allocVector(INTSXP, n));
	for(i=0 ; i<n ; i++)
		LOGICAL(ind)[i] = 0;

	k = 0;
	GMode(2);
	while(k < n) {
		if(!GLocator(&xp, &yp, 0)) break;
		dmin = DBL_MAX;
		imin = -1;
		for(i=0 ; i<n ; i++) {
			xi = xt(REAL(x)[i]);
			yi = yt(REAL(y)[i]);
			if(xi == NA_REAL || yi == NA_REAL) continue;
			d = hypot(xFigtoInch(xp-XMAP(xi)), yFigtoInch(yp-YMAP(yi)));
			if(d < dmin) {
				imin = i;
				dmin = d;
			}
		}
		if(dmin > THRESHOLD)
			REprintf("warning: no point with %.2f inches\n", THRESHOLD);
		else if(LOGICAL(ind)[imin])
			REprintf("warning: nearest point already identified\n");
		else {
			LOGICAL(ind)[imin] = 1;
			xi = XMAP(xt(REAL(x)[imin]));
			yi = YMAP(yt(REAL(y)[imin]));
			if(fabs(xFigtoInch(xp-xi)) >= fabs(yFigtoInch(yp-yi))) {
				if(xp >= xi) {
					INTEGER(pos)[imin] = 4;
					xi = xi+xInchtoFig(offset);
					GText(xi, yi, CHAR(STRING(l)[imin]), 0.0, GP->yCharOffset, 0.0);
				}
				else {
					INTEGER(pos)[imin] = 2;
					xi = xi-xInchtoFig(offset);
					GText(xi, yi, CHAR(STRING(l)[imin]), 1.0, GP->yCharOffset, 0.0);
				}
			}
			else {
				if(yp >= yi) {
					INTEGER(pos)[imin] = 3;
					yi = yi+yInchtoFig(offset);
					GText(xi, yi, CHAR(STRING(l)[imin]), 0.5, 0.0, 0.0);
				}
				else {
					INTEGER(pos)[imin] = 1;
					yi = yi-yInchtoFig(offset);
					GText(xi, yi, CHAR(STRING(l)[imin]), 0.5, 1-(0.5-GP->yCharOffset), 0.0);
				}
			}
		}
	}
	GMode(0);
	ans = allocList(2);
	CAR(ans) = ind;
	CADR(ans) = pos;
	UNPROTECT(2);
	return ans;
}

	/* strwidth(str, units) */

SEXP do_strwidth(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP ans, str;
	int i, n, units;
	double cex, cexsave;

	checkArity(op, args);
	str = CAR(args);
	if(TYPEOF(str) != STRSXP)
		errorcall(call, "character first argument expected\n");
	args = CDR(args);

	if((units = asInteger(CAR(args))) == NA_INTEGER || units < 0)
		errorcall(call, "invalid units\n");
	args = CDR(args);

	if(isNull(CAR(args)))
		cex = GP->cex;
	else if((cex = asReal(CAR(args))) == NA_REAL || cex <= 0.0)
		errorcall(call, "invalid cex value\n");

	n = LENGTH(str);
	ans = allocVector(REALSXP, n);
	cexsave = GP->cex;
	GP->cex = cex * GP->cexbase;
	for(i=0 ; i<n ; i++)
		REAL(ans)[i] = GStrWidth(CHAR(STRING(str)[i]), units);
	GP->cex = cexsave;
	return ans;
}
