/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdio.h>
#include "MACconsole.h"


#define SAVELINES 100

/* Implementation */

static WindowRecord		stdioWindowRecord;
static WindowPtr		stdioWindow;
static Rect				stdioWindowRect = {43, 5, 200, 300};
static TEHandle			stdioTEH;

static int interrupted = 0;

extern int	R_Unnamed;
extern int	R_DirtyImage;
extern char	R_ImageName[256];

/*	Low-level stdio interface */

static int InStart;		/* We cannot change text preceding this point */
static int InFlag;		/* Set to 0 when a newline is seen */


int ReadKBD(char *buf,int bufsize)
{
	unsigned char *q;
	int n, t1;

	InStart = (**stdioTEH).teLength;
	InFlag = 0;
	do {
		EventLoop();
	}
	while (!InFlag);
	if( InFlag==2 ) {  /* we have an EOF */
		*buf++=EOF;
		*buf='\0';
		return(1);
	}
	q = (unsigned char*)*TEGetText(stdioTEH) + InStart;
	t1 = n = (**stdioTEH).teLength - InStart;
	if(n > bufsize) return(0);
	while(n--) {
		if(*q == '\r') *buf = '\n';
		else *buf = *q;
		buf++;
		q++;
	}
	*buf='\0';
	InStart= (**stdioTEH).teLength;  /* set InStart to the end of the text */
	return(t1);
}

/* write to the console 
   eq seems to be used to see if there is an interrupt signalled (command-dot)
*/

int WriteConsole(char *buf,int buflen)
{
	char *p;
	int n;
	register EvQElPtr eq;

	p=buf;
	for(n=buflen ; n>0 ; n--) {
		if(*p == '\n') 
			*p = '\r';
		p++;
	}
	TEInsert(buf, buflen, stdioTEH);
	ScrollInsertPt(stdioTEH);
	InStart=(**stdioTEH).teLength;
	SetVScroll();
	return(buflen);
}


static void ScrollInsertPt(TEHandle hTE)
{
	TEPtr	pTE;
	short	nLines, linePos, lineHeight, winLines, linesDown;
	
	HLock((Handle)hTE);
	pTE = *hTE;
	lineHeight = pTE->lineHeight;
	nLines = pTE->nLines;
	winLines = (((pTE->viewRect).bottom - (pTE->viewRect).top)) / pTE->lineHeight;
	linesDown = (((pTE->viewRect).bottom - (pTE->destRect).top)) / pTE->lineHeight;
	linePos = pTE->nLines - linesDown;
	if ((**hTE).teLength > 0 && (*((**hTE).hText))[(**hTE).teLength-1]=='\r') {
		nLines++;
		linePos++;
	}
	if(nLines > winLines)
		TEScroll(0, -linePos*lineHeight, hTE);
	HUnlock((Handle)hTE);
}

static void doStdioCursor(void)
{
	Point mousePt;
	TEIdle(stdioTEH);
	GetMouse(&mousePt);
	if(PtInRect(mousePt, &((**stdioTEH).viewRect)))
		SetCursor(*iBeam);
	else
		SetCursor(&qd.arrow);
}

static void doStdioKey(int theChar, EventRecord *theEvent)
{
	/* cursor motion stuff here (arrow keys etc) */
	
	if((**stdioTEH).selStart < InStart) {
		SysBeep(2);
	}
	else if(theChar == '\r') {
		int cutLines;
		InFlag = 1;
		cutLines = (**stdioTEH).nLines - SAVELINES;
		if(cutLines >= 0) {
			InStart -= (**stdioTEH).lineStarts[cutLines];
			TESetSelect(0, (**stdioTEH).lineStarts[cutLines], stdioTEH);
			TEDelete(stdioTEH);
		}
		TESetSelect((**stdioTEH).teLength, (**stdioTEH).teLength, stdioTEH);
		TEKey(theChar, stdioTEH);
		ScrollInsertPt(stdioTEH);
		SetVScroll();
	}
	else if(theChar == '\b') {
		if((**stdioTEH).selStart > InStart) {
			TEKey(theChar, stdioTEH);
			ScrollInsertPt(stdioTEH);
			SetVScroll();
		}
		else SysBeep(2);
	}
	else if( theEvent->modifiers & controlKey && theChar == '\4' )
					InFlag=2;
	else {
		TEKey(theChar, stdioTEH);
		ScrollInsertPt(stdioTEH);
		SetVScroll();
	}
}

static void doPaste(void)
{
Handle	TEScrpHandle = NewHandle(0);

	if ((stdioContext.pasteLen = GetScrap(TEScrpHandle, 'TEXT', &stdioContext.pasteOfs)) > 0) {
		stdioContext.pasteH = TEScrpHandle;
		/*TEScrpHandle = NewHandle(0);*/
		stdioContext.pasteOfs = 0;
	}
	/*TEScrpLength = 0;*/
}

static void doStdioMenu(long code)
{
	int		theItem;
	Str255	name;
	
	theItem = LoWord(code);
	switch (HiWord(code)) {
		case 1:
			if(LoWord(code) == 1) {
				AboutWindow();
			}
			else {
				GetItem(appleMenu, LoWord(code), name);
				OpenDeskAcc(name);
			}
			break;
		case 2:
			switch(LoWord(code)) {
			case newCommand:		/* New */
				menuNew();
				break;
			case openCommand:		/* Open */
				menuOpen();
				break;
			case saveCommand:		/* Save */
				menuSave(1);
				break;
			case loadCommand:		/* Save as ... */
				menuLoad();
				break;
			case pageSetCommand:	/* Page Setup ... */
				SetupPrinter();
				break;
			case printCommand:		/* Print ... */
				printTE(stdioTEH);
				break;
			case quitCommand:		/* Quit */
				HiliteMenu(0);
				RCleanUp();
				break;
			}
			break;
		case 3: 
			if (SystemEdit(theItem-1) == 0) {
				switch (theItem) {
					case cutCommand:
						if((**stdioTEH).selStart < InStart)
							SysBeep(2);
						else {
							TECut(stdioTEH);
							ZeroScrap();
							TEToScrap();
						}
						break;
	
					case copyCommand:
						TECopy(stdioTEH);
						ZeroScrap();
						TEToScrap();
						break;
		
					case pasteCommand:
						if((**stdioTEH).selStart < InStart)
							SysBeep(2);
						else
							doPaste();
						break;
		
					case clearCommand:
						if((**stdioTEH).selStart < InStart)
							SysBeep(2);
						else
							TEDelete(stdioTEH);
						break;
				}
				/* ShowSelect(); */
			}
			break;
	}
	HiliteMenu(0);
}

static void doStdioGrow(WindowPtr w, Point p)
{
	GrafPtr	savePort;
	long	theResult;
	Rect	hr, vr;
	Rect 	r;
	
	GetPort(&savePort);
	SetPort(w);
	
	SetRect(&r, 80, 80, qd.screenBits.bounds.right, qd.screenBits.bounds.bottom);
	theResult = GrowWindow(w, p, &r);
	if (theResult == 0)
	  return;
	SizeWindow( w, LoWord(theResult), HiWord(theResult), true);
	SetRect(&hr, w->portRect.left-1, w->portRect.bottom-15, w->portRect.right-14, w->portRect.bottom+1);
	SetRect(&vr, w->portRect.right-15, w->portRect.top-1, w->portRect.right+1, w->portRect.bottom-14);
	HLock((Handle)stdioContext.hScroll);
	HLock((Handle)stdioContext.vScroll);
	(**stdioContext.hScroll).contrlRect = hr;
	(**stdioContext.vScroll).contrlRect = vr;
	HUnlock((Handle)stdioContext.hScroll);
	HUnlock((Handle)stdioContext.vScroll);
	EraseRect(&w->portRect);
	InvalRect(&w->portRect);
	SetView(w);
	SetVScroll();
	AdjustText();
	SetPort(savePort);
}

static	ControlActionUPP	theAction = NULL;
static void doStdioContent(WindowPtr theWindow, EventRecord *theEvent)
{
	int				cntlCode;
	ControlHandle 	theControl;
	int				pageSize;
	GrafPtr			savePort;
	
	
	GetPort(&savePort);
	SetPort(theWindow);

	GlobalToLocal(&theEvent->where);
	if ((cntlCode = FindControl(theEvent->where, theWindow, &theControl)) == 0) {
		if (PtInRect(theEvent->where, &(**stdioTEH).viewRect))
			TEClick(theEvent->where, (theEvent->modifiers & shiftKey)!=0, stdioTEH);
	} else if (cntlCode == inThumb) {
		TrackControl(theControl, theEvent->where, 0L);
		AdjustText();
	} else
		{
		if( theAction == NULL )
			theAction = NewControlActionProc(ScrollProc); /* JRH - PPC 21/11/95 */
		TrackControl(theControl, theEvent->where, theAction);
		}
	SetPort(savePort);
}


static void doStdioActive(EventRecord *theEvent, WindowPtr theWindow, short windowCode)
{
	/*
	GrafPtr	savePort;
	
	GetPort(&savePort);
	*/
	SetPort(theWindow);
	switch(windowCode) {
		case inContent:
			doStdioContent(theWindow, theEvent);
			break;
		case inDrag:
			DragWindow(theWindow, theEvent->where, &dragRect);
			break;
		case inGrow:
			doStdioGrow(theWindow, theEvent->where);
			break;
		case inSysWindow:
			SystemClick(theEvent, theWindow);
			break;
	}
	/*
	SetPort(savePort);
	*/
}


static void doStdioInactive(EventRecord *theEvent, WindowPtr theWindow, short windowCode)
{
	switch(windowCode) {
		case inContent:
			SelectWindow(theWindow);
			break;
		case inDrag:
			DragWindow(theWindow, theEvent->where, &dragRect);
			break;
		case inSysWindow:
			SystemClick(theEvent, theWindow);
			break;
	}
}

static void doStdioNotWindow(EventRecord *theEvent, WindowPtr theWindow, short windowCode)
{
	switch(windowCode) {
		case inMenuBar:
			doStdioMenu(MenuSelect(theEvent->where));
			break;
		case inDesk:
			SystemClick(theEvent, theWindow);
			break;
	}
}

static void doStdioUpdate(WindowPtr theWindow)
{
	GrafPtr	savePort;
	
	GetPort(&savePort);
	SetPort(theWindow);
	BeginUpdate(theWindow);
	EraseRect(&theWindow->portRect);
	DrawControls(theWindow);
	DrawGrowIcon(theWindow);
	TEUpdate(&theWindow->portRect, stdioTEH);
	EndUpdate(theWindow);
	SetPort(savePort);
}

static void doStdioActivate(int theCode)
{
	if(theCode) {
		SetPort(stdioWindow);

		TEActivate(stdioTEH);
		ShowControl(stdioContext.vScroll);
		ShowControl(stdioContext.hScroll);
		TEFromScrap();
		
		EnableItem(fileMenu, newCommand);
		EnableItem(fileMenu, openCommand);
		EnableItem(fileMenu, saveCommand);
		EnableItem(fileMenu, loadCommand);
		EnableItem(fileMenu, pageSetCommand);
		EnableItem(fileMenu, printCommand);
		EnableItem(fileMenu, quitCommand);

		DisableItem(editMenu, undoCommand);
		EnableItem(editMenu, cutCommand);
		EnableItem(editMenu, copyCommand);
		EnableItem(editMenu, pasteCommand);
		EnableItem(editMenu, clearCommand);
	}
	else {
		TEDeactivate(stdioTEH);
		HideControl(stdioContext.vScroll);
		HideControl(stdioContext.hScroll);
		ZeroScrap();
		TEToScrap();
	}
	DrawGrowIcon(stdioWindow);
}


static TEClickLoopUPP theClickLoop = NULL;
void InitStdioConsole(Str255 title, int rows, int columns, WindowContext *theContext)
{
	Rect bounds, rect;
	FontInfo info;

	stdioWindow = NewWindow(&stdioWindowRecord, &stdioWindowRect, title,
							0, 0, (WindowPtr)-1L, 0, 0);
	SetPort(stdioWindow);
	TextFont(monaco);
	TextSize(9);
	GetFontInfo(&info);
	stdioContext.fontHeight = info.ascent + info.descent + info.leading;
	stdioContext.fontWidth = info.widMax;
	bounds.top = 0;
	bounds.left = 0;
	bounds.bottom = rows * stdioContext.fontHeight + 8 + 16;
	bounds.right = columns * stdioContext.fontWidth + 8 + 16;
	SizeWindow(stdioWindow, bounds.right, bounds.bottom, 0);
	
	rect = (*stdioWindow).portRect;
	rect.left = rect.right-15;
	rect.right += 1;
	rect.bottom -= 14;
	rect.top -= 1;
	stdioContext.vScroll = NewControl(stdioWindow, &rect, "\p", 1, 0, 0, 0, scrollBarProc, 0L);

	rect = (*stdioWindow).portRect;
	rect.top = rect.bottom-15;
	rect.bottom += 1;
	rect.right -= 14;
	rect.left -= 1;
	stdioContext.hScroll = NewControl(stdioWindow, &rect, "\p", 1, 0, 0, 512, scrollBarProc, 0L);
		
	rect = qd.thePort->portRect;
	rect.right -= SBarWidth;
	rect.bottom -= SBarWidth;
	InsetRect(&rect, 4, 4);
	stdioTEH = TENew(&rect, &rect);
	(**stdioTEH).crOnly = -1;
	if( theClickLoop == NULL )
		theClickLoop = NewTEClickLoopProc(CClikLoop);	
	SetClikLoop(theClickLoop, stdioTEH);
	
	stdioContext.active = 1;
	stdioContext.theWindow = stdioWindow;
	stdioContext.theTEH = stdioTEH;
	stdioContext.lines = rows;
	stdioContext.cols = columns;
	
	stdioContext.doCursor = doStdioCursor;
	stdioContext.doKey = doStdioKey;
	stdioContext.doMenu = doStdioMenu;
	stdioContext.doActive = doStdioActive;
	stdioContext.doInactive = doStdioInactive;
	stdioContext.doNotWindow = doStdioNotWindow;
	stdioContext.doUpdate = doStdioUpdate;
	stdioContext.doActivate = doStdioActivate;
	
	SetView(stdioWindow);
	ShowWindow(stdioWindow);
	DrawControls(stdioWindow);
	DrawGrowIcon(stdioWindow);
}
