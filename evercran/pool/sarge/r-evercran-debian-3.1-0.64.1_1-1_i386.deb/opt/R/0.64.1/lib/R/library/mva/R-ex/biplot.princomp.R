###--- >>> `biplot.princomp' <<<----- Biplot for Principal Components

	## alias	 help(biplot.princomp)

##___ Examples ___:

data(crimes)
biplot(princomp(crimes))

## Keywords: 'multivariate', 'hplot'.


