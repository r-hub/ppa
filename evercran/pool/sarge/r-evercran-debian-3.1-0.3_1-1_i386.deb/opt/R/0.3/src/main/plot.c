/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995, 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"
#include "Graphics.h"

	/* Coordinate Mappings */
	/* Linear/Logarithmic Scales */

static double (*xt) (double);
static double (*yt) (double);

static double Log10(double x)
{
	return (x == NA_REAL || x <= 0.0) ? NA_REAL : log10(x);
}

static double Ident(double x)
{
	return x;
}


/* Device Startup */
SEXP do_device(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP s;
	char *device;
	int i, ncpars, nnpars;
	char *cpars[20];
	double *npars;

	/* NO GARBAGE COLLECTS ALLOWED HERE*/
	/* WE ARE USING REAL POINTERS */
	/* SWITCH TO RALLOCING IF NECESSARY */

	checkArity(op, args);

	s = CAR(args);
	if (!isString(s) || length(s) <= 0)
		errorcall(call, "device name must be a character string\n");
	device = CHAR(STRING(s)[0]);

	s = CADR(args);
	if (!isString(s) || length(s) > 20)
		errorcall(call, "invalid device driver parameters\n");
	ncpars = LENGTH(s);
	for(i=0 ; i<LENGTH(s) ; i++)
		cpars[i] = CHAR(STRING(s)[i]);

	s = CADDR(args);
	if (!isReal(CADDR(args)))
		errorcall(call, "device name must be a character string\n");
	nnpars = LENGTH(s);
	npars = REAL(s);

	if (!SetDevice(device, cpars, ncpars, npars, nnpars))
		errorcall(call, "unable to start device %s\n", device);

	xt = Ident;
	yt = Ident;
	R_Visible = 0;
	return CAR(args);
}

SEXP do_plot_range(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP sx;
	double *x, xmin, xmax;
	int i, nx;

	checkArity(op, args);
	if (!isNumeric(CAR(args)))
		internalTypeCheck(call, CAR(args), REALSXP);
	PROTECT(sx = coerceVector(CAR(args), REALSXP));
	x = REAL(sx);
	nx = LENGTH(sx);
	xmin = DBL_MAX;
	xmax = -DBL_MAX;
	for (i = 0; i < nx; i++)
		if (x[i] != NA_REAL) {
			if (x[i] < xmin)
				xmin = x[i];
			if (x[i] > xmax)
				xmax = x[i];
		}
	if (xmax < xmin)
		errorcall(call, "no non-missing values\n");
	sx = allocVector(REALSXP, 2);
	UNPROTECT(1);
	REAL(sx)[0] = xmin;
	REAL(sx)[1] = xmax;
	return sx;
}

SEXP do_plot_new(SEXP call, SEXP op, SEXP args, SEXP env)
{
	GNewPlot();
	DP->xlog = GP->xlog = 0;
	DP->ylog = GP->ylog = 0;
	xt = Ident;
	yt = Ident;
	R_Visible = 0;
	return R_NilValue;
}


SEXP do_plot_setup(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP xdata, ydata, xlim, ylim, log;
	double *x, *y, xmin, xmax, ymin, ymax;
	int i, nx, ny;
	char *p;

	checkArity(op, args);

	xdata = CAR(args);
	if (!isNull(xdata)) {
		internalTypeCheck(call, xdata, REALSXP);
		nx = LENGTH(xdata);
	}
	else nx = 0;
	args = CDR(args);

	ydata = CAR(args);
	if (!isNull(ydata)) {
		internalTypeCheck(call, ydata, REALSXP);
		ny = LENGTH(ydata);
	}
	else ny = 0;
	args = CDR(args);

	if (nx != ny)
		errorcall(call, "x and y data lengths differ\n");

	xlim = CAR(args);
	args = CDR(args);
	if (!isNull(xlim)) {
		internalTypeCheck(call, xlim, REALSXP);
		if (LENGTH(xlim) != 2)
			errorcall(call, "incorrect length for xlim\n");
	}
	else if (nx == 0)
		errorcall(call, "no data to compute x limits\n");

	ylim = CAR(args);
	args = CDR(args);
	if (!isNull(ylim)) {
		internalTypeCheck(call, ylim, REALSXP);
		if (LENGTH(ylim) != 2)
			errorcall(call, "incorrect length for ylim\n");
	}
	else if (ny == 0)
		errorcall(call, "no data to compute y limits\n");

	log = CAR(args);
	if (!isString(log))
		error("invalid \"log=\" specification\n");
	p = CHAR(STRING(log)[0]);
	while (*p) {
		switch (*p) {
		case 'x':
			DP->xlog = GP->xlog = 1;
			xt = Log10;
			break;
		case 'y':
			DP->ylog = GP->ylog = 1;
			yt = Log10;
			break;
		default:
			error("invalid \"log=\" specification\n");
		}
		p++;
	}

	if (isNull(xlim) || isNull(ylim)) {
		x = REAL(xdata);
		y = REAL(ydata);
		xmin = DBL_MAX;
		xmax = -DBL_MAX;
		ymin = DBL_MAX;
		ymax = -DBL_MAX;
		for (i = 0; i < nx; i++) {
			if (xt(x[i]) != NA_REAL && yt(y[i]) != NA_REAL) {
				if (x[i] < xmin) xmin = x[i];
				if (y[i] < ymin) ymin = y[i];
				if (x[i] > xmax) xmax = x[i];
				if (y[i] > ymax) ymax = y[i];
			}
		}
		if (xmin > xmax)
			errorcall(call, "no data to compute plot limits\n");
	}
	if (!isNull(xlim)) {
		xmin = REAL(xlim)[0];
		xmax = REAL(xlim)[1];
	}
	if (!isNull(ylim)) {
		ymin = REAL(ylim)[0];
		ymax = REAL(ylim)[1];
	}

		/* Arguments all checked */
		/* Go for it */

	GScale(xmin, xmax, 1);
	GScale(ymin, ymax, 2);
	GMapping(0);
	GMapWin2Fig();
	R_Visible = 0;
	return R_NilValue;
}

SEXP do_axis(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP at, lab;
	int colsave, i, ltysave, n, nc, which, xpdsave;
	double cexsave, x, y, xc, yc, xtk, ytk, tnew, tlast, cwid;

	checkArity(op, args);

	which = asInteger(CAR(args));
	if (which < 1 || which > 4)
		errorcall(call, "invalid axis number\n");
	internalTypeCheck(call, at = CADR(args), REALSXP);
	internalTypeCheck(call, lab = CADDR(args), STRSXP);
	if (LENGTH(at) != LENGTH(lab))
		errorcall(call, "location and label lengths differ\n");
	n = LENGTH(at);

		/* Compute the ticksize in NDC units */

	xc = fabs(GP->mex * GP->cra[1] * GP->asp / GP->fig2dev.bx);
	yc = fabs(GP->mex * GP->cra[1] / GP->fig2dev.by);
	xtk = 0.5 * xc;
	ytk = 0.5 * yc;
	x = GP->plt[0];
	y = GP->plt[2];

		/* Axes are always solid and in the standard */
		/* foreground color and with standard size annotations. */
		/* Save the current line type */

	cexsave = GP->cex;
	colsave = GP->col;
	ltysave = GP->lty;
	xpdsave = GP->xpd;
	/* GP->cex = 1.0; */
	GP->col = GP->fg;
	GP->lty = LTY_SOLID;
	GP->xpd = 1;

	GMode(1);
	switch (which) {
	case 1:
	case 3:
		if (which == 3) {
			y = GP->plt[3];
			ytk = -ytk;
		}
		GStartPath();
		GMoveTo(XMAP(xt(REAL(at)[0])), y);
		GLineTo(XMAP(xt(REAL(at)[n - 1])), y);
		for (i = 0; i < n; i++) {
			x = XMAP(xt(REAL(at)[i]));
			if (GP->plt[0] <= x && x <= GP->plt[1]) {
				GMoveTo(x, y);
				GLineTo(x, y - ytk);
			}
		}
		GEndPath();
		y = (which == 1) ? GP->plt[2] - 1.5 * yc : GP->plt[3] + 1.5 * yc;
		tlast = 0.0;
		cwid = GP->cex * fabs(GP->cra[0] / GP->ndc2dev.bx);
		for (i = 0; i < n; i++) {
			x = XMAP(xt(REAL(at)[i]));
			nc = strlen(CHAR(STRING(lab)[i]));
			tnew = x - 0.5 * (nc + 1) * cwid;
			if (tnew > tlast) {
				GMoveTo(x, y);
				GText(CHAR(STRING(lab)[i]), 0.5, 0.5);
				tlast = x + 0.5 * (nc + 1) * cwid;
			}
		}
		break;
	case 2:
	case 4:
		if (which == 4) {
			x = GP->plt[1];
			xtk = -xtk;
		}
		GStartPath();
		GMoveTo(x, YMAP(yt(REAL(at)[0])));
		GLineTo(x, YMAP(yt(REAL(at)[n - 1])));
		for (i = 0; i < n; i++) {
			y = YMAP(yt(REAL(at)[i]));
			if (GP->plt[2] <= y && y <= GP->plt[3]) {
				GMoveTo(x, y);
				GLineTo(x - xtk, y);
			}
		}
		GEndPath();
		x = (which == 2) ? GP->plt[0] - 1.0 * xc : GP->plt[1] + 2.0 * xc;
		tlast = 0.0;
		cwid = GP->cex * fabs(GP->cra[0] / GP->ndc2dev.by);
		for (i = 0; i < n; i++) {
			y = YMAP(yt(REAL(at)[i]));
			nc = strlen(CHAR(STRING(lab)[i]));
			tnew = y - 0.5 * (nc + 1) * cwid;
			if (tnew > tlast) {
				GMoveTo(x, y);
				GRText(CHAR(STRING(lab)[i]), 0.5, 0.0, 90.0);
				tlast = y + 0.5 * (nc + 1) * cwid;
			}
		}
		break;
	}
	GP->cex = cexsave;
	GP->col = colsave;
	GP->lty = ltysave;
	GP->xpd = xpdsave;
	GMode(0);
	R_Visible = 0;
	return R_NilValue;
}

SEXP do_plot_content(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP sxy, sx, sy, pch, col;
	char pchar[2];
	double *x, *y, xold, yold, xx, yy;
	int i, n, npch, ncol, colsave, symbol;
	rcolor *cols;

	checkArity(op, args);
	sxy = CAR(args);
	if (!isList(sxy) || length(sxy) < 2)
		errorcall(call, "invalid plotting structure\n");
	internalTypeCheck(call, sx = CAR(sxy), REALSXP);
	internalTypeCheck(call, sy = CADR(sxy), REALSXP);
	x = REAL(sx);
	y = REAL(sy);
	if (LENGTH(sx) != LENGTH(sy))
		error("x and y lengths differ for plot\n");
	n = LENGTH(sx);

	if ((pch = CADR(args)) != R_NilValue) {
		if (isVector(pch)) {
			if (isNumeric(pch)) {
				pch = CADR(args) = coerceVector(pch, INTSXP);
				symbol = 1;
			}
			else {
				pch = CADR(args) = coerceVector(pch, STRSXP);
				symbol = 0;
			}
		}
		else
			internalTypeCheck(call, pch, STRSXP);
		npch = LENGTH(pch);
	}
	else
		npch = 0;

	if (symbol && npch == 0)
		symbol = 0;

	if(!isInteger(col=CADDR(args)))
		error("invalid rgb color description\n");
	ncol = LENGTH(col);
	if (ncol == 0)
		cols = &GP->col;
	else
		cols = (rcolor*)INTEGER(col);
	colsave = GP->col;

	GMode(1);

	if (GP->type == 'p' || GP->type == 'b' || GP->type == 'o') {
		pchar[0] = GP->pch;
		pchar[1] = '\0';
		for (i = 0; i < n; i++) {
			xx = xt(x[i]);
			yy = yt(y[i]);
			if (xx != NA_REAL && yy != NA_REAL) {
				GMoveTo(XMAP(xx), YMAP(yy));
				if (ncol && cols[i % ncol] != NA_INTEGER)
					GP->col = cols[i % ncol];
				if (symbol) {
					GSymbol(INTEGER(pch)[i % npch]);
				}
				else {
					if (npch)
						pchar[0] = CHAR(STRING(pch)[i % npch])[0];
					GText(pchar, GP->xCharOffset, GP->yCharOffset);
				}
				GP->col = colsave;
			}
		}
	}

	if (GP->type == 'l' || GP->type == 'b') {
		if (ncol && cols[0] != NA_INTEGER)
			GP->col = cols[0];
		xold = NA_REAL;
		yold = NA_REAL;
		GStartPath();
		for (i = 0; i < n; i++) {
			xx = xt(x[i]);
			yy = yt(y[i]);
			if (xold != NA_REAL && yold != NA_REAL && xx != NA_REAL && yy != NA_REAL) {
				GLineTo(XMAP(xx), YMAP(yy));
			}
			else if (xx != NA_REAL && yy != NA_REAL)
				GMoveTo(XMAP(xx), YMAP(yy));
			xold = xx;
			yold = yy;
		}
		GEndPath();
	}

	if (GP->type == 's') {
		if (cols[0] != NA_INTEGER && cols[0] >= 0)
			GP->col = cols[0];
		xold = xt(x[0]);
		yold = xt(y[0]);
		GStartPath();
		if (xold != NA_REAL && yold != NA_REAL)
			GMoveTo(XMAP(xold), YMAP(yold));
		for (i = 1; i < n; i++) {
			xx = xt(x[i]);
			yy = yt(y[i]);
			if (xold != NA_REAL && yold != NA_REAL && xx != NA_REAL && yy != NA_REAL) {
				GLineTo(XMAP(xx), YMAP(yold));
				GLineTo(XMAP(xx), YMAP(yy));
			}
			else if (x[i] != NA_REAL && y[i] != NA_REAL)
				GMoveTo(XMAP(xx), YMAP(yy));
			xold = xx;
			yold = yy;
		}
		GEndPath();
	}

	if (GP->type == 'S') {
		if (cols[0] != NA_INTEGER && cols[0] >= 0)
			GP->col = cols[0];
		xold = xt(x[0]);
		yold = xt(y[0]);
		GStartPath();
		if (xold != NA_REAL && yold != NA_REAL)
			GMoveTo(XMAP(xold), YMAP(yold));
		for (i = 1; i < n; i++) {
			xx = xt(x[i]);
			yy = yt(y[i]);
			if (xold != NA_REAL && yold != NA_REAL && xx != NA_REAL && yy != NA_REAL) {
				GLineTo(XMAP(xold), YMAP(yy));
				GLineTo(XMAP(xx), YMAP(yy));
			}
			else if (x[i] != NA_REAL && y[i] != NA_REAL)
				GMoveTo(XMAP(xx), YMAP(yy));
			xold = xx;
			yold = yy;
		}
		GEndPath();
	}

	if (GP->type == 'h') {
		if (cols[0] != NA_INTEGER && cols[0] >= 0)
			GP->col = cols[0];
		for (i = 0; i < n; i++) {
			xx = xt(x[i]);
			yy = yt(y[i]);
			if (xx != NA_REAL && yy != NA_REAL) {
				GStartPath();
				GMoveTo(XMAP(xx), YMAP(yt(0.0)));
				GLineTo(XMAP(xx), YMAP(yy));
				GEndPath();
			}
		}
	}

	GMode(0);
	GP->col = colsave;
	R_Visible = 0;
	return R_NilValue;
}

static void xypoints(SEXP call, SEXP args, int *n)
{
	int k;

	if (!isNumeric(CAR(args)) || (k = LENGTH(CAR(args))) <= 0)
		errorcall(call, "first argument invalid\n");
	CAR(args) = coerceVector(CAR(args), REALSXP);
	*n = k;
	args = CDR(args);

	if (!isNumeric(CAR(args)) || (k = LENGTH(CAR(args))) <= 0)
		errorcall(call, "second argument invalid\n");
	CAR(args) = coerceVector(CAR(args), REALSXP);
	if (k > *n) *n = k;
	args = CDR(args);

	if (!isNumeric(CAR(args)) || (k = LENGTH(CAR(args))) <= 0)
		errorcall(call, "third argument invalid\n");
	CAR(args) = coerceVector(CAR(args), REALSXP);
	if (k > *n) *n = k;
	args = CDR(args);

	if (!isNumeric(CAR(args)) || (k = LENGTH(CAR(args))) <= 0)
		errorcall(call, "fourth argument invalid\n");
	CAR(args) = coerceVector(CAR(args), REALSXP);
	if (k > *n) *n = k;
	args = CDR(args);
}

/* segments(x0, y0, x1, y1, col, lty) */

SEXP do_segments(SEXP call, SEXP op, SEXP args, SEXP env)
{
	double *x0, *x1, *y0, *y1;
	int nx0, nx1, ny0, ny1;
	int i, n, ncol, colsave, nlty, ltysave;
	int *col, *lty;

	checkArity(op, args);

	xypoints(call, args, &n);

	x0 = REAL(CAR(args)); nx0 = LENGTH(CAR(args)); args = CDR(args);
	y0 = REAL(CAR(args)); ny0 = LENGTH(CAR(args)); args = CDR(args);
	x1 = REAL(CAR(args)); nx1 = LENGTH(CAR(args)); args = CDR(args);
	y1 = REAL(CAR(args)); ny1 = LENGTH(CAR(args)); args = CDR(args);

	if(!isInteger(CAR(args)))
		errorcall(call, "invalid rgb color\n");
	if(LENGTH(CAR(args)) >= 1) {
		ncol = LENGTH(CAR(args));
		col = INTEGER(CAR(args));
	}
	else {
		ncol = 1;
		col = (int*)&GP->fg;
	}
	args = CDR(args);

	if(!isInteger(CAR(args)))
		errorcall(call, "invalid line type\n");
	if(LENGTH(CAR(args)) >= 1) {
		nlty = LENGTH(CAR(args));
		lty = INTEGER(CAR(args));
	}
	else {
		nlty = 1;
		lty = (int*)&GP->lty;
	}

	colsave = GP->col;
	ltysave = GP->lty;
	GMode(1);
	for (i = 0; i < n; i++) {
		if (x0[i % nx0] != NA_REAL && y0[i % ny0] != NA_REAL
		    && x1[i % nx1] != NA_REAL && y1[i % ny1] != NA_REAL) {
			if (ncol && col[i % ncol] != NA_INTEGER) {
				GP->col = col[i % ncol];
			}
			else GP->col = colsave;
			if (nlty && lty[i % nlty] != NA_INTEGER) {
				GP->lty = lty[i % nlty];
			}
			else GP->lty = ltysave;
			GStartPath();
			GMoveTo(XMAP(x0[i % nx0]), YMAP(y0[i % ny0]));
			GLineTo(XMAP(x1[i % nx1]), YMAP(y1[i % ny1]));
			GEndPath();
		}
	}
	GMode(0);
	GP->col = colsave;
	GP->lty = ltysave;
	R_Visible = 0;
	return R_NilValue;
}

SEXP do_rect(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP sxl, sxr, syb, syt;
	double *xl, *xr, *yb, *yt;
	int i, n, nxl, nxr, nyb, nyt, ncol, colsave, border;
	int *col;

	checkArity(op, args);

	if (!isNumeric(CAR(args)) || (nxl = LENGTH(CAR(args))) <= 0)
		errorcall(call, "first argument invalid\n");
	CAR(args) = coerceVector(CAR(args), REALSXP);
	sxl = CAR(args);
	n = nxl;
	args = CDR(args);

	if (!isNumeric(CAR(args)) || (nyb = LENGTH(CAR(args))) <= 0)
		errorcall(call, "second argument invalid\n");
	CAR(args) = coerceVector(CAR(args), REALSXP);
	syb = CAR(args);
	if (nyb > n)
		n = nyb;
	args = CDR(args);

	if (!isNumeric(CAR(args)) || (nxr = LENGTH(CAR(args))) <= 0)
		errorcall(call, "third argument invalid\n");
	CAR(args) = coerceVector(CAR(args), REALSXP);
	sxr = CAR(args);
	if (nxr > n)
		n = nxr;
	args = CDR(args);

	if (!isNumeric(CAR(args)) || (nyt = LENGTH(CAR(args))) <= 0)
		errorcall(call, "fourth argument invalid\n");
	CAR(args) = coerceVector(CAR(args), REALSXP);
	syt = CAR(args);
	if (nyt > n)
		n = nyt;
	args = CDR(args);

	if(!isInteger(CAR(args)))
		errorcall(call, "invalid rgb color\n");
	if(LENGTH(CAR(args)) >= 1) {
		ncol = LENGTH(CAR(args));
		col = INTEGER(CAR(args));
	}
	else {
		ncol = 1;
		col = (int*)&ncol;
	}
        args = CDR(args);

	if(LENGTH(CAR(args)) < 1)
		border = 1;
	else
		border = asInteger(CAR(args));

	xl = REAL(sxl);
	xr = REAL(sxr);
	yb = REAL(syb);
	yt = REAL(syt);

	colsave = GP->col;
	GMode(1);
	for (i = 0; i < n; i++) {
		if (xl[i % nxl] != NA_REAL && yb[i % nyb] != NA_REAL
		    && xr[i % nxr] != NA_REAL && yt[i % nyt] != NA_REAL)
			if (ncol && col[i % ncol] != NA_INTEGER)
				GRect(XMAP(xl[i % nxl]), YMAP(yb[i % nyb]),
				      XMAP(xr[i % nxr]), YMAP(yt[i % nyt]), col[i % ncol], border);
			else
				GRect(XMAP(xl[i % nxl]), YMAP(yb[i % nyb]),
				      XMAP(xr[i % nxr]), YMAP(yt[i % nyt]), 0, border);
	}
	GMode(0);
	GP->col = colsave;
	R_Visible = 0;
	return R_NilValue;
}

/* do_arrows(x0, y0, x1, y1, length, angle, code, col) */

SEXP do_arrows(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP sx0, sx1, sy0, sy1;
	double *x0, *x1, *y0, *y1;
	double hlen, angle;
	int i, n, nx0, nx1, ny0, ny1;
	int ncol, colsave, code;
	rcolor *col;

	checkArity(op, args);

	if (!isNumeric(CAR(args)) || (nx0 = LENGTH(CAR(args))) <= 0)
		errorcall(call, "first argument invalid\n");
	CAR(args) = coerceVector(CAR(args), REALSXP);
	sx0 = CAR(args);
	n = nx0;
	args = CDR(args);

	if (!isNumeric(CAR(args)) || (ny0 = LENGTH(CAR(args))) <= 0)
		errorcall(call, "second argument invalid\n");
	CAR(args) = coerceVector(CAR(args), REALSXP);
	sy0 = CAR(args);
	if (ny0 > n)
		n = ny0;
	args = CDR(args);

	if (!isNumeric(CAR(args)) || (nx1 = LENGTH(CAR(args))) <= 0)
		errorcall(call, "third argument invalid\n");
	CAR(args) = coerceVector(CAR(args), REALSXP);
	sx1 = CAR(args);
	if (nx1 > n)
		n = nx1;
	args = CDR(args);

	if (!isNumeric(CAR(args)) || (ny1 = LENGTH(CAR(args))) <= 0)
		errorcall(call, "fourth argument invalid\n");
	CAR(args) = coerceVector(CAR(args), REALSXP);
	sy1 = CAR(args);
	if (ny1 > n)
		n = ny1;
	args = CDR(args);

	hlen = asReal(CAR(args));
	if (hlen == NA_REAL || hlen <= 0)
		errorcall(call, "invalid head length\n");
	args = CDR(args);

	angle = asReal(CAR(args));
	if (angle == NA_REAL)
		errorcall(call, "invalid head angle\n");
	args = CDR(args);

	code = asInteger(CAR(args));
	if (code == NA_INTEGER || code < 0 || code > 3)
		errorcall(call, "invalid arrow head specification\n");

	if (isNull(CAR(args)) || LENGTH(CAR(args))<=0) {
		col = (rcolor*)&(GP->col);
		ncol = 1;
	}
	else {
		if (!isInteger(CAR(args)))
			errorcall(call, "fifth argument invalid\n");
		col = (rcolor*)INTEGER(CAR(args));
	}
	args = CDR(args);

	x0 = REAL(sx0);
	y0 = REAL(sy0);
	x1 = REAL(sx1);
	y1 = REAL(sy1);

	colsave = GP->col;
	GMode(1);
	for (i = 0; i < n; i++) {
		if (x0[i % nx0] != NA_REAL && y0[i % ny0] != NA_REAL
		    && x1[i % nx1] != NA_REAL && y1[i % ny1] != NA_REAL)
			GP->col = col[i % ncol];
		GArrow(XMAP(x0[i % nx0]), YMAP(y0[i % ny0]),
		       XMAP(x1[i % nx1]), YMAP(y1[i % ny1]),
		       hlen, angle, code);
	}
	GMode(0);
	GP->col = colsave;
	R_Visible = 0;
	return R_NilValue;
}

SEXP do_polygon(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP sx, sy;
	int border, col, colsave, nx, ny, *work;
	char *vmax;

	checkArity(op, args);

	if (!isNumeric(CAR(args)) || (nx = LENGTH(CAR(args))) <= 0)
		errorcall(call, "first argument invalid\n");
	sx = CAR(args) = coerceVector(CAR(args), REALSXP);
	args = CDR(args);

	if (!isNumeric(CAR(args)) || (ny = LENGTH(CAR(args))) <= 0)
		errorcall(call, "second argument invalid\n");
	sy = CAR(args) = coerceVector(CAR(args), REALSXP);
	args = CDR(args);

	if (ny != nx)
		errorcall(call, "x and y lengths differ in polygon");

	if(!isInteger(CAR(args)))
		errorcall(call, "invalid color\n");
	if(LENGTH(CAR(args)) <= 0)
		col = 1;
	else
		col = asInteger(CAR(args));
	args = CDR(args);

	if(LENGTH(CAR(args)) <= 0)
		border = 1;
	else
		border = asInteger(CAR(args));

	colsave = GP->col;
	GMode(1);
	vmax = vmaxget();
	work = (int*)R_alloc(2*nx, sizeof(int));
	GPolygon(nx, REAL(sx), REAL(sy), col, border, 1, work);
	vmaxset(vmax);
	GMode(0);
	GP->col = colsave;
	R_Visible = 0;
	return R_NilValue;
}

SEXP do_text(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP sx, sy, sxy, txt, pars;
	int i, n, nx, ny, ntxt;
	double *x, *y;
	double xx, yy;
	extern int setpar(SEXP pars);


	checkArity(op, args);
	sxy = CAR(args);
	if (!isList(sxy) || length(sxy) < 2)
		errorcall(call, "invalid plotting structure\n");
	internalTypeCheck(call, sx = CAR(sxy), REALSXP);
	internalTypeCheck(call, sy = CADR(sxy), REALSXP);
	internalTypeCheck(call, txt = CADR(args), STRSXP);
	if (LENGTH(txt) <= 0)
		errorcall(call, "zero length \"text\" specified\n");
	pars = CADDR(args);
	if (pars != R_NilValue)
		setpar(pars);

	x = REAL(sx);
	y = REAL(sy);
	nx = LENGTH(sx);
	ny = LENGTH(sy);
	ntxt = LENGTH(txt);
	n = (nx > ny) ? nx : ny;

	GMode(1);
	for (i = 0; i < n; i++) {
		xx = xt(x[i % nx]);
		yy = yt(y[i % ny]);
		if (xx != NA_REAL && yy != NA_REAL) {
			GMoveTo(XMAP(xx), YMAP(yy));
			GText(CHAR(STRING(txt)[i % ntxt]), GP->adj, 0.5);
		}
	}
	GMode(0);
	R_Visible = 0;
	return R_NilValue;
}

SEXP do_plot_titles(SEXP call, SEXP op, SEXP args, SEXP env)
{
	char *main, *sub, *xlab, *ylab;
	double colsave;

	checkArity(op, args);

	main = sub = xlab = ylab = NULL;

	if (CAR(args) != R_NilValue && LENGTH(CAR(args)) > 0)
		main = CHAR(STRING(CAR(args))[0]);
	args = CDR(args);

	if (CAR(args) != R_NilValue && LENGTH(CAR(args)) > 0)
		sub = CHAR(STRING(CAR(args))[0]);
	args = CDR(args);

	if (CAR(args) != R_NilValue && LENGTH(CAR(args)) > 0)
		xlab = CHAR(STRING(CAR(args))[0]);
	args = CDR(args);

	if (CAR(args) != R_NilValue && LENGTH(CAR(args)) > 0)
		ylab = CHAR(STRING(CAR(args))[0]);
	args = CDR(args);

        /* colsave = GP->col; */
        /* GP->col = GP->fg; */

	GMode(1);
	GTitles(main, sub, xlab, ylab);
	GMode(0);

	/* GP->col = colsave; */

	R_Visible = 0;
	return R_NilValue;
}

SEXP do_plot_abline(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP a, b, h, v;
	double aa, bb;
	int i, col, colsave;

	checkArity(op, args);

	a = CAR(args);
	b = CADR(args);
	h = CADDR(args);
	v = CADR(CDDR(args));
	col = asInteger(CADDR(CDDR(args)));

	colsave = GP->col;
	GP->col = col;

	if (a != R_NilValue) {
		CAR(args) = a = coerceVector(a, REALSXP);
		if (b == R_NilValue) {
			if (LENGTH(a) != 2)
				errorcall(call, "invalid a=, b= specification in \"abline\"\n");
			aa = REAL(a)[0];
			bb = REAL(a)[1];
		}
		else {
			CADR(args) = b = coerceVector(b, REALSXP);
			aa = asReal(a);
			bb = asReal(b);
		}
		if (aa == NA_REAL || bb == NA_REAL)
			errorcall(call, "\"a\" and \"b\" must be non-missing\n");
		GMode(1);
		GStartPath();
		GMoveTo(XMAP(GP->usr[0]), YMAP(aa + GP->usr[0] * bb));
		GLineTo(XMAP(GP->usr[1]), YMAP(aa + GP->usr[1] * bb));
		GEndPath();
		GMode(0);
	}
	if (h != R_NilValue) {
		CADDR(args) = h = coerceVector(h, REALSXP);
		GMode(1);
		for (i = 0; i < LENGTH(h); i++) {
			aa = yt(REAL(h)[i]);
			if (aa != NA_REAL) {
				GStartPath();
				GMoveTo(XMAP(GP->usr[0]), YMAP(aa));
				GLineTo(XMAP(GP->usr[1]), YMAP(aa));
				GEndPath();
			}
		}
		GMode(0);
	}
	if (v != R_NilValue) {
		CADR(CDDR(args)) = v = coerceVector(v, REALSXP);
		GMode(1);
		for (i = 0; i < LENGTH(v); i++) {
			aa = xt(REAL(v)[i]);
			if (aa != NA_REAL) {
				GStartPath();
				GMoveTo(XMAP(aa), YMAP(GP->usr[2]));
				GLineTo(XMAP(aa), YMAP(GP->usr[3]));
				GEndPath();
			}
		}
		GMode(0);
	}
	GP->col = colsave;
	R_Visible = 0;
	return R_NilValue;
}

SEXP do_box(SEXP call, SEXP op, SEXP args, SEXP env)
{
	int colsave, ltysave, xpdsave;

	colsave = GP->col;
	ltysave = GP->lty;
	xpdsave = GP->xpd;
	GP->col = GP->fg;
	GP->lty = LTY_SOLID;
	GP->xpd = 1;

	GMode(1);
	GBox();
	GMode(0);

	GP->col = colsave;
	GP->lty = ltysave;
	GP->xpd = xpdsave;

	R_Visible = 0;
	return R_NilValue;
}


SEXP do_locator(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP x, y, nobs, ans;
	int i, n;
	
	checkArity(op, args);
	n = asInteger(CAR(args));
	if(n <= 0 || n == NA_INTEGER)
		error("invalid number of points in locator\n");
	PROTECT(x = allocVector(REALSXP, n));
	PROTECT(y = allocVector(REALSXP, n));
	PROTECT(nobs=allocVector(INTSXP,1));
	i = 0;
	
	GMode(2);
	while(i < n) {
		if(!GLocator(&(REAL(x)[i]), &(REAL(y)[i]), 1))
			break;
		i += 1;
	}
	GMode(0);
	INTEGER(nobs)[0] = i;
	while(i < n) {
		REAL(x)[i] = NA_REAL;
		REAL(y)[i] = NA_REAL;
		i += 1;
	}
	ans = allocList(3);
	UNPROTECT(3);
	CAR(ans) = x;
	CADR(ans) = y;
	CADDR(ans) = nobs;
	return ans;
}

#define THRESHOLD	0.25

#ifdef Macintosh
double hypot(double x, double y)
{
	return sqrt(x*x+y*y);
}
#endif

SEXP do_identify(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP ans, x, y, l, ind, pos;
	double xi, yi, xp,  yp, d, dmin, offset;
	int i, imin, k, n;

	checkArity(op, args);
	x = CAR(args);
	y = CADR(args);
	l = CADDR(args);
	if(!isReal(x) || !isReal(y) || !isString(l))
		errorcall(call, "incorrect argument type\n");
	if(LENGTH(x) != LENGTH(y) || LENGTH(x) != LENGTH(l))
		errorcall(call, "different argument lengths\n");
	n = LENGTH(x);
	if(n <= 0) {
		R_Visible = 0;
		return NULL;
	}

	offset = xChartoInch(0.5);
	PROTECT(ind = allocVector(LGLSXP, n));
	PROTECT(pos = allocVector(INTSXP, n));
	for(i=0 ; i<n ; i++)
		LOGICAL(ind)[i] = 0;

	k = 0;
	GMode(2);
	while(k < n) {
		if(!GLocator(&xp, &yp, 0)) break;
		dmin = DBL_MAX;
		imin = -1;
		for(i=0 ; i<n ; i++) {
			xi = xt(REAL(x)[i]);
			yi = yt(REAL(y)[i]);
			if(xi == NA_REAL || yi == NA_REAL) continue;
			d = hypot(xFigtoInch(xp-XMAP(xi)), yFigtoInch(yp-YMAP(yi)));
			if(d < dmin) {
				imin = i;
				dmin = d;
			}
		}
		if(dmin > THRESHOLD)
			REprintf("warning: no point with %.2f inches\n", THRESHOLD);
		else if(LOGICAL(ind)[imin])
			REprintf("warning: nearest point already identified\n");
		else {
			LOGICAL(ind)[imin] = 1;
			xi = XMAP(xt(REAL(x)[imin]));
			yi = YMAP(yt(REAL(y)[imin]));
			if(fabs(xFigtoInch(xp-xi)) >= fabs(yFigtoInch(yp-yi))) {
				if(xp >= xi) {
					INTEGER(pos)[imin] = 4;
					xi = xi+xInchtoFig(offset);
					GMoveTo(xi,yi);
					GText(CHAR(STRING(l)[imin]), 0.0, GP->yCharOffset);
				}
				else {
					INTEGER(pos)[imin] = 2;
					xi = xi-xInchtoFig(offset);
					GMoveTo(xi,yi);
					GText(CHAR(STRING(l)[imin]), 1.0, GP->yCharOffset);
				}
			}
			else {
				if(yp >= yi) {
					INTEGER(pos)[imin] = 3;
					yi = yi+yInchtoFig(offset);
					GMoveTo(xi,yi);
					GText(CHAR(STRING(l)[imin]), 0.5, 0.0);
				}
				else {
					INTEGER(pos)[imin] = 1;
					yi = yi-yInchtoFig(offset);
					GMoveTo(xi,yi);
					GText(CHAR(STRING(l)[imin]), 0.5, 1-(0.5-GP->yCharOffset));
				}
			}
		}
	}
	GMode(0);
	ans = allocList(2);
	CAR(ans) = ind;
	CADR(ans) = pos;
	UNPROTECT(2);
	return ans;
}
