extern char *malloc(), *realloc();

# line 2 "gram.y"
/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995, 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"

extern SEXP listAppend(SEXP,SEXP);
void pushCmt();
void popCmt();

static int eatln;
extern SEXP R_CommentSxp;

#define YYSTYPE		SEXP
#ifdef YYBYACC
#define YYRETURN(x)	{ return(x); }
#else
#define YYRETURN(x)	{ free((void*)yys); free((void*)yyv); return(x); }
#endif

# define STR_CONST 257
# define NUM_CONST 258
# define NULL_CONST 259
# define SYMBOL 260
# define FUNCTION 261
# define LEX_ERROR 262
# define LBB 263
# define ERROR 264
# define LEFT_ASSIGN 265
# define RIGHT_ASSIGN 266
# define FOR 267
# define IN 268
# define IF 269
# define ELSE 270
# define WHILE 271
# define NEXT 272
# define BREAK 273
# define REPEAT 274
# define GT 275
# define GE 276
# define LT 277
# define LE 278
# define EQ 279
# define NE 280
# define AND 281
# define OR 282
# define LOW 283
# define UNOT 284
# define NOT 285
# define TILDE 286
# define SPECIAL 287
# define UMINUS 288
# define UPLUS 289
#define yyclearin yychar = -1
#define yyerrok yyerrflag = 0
extern int yychar;
extern int yyerrflag;
#ifndef YYMAXDEPTH
#define YYMAXDEPTH 150
#endif
#ifndef YYSTYPE
#define YYSTYPE int
#endif
YYSTYPE yylval, yyval;
# define YYERRCODE 256

# line 179 "gram.y"


SEXP tagarg(SEXP arg, SEXP tag)
{
	switch (TYPEOF(tag)) {
	case NILSXP:
	case SYMSXP:
		return lang2(arg, tag);
	case STRSXP:
		PROTECT(arg);
		PROTECT(tag);
		tag = install(CHAR(STRING(tag)[0]));
		UNPROTECT(2);
		return lang2(arg, tag);
	default:
		error("incorrect tag type\n");
	}
	/*NOTREACHED*/
}

/* Lists are created and grown using a special dotted pair. */
/* The CAR of the list points to the last cons-cell in the list */
/* and the CDR points to the first.  The list can be extracted */
/* from the pair by taking its CDR, while the CAR gives fast access */
/* to the end of the list. */

/* Create a stretchy-list dotted pair */

SEXP newlist(void)
{
	SEXP s = CONS(R_NilValue, R_NilValue);
	CAR(s) = s;
	return s;
}

/* Add a new element at the end of a stretchy list */

SEXP growlist(SEXP l, SEXP s)
{
	SEXP tmp;
	PROTECT(l);
	tmp = CONS(s, R_NilValue);
	UNPROTECT(1);
	SETCDR(CAR(l), tmp);
	CAR(l) = tmp;
	return l;
}

/* Functions to handle comments */
/* R_CommentSxp is of the same form as an expression list, */
/* each time a new { is encountered a new element is placed */
/* in the R_CommentSxp and when a } is encountered it is removed.  */

extern void ResetComment()
{
	R_CommentSxp = newlist();
}

void pushCmt()
{
	R_CommentSxp = growlist(R_CommentSxp, R_NilValue);
}

void popCmt()
{
	SEXP tmp;

	for (tmp = CDR(R_CommentSxp); tmp != CAR(R_CommentSxp); tmp = CDR(tmp));
	CAR(R_CommentSxp) = tmp;
}

int isComment(SEXP l)
{
	if (isList(l) && isString(CAR(l)) && !strncmp(CHAR(STRING(CAR(l))[0]), "#", 1))
		return 1;
	else
		return 0;
}

void addcomment(SEXP l)
{
	SEXP tcmt;

	tcmt = CAR(CAR(R_CommentSxp));
	if (tcmt == R_NilValue)
		return;
	if ((isList(l) || isLanguage(l)) && !(l == R_NilValue))
		if (TAG(l) == R_NilValue)
			TAG(l) = tcmt;
		else if (isComment(TAG(l))) {
			PROTECT(l);
			TAG(l) = listAppend(TAG(l), tcmt);
			UNPROTECT(1);
		}
		else
			error("problem in addcomment");
	CAR(CAR(R_CommentSxp)) = R_NilValue;
}

SEXP firstarg(SEXP s, SEXP tag)
{
	SEXP tmp;
	PROTECT(s);
	PROTECT(tag);
	tmp = newlist();
	tmp = growlist(tmp, s);
	TAG(CAR(tmp)) = tag;
	UNPROTECT(2);
	return tmp;
}

SEXP nextarg(SEXP l, SEXP s, SEXP tag)
{
	PROTECT(tag);
	l = growlist(l, s);
	TAG(CAR(l)) = tag;
	UNPROTECT(1);
	return l;
}


SEXP mkString(char *);
SEXP mkInteger(char *);
SEXP mkFloat(char *);
SEXP mkNA(void);
SEXP mkTrue(void);
SEXP mkFalse(void);


/* Lexical Analyzer:
 *
 * Basic lexical analysis is performed by the following routines.
 * Input is read a line at a time, and, if the program is in batch
 * mode, each input line is echoed to standard output after it
 * is read.
 *
 * The function yylex() scans the input, breaking it into tokens
 * which are then passed to the parser.  The lexical analyser maintains
 * a symbol table (in a very messy fashion).
 *
 * The fact that if statements need to parse differently depending on
 * whether the statement is being interpreted or part of the body of
 * a function causes the need for ifpop and ifpush. When an if statement is
 * encountered an 'i' is pushed on a stack (provided there are parentheses 
 * active). At later points this 'i' needs to be popped off of the if stack.
 */

/* #define BUFSIZE		128	---changed to MAXELTSIZE */

static char buf[MAXELTSIZE];
static char *bufp;
static int cnt = 0;
extern int ReadKBD(char *, int);

int cget()
{
	if (--cnt < 0) {
		if (R_ParseText != R_NilValue) {
			if (R_ParseCnt < LENGTH(R_ParseText)) {
				strcpy(buf, CHAR(STRING(R_ParseText)[(R_ParseCnt++)]));
				strcat(buf, "\n");
			}
			else
				return EOF;
		}
		else if (R_Console == 1) {
			if (ReadKBD(buf, MAXELTSIZE) == 0) {
				ClearerrConsole();
				return EOF;
			}
		}
		else if (fgets(buf, MAXELTSIZE, R_Inputfile) == NULL) {
			ResetConsole();
			return EOF;
		}
		bufp = buf;
		cnt = strlen(buf);
		cnt--;
	}
	return *bufp++;
}


void uncget(int n)
{
	cnt += n;
	bufp -= n;
}

static int newline = 0;
static int reset = 1;
#ifndef DEBUG_LEX
static
#endif
char *parenp, parenstack[50];

static void ifpush(void)
{
	if (*parenp == '{' || *parenp == '[' || *parenp == '(' || *parenp == 'i')
		*++parenp = 'i';
}

static void ifpop(void)
{
	if (*parenp == 'i')
		parenp--;
}

static int typeofnext(void)
{
	int k, c;

	c = cget();
	if (isdigit(c)) k = 1;
	else if (isalpha(c) || c == '.')
		k = 2;
	else
		k = 3;
	uncget(1);
	return k;
}

static int nextchar(int expect)
{
	int c = cget();

	if (c == expect)
		return 1;
	else
		uncget(1);
	return 0;
}

struct {
	char *name;
	int token;
} keywords[] = {
	{ "in",		IN		},	/*  0 */
	{ "else",	ELSE		},	/*  1 */
	{ "for",	FOR		},	/*  2 */
	{ "if",		IF		},	/*  3 */
	{ "while",	WHILE		},	/*  4 */
	{ "next",	NEXT		},	/*  5 */
	{ "break",	BREAK		},	/*  6 */
	{ "function",	FUNCTION	},	/*  7 */
	{ "NA",		NUM_CONST	},	/*  8 */
	{ "NULL",	NULL_CONST	},	/*  9 */
	{ "T",		NUM_CONST	},	/* 10 */
	{ "F",		NUM_CONST	},	/* 11 */
	{ "...",	SYMBOL		},	/* 12 (no assignment to ...) */
	{ "repeat",	REPEAT		},	/* 13 */
	{ "true",	NUM_CONST	},	/* 14 */
	{ "false",	NUM_CONST	},	/* 15 */
	{ "null",	NULL_CONST	},	/* 16 */
	{ "TRUE",	NUM_CONST	},	/* 17 */
	{ "FALSE",	NUM_CONST	},      /* 18 */
	{ 0, 0				}
};


/* klookup has side effects, it sets yylval */

int klookup(s)
char *s;
{
	int i;

	for (i = 0; keywords[i].name; i++) {
		if (strcmp(keywords[i].name, s) == 0) {
			switch (i) {
			case 0:
				eatln = 1;
				break;
			case 1:
				ifpop();
				eatln = 1;
				break;
			case 2:
			case 3:
			case 4:
			case 7:
			case 13:
				eatln = 1;
				yylval = install(s);
				break;
			case 5:
			case 6:
				eatln = 0;
				yylval = install(s);
				break;
			case 8:
				PROTECT(yylval = mkNA());
				eatln = 0;
				break;
			case 9:
			case 16:
				PROTECT(yylval = R_NilValue);
				eatln = 0;
				break;
			case 10:
			case 14:
			case 17:
				PROTECT(yylval = mkTrue());
				eatln = 0;
				break;
			case 11:
			case 15:
			case 18:
				PROTECT(yylval = mkFalse());
				eatln = 0;
				break;
			case 12:
				PROTECT(yylval = install(s));
				eatln = 0;
				break;
			}
			return keywords[i].token;
		}
	}
	return 0;
}

static void prompt()
{
	if (R_ParseText == R_NilValue && R_Console == 1)
		yyprompt(CHAR(R_options_continue));
}

SEXP mkString(char *s)
{
	SEXP t;

	PROTECT(t = allocVector(STRSXP, 1));
	STRING(t)[0] = mkChar(s);
	UNPROTECT(1);
	return t;
}

SEXP mkFloat(char *s)
{
	SEXP t = allocVector(REALSXP, 1);
	REAL(t)[0] = atof(s);
	return t;
}

SEXP mkNA(void)
{
	SEXP t = allocVector(LGLSXP, 1);
	LOGICAL(t)[0] = NA_LOGICAL;
	return t;
}

SEXP mkTrue(void)
{
	SEXP s = allocVector(LGLSXP, 1);
	LOGICAL(s)[0] = 1;
	return s;
}

SEXP mkFalse(void)
{
	SEXP s = allocVector(LGLSXP, 1);
	LOGICAL(s)[0] = 0;
	return s;
}

void yyinit(void)
{
	newline = 0;
	reset = 1;
	/* cnt = 0; */
}

int yywrap()
{
	return feof(R_Inputfile);
}       

void yyprompt(char *format, ...)
{
	va_list(ap);
#ifdef OLD
	if (DevInit)
		DevHold();      
#endif
	va_start(ap, format);
	REvprintf(format, ap);  
	va_end(ap);
	fflush(stdout);
	RBusy(0);
}

void yyerror(char *s)
{
	int i;

	R_CommentSxp = R_NilValue;
	REprintf("%s", buf);
	for (i = 1; i < bufp - buf; i++) {
		REprintf(" ");
	}
	REprintf("^\n");
	if (R_Console == 0) {
		fclose(R_Inputfile);
		ResetConsole();
	}
	else {
		FlushConsole();
		REprintf("Error: %s\n", s);
	}
	newline = 0;
	reset = 1;
	cnt = 0;
}

int yylex()
{
	SEXP f;
	int c, quote, kw;
	char *p, yytext[MAXELTSIZE];

	if (newline) {
		newline = 0;
		prompt();
	}

    again:
	if (reset) {
		parenp = parenstack;
		*parenp = ' ';
		reset = 0;
		eatln = 0;
		ResetComment();
	}

	while ((c = cget()) == ' ' || c == '\t');

	if (c == '#') {
		p = yytext;
		*p++ = c;
		while ((c = cget()) != '\n' && c != EOF)
			*p++ = c;
		*p = '\0';
		f = mkString(yytext);
		f = CONS(f, R_NilValue);
		CAR(CAR(R_CommentSxp)) = listAppend(CAR(CAR(R_CommentSxp)), f);
	}


	if (c == EOF)
		return EOF;

		/* This code deals with context sensitivity to newlines. */
		/* The main problem is finding out whether a newline is */
		/* followed by an ELSE clause.  This is only of importance */
		/* if we are inside one of (, [, or {. */

	if (c == '\n') {
		if (eatln || *parenp == '[' || *parenp == '(') {
			prompt();
			goto again;
		}
		if (*parenp == 'i') {
			prompt();
			while ((c = cget()) == ' ' || c == '\t');
			if (c == '#') {
				p = yytext;
				*p++ = c;
				while ((c = cget()) != '\n' && c != EOF)
					*p++ = c;
				*p = '\0';
				f = mkString(yytext);
				f = CONS(f, R_NilValue);
				CAR(CAR(R_CommentSxp)) = listAppend(CAR(CAR(R_CommentSxp)), f);
			}
			if (c == '\n') {
				prompt();
				uncget(1);
				goto again;
			}
			if (c == '}') {
				while (*parenp == 'i')
					ifpop();
				parenp--;
				return c;
			}
			if (c == ',') {
				ifpop();
				return c;
			}
			uncget(1);
			if (!strncmp(bufp, "else", 4) && !isalnum(bufp[4]) && bufp[4] != '.') {
				eatln = 1;
				bufp += 4;
				cnt -= 4;
				ifpop();
				return ELSE;
			}
			ifpop();
		}
		else newline = 1;
		return '\n';
	}

		/* These are needed because both ; and , can end an if */
		/* clause without a newline.  Ifpop only does its thing in */
		/* the right context */

	if (c == ';' || c == ',') {
		ifpop();
		return c;
	}

		/* either digits or symbols can start with a . so we need */
		/* to decide which it is and jump to the correct spot */

	if (c == '.') {
		kw = typeofnext();
		if (kw >= 2) goto symbol;
#ifdef OLD
		if (kw == 2)
			goto symbol;
		if (kw == 0)
			return ERROR;
#endif
	}
	/* literal numbers */

	if (c == '.' || isdigit(c)) {
		int seendot = (c == '.');
		int seenexp = 0;
		p = yytext;
		*p++ = c;
		while (isdigit(c = cget()) || c == '.' || c == 'e' || c == 'E') {
			if (c == 'E' || c == 'e') {
				if (seenexp)
					break;
				seenexp = 1;
				seendot = 1;
				*p++ = c;
				c = cget();
				if (!isdigit(c) && c != '+' && c != '-')
					break;
			}
			if (c == '.') {
				if (seendot)
					break;
				seendot = 1;
			}
			*p++ = c;
		}
		uncget(1);
		*p = '\0';
		PROTECT(yylval = mkFloat(yytext));
		eatln = 0;
		return NUM_CONST;
	}

	/* literal strings */

	if (c == '\"' || c == '\'') {
		quote = c;
		p = yytext;
		while ((c = cget()) != EOF && c != quote) {
			if (c == '\n') {
				uncget(1);
				return ERROR;
			}
			if (c == '\\') {
				c = cget();
				switch (c) {
				case 'n':
					c = '\n';
					break;
				case 'r':
					c = '\r';
					break;
				case 't':
					c = '\t';
					break;
				case '\\':
					c = '\\';
					break;
				}
			}
			*p++ = c;
		}
		*p = '\0';
		PROTECT(yylval = mkString(yytext));
		eatln = 0;
		return STR_CONST;
	}

	/* special functions */
	if (c == '%') {
		p = yytext;
		*p++ = c;
		while ((c = cget()) != EOF && c != '%') {
			if (c == '\n') {
				uncget(1);
				return ERROR;
			}
			*p++ = c;
		}
		if (c == '%')
			*p++ = c;
		*p++ = '\0';
		PROTECT(yylval = install(yytext));
		eatln=1;
		return SPECIAL;
	}


	/* functions, constants and variables */

	/* gag, barf, but the punters want it */
	if (c == '_') {
		yylval = install("<-");
		return LEFT_ASSIGN;
	}

    symbol:
	if (c == '.' || isalpha(c)) {
		p = yytext;
		do {
			*p++ = c;
		} while ((c = cget()) != EOF && (isalnum(c) || c == '.'));
		uncget(1);
		*p = '\0';

		if ((kw = klookup(yytext)))
			return kw;

		PROTECT(yylval = install(yytext));
		eatln = 0;
		return SYMBOL;
	}

	/* compound tokens */

	switch (c) {
	case '<':
		eatln = 1;
		if (nextchar('=')) {
			yylval = install("<=");
			return LE;
		}
		if (nextchar('-')) {
			yylval = install("<-");
			return LEFT_ASSIGN;
		}
		if (nextchar('<'))
			if (nextchar('-')) {
				yylval = install("<<-");
				return LEFT_ASSIGN;
			}
			else
				return ERROR;
		yylval = install("<");
		return LT;
	case '-':
		eatln = 1;
		if (nextchar('>'))
			if (nextchar('>')) {
				yylval = install("<<-");
				return RIGHT_ASSIGN;
			}
			else {
				yylval = install("<-");
				return RIGHT_ASSIGN;
			}
		yylval = install("-");
		return '-';
	case '>':
		eatln = 1;
		if (nextchar('=')) {
			yylval = install(">=");
			return GE;
		}
		yylval = install(">");
		return GT;
	case '!':
		eatln = 1;
		if (nextchar('=')) {
			yylval = install("!=");
			return NE;
		}
		yylval = install("!");
		return '!';
	case '=':
		eatln = 1;
		if (nextchar('=')) {
			yylval = install("==");
			return EQ;
		}
		return '=';
	case ':':
		eatln = 1;
		if (nextchar('=')) {
			yylval = install(":=");
			return LEFT_ASSIGN;
		}
		yylval = install(":");
		return ':';
	case '&':
		eatln = 1;
		if (nextchar('&')) {
			yylval = install("&&");
			return AND;
		}
		yylval = install("&");
		return AND;
	case '|':
		eatln = 1;
		if (nextchar('|')) {
			yylval = install("||");
			return OR;
		}
		yylval = install("|");
		return OR;
	case '{':
		*++parenp = c;
		yylval = install("{");
		pushCmt();
		return c;
	case '}':
		ifpop();
		if(*parenp == '{')
			popCmt();
		parenp--;
		return c;
	case '(':
		*++parenp = c;
		yylval = install("(");
		return c;
	case ')':
		eatln = 0;
		ifpop();
		parenp--;
		return c;
	case '[':
		*++parenp = c;
		if (nextchar('[')) {
			*++parenp = c;
			yylval = install("[[");
			return LBB;
		}
		yylval = install("[");
		return c;
	case ']':
		ifpop();
		eatln = 0;
		parenp--;
		return c;
	case '?':
		eatln = 1;
		strcpy(yytext, "help");
		yylval = install(yytext);
		return c;
	case '*':
		eatln=1;
		if (nextchar('*')) 
			c='^';
		yytext[0] = c;
                yytext[1] = '\0';
                yylval = install(yytext);
                return c;
	case '+':
	case '/':
	case '^':
	case '~':
	case '$':
		eatln = 1;
		yytext[0] = c;
		yytext[1] = '\0';
		yylval = install(yytext);
		return c;
	default:
		return c;
	}
}
int yyexca[] ={
-1, 1,
	0, -1,
	-2, 0,
-1, 55,
	126, 0,
	-2, 15,
-1, 74,
	126, 0,
	-2, 26,
-1, 75,
	275, 0,
	276, 0,
	277, 0,
	278, 0,
	279, 0,
	280, 0,
	-2, 27,
-1, 76,
	275, 0,
	276, 0,
	277, 0,
	278, 0,
	279, 0,
	280, 0,
	-2, 28,
-1, 77,
	275, 0,
	276, 0,
	277, 0,
	278, 0,
	279, 0,
	280, 0,
	-2, 29,
-1, 78,
	275, 0,
	276, 0,
	277, 0,
	278, 0,
	279, 0,
	280, 0,
	-2, 30,
-1, 79,
	275, 0,
	276, 0,
	277, 0,
	278, 0,
	279, 0,
	280, 0,
	-2, 31,
-1, 80,
	275, 0,
	276, 0,
	277, 0,
	278, 0,
	279, 0,
	280, 0,
	-2, 32,
	};
# define YYNPROD 84
# define YYLAST 888
int yyact[]={

    23,    47,    32,   130,   141,    44,   149,    28,    26,   109,
    27,    98,    29,    57,    97,   105,    56,   113,   136,   121,
    92,    47,   117,    25,    48,    44,    47,    32,   148,    86,
    44,   127,    28,    26,   102,    27,   120,    29,   116,    48,
   115,   125,    91,    25,   126,   119,    47,    32,    25,    24,
    44,   131,    28,    26,    85,    27,    46,    29,   137,    30,
   114,   132,   122,   112,    63,    64,    47,    32,    25,    62,
    44,   129,    28,    26,    60,    27,    46,    29,    58,    30,
    48,    46,    61,   101,    30,    59,    47,    32,    25,    96,
    44,    33,    28,    26,   104,    27,    47,    29,    49,     1,
    44,    46,     0,    99,    30,     0,    47,    32,    25,   118,
    44,   103,    28,    26,   118,    27,    33,    29,     0,     0,
     0,    46,     0,     0,    30,     0,    47,    32,    25,     0,
    44,     0,    28,    26,     0,    27,    33,    29,     0,     0,
     0,    46,     0,   140,    30,     0,    47,    32,    25,   100,
    44,    46,    28,    26,    30,    27,    33,    29,   146,     0,
     0,    46,   145,     0,    30,     0,     0,     0,    25,     0,
     0,    47,    32,     0,     0,    44,    33,    28,    26,     0,
    27,    46,    29,     0,    30,     0,     0,     0,     0,     0,
     0,     0,     0,    25,     0,     0,    33,     0,     0,     0,
     0,    46,     0,     0,    30,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,    33,     0,     0,     0,
     0,     0,     0,     0,     0,     0,    46,     0,    45,    30,
    42,    43,     0,     0,     0,     0,    33,     0,     0,     0,
    39,    38,    34,    35,    36,    37,    40,    41,    45,     0,
     0,     0,    31,    45,     0,    42,    43,     0,     0,     0,
     0,    33,     0,     0,     0,    39,    38,    34,    35,    36,
    37,    40,    41,    45,     0,    42,    43,    31,     0,     0,
     0,     0,     0,     0,     0,    39,    38,    34,    35,    36,
    37,    40,    41,    45,     0,    42,    43,    31,     0,     0,
     0,     0,     0,     0,     0,    39,    38,    34,    35,    36,
    37,    40,    41,    45,     0,    42,    43,    31,     0,     0,
   128,     0,     0,    45,     0,    39,    38,    34,    35,    36,
    37,    40,    41,    45,     0,    42,    43,    31,     0,     0,
     0,     0,     0,     0,     0,    39,    38,    34,    35,    36,
    37,    40,    41,    45,     0,    42,    43,    31,     0,     0,
     0,     0,     0,     0,     0,    39,    38,    34,    35,    36,
    37,    40,    41,    45,     0,     0,     0,    31,     0,     0,
     0,     0,     0,     0,     0,    39,    38,    34,    35,    36,
    37,    40,    41,     0,     0,    47,    32,    31,    45,    44,
     0,    28,    26,    47,    27,     0,    29,    44,     0,     0,
    39,    38,    34,    35,    36,    37,     2,    25,     0,     0,
    47,    32,    31,     0,    44,    25,    28,    26,     0,    27,
     0,    29,    47,    32,     0,     0,    44,     0,    28,    13,
     0,     0,    25,    29,     0,     0,    10,     0,     0,    12,
    46,    11,     0,    30,    25,     0,     0,     0,    46,     0,
     0,    30,     0,     0,    13,     0,     0,     0,     0,    15,
     0,    10,     0,     0,    12,    46,    11,     0,    30,     0,
     0,     0,     0,     0,     0,    33,    13,    46,     0,     0,
    30,     0,     0,    10,    15,     0,    12,     0,    11,     0,
     0,     0,     0,     0,     0,    13,     0,     0,     0,     0,
     0,     0,    10,     0,     0,    12,    15,    11,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     9,
     0,     0,    14,     0,     0,    15,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     9,     0,     0,    14,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     9,     0,     0,    14,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     9,     0,     0,    14,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,    45,     0,     0,     0,     0,     0,     0,     0,
    45,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,    31,    45,     0,     0,
     0,     0,     0,     0,    31,     0,     0,     0,     0,    45,
     0,     0,     4,     6,     5,     7,     8,    16,     0,     0,
     0,    31,     0,    18,     0,    17,     0,    19,    21,    22,
    20,     0,     0,    31,     0,     0,     0,     0,     6,     5,
     7,     8,    16,     0,     0,     0,     0,     0,    18,     0,
    17,     0,    19,    21,    22,    20,     0,     0,     0,     0,
    95,     5,     7,    94,    16,     0,     0,     0,     0,     0,
    18,     0,    17,     0,    19,    21,    22,    20,     0,    89,
     5,    90,    88,    16,     0,     0,     0,     0,    87,    18,
     3,    17,     0,    19,    21,    22,    20,     0,    50,    51,
    52,    53,    54,    55,     0,     0,     0,     0,     0,    65,
     0,     0,     0,     0,    66,    67,    68,    69,    70,    71,
    72,    73,    74,    75,    76,    77,    78,    79,    80,    81,
    82,    83,    84,     0,    93,    93,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,   106,   107,
   108,     0,   110,   111,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
   123,   124,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,   133,   134,   135,     0,     0,   138,   139,
     0,     0,     0,     0,     0,     0,   142,   143,     0,   144,
     0,     0,     0,     0,     0,     0,    93,     0,     0,   147,
     0,     0,     0,     0,     0,     0,     0,   150 };
int yypact[]={

 -1000,   406, -1000,   -10, -1000, -1000, -1000, -1000,    40,   431,
   431,   431,   431,   431,   431,  -244,    38,    34,    29,    25,
   431, -1000, -1000, -1000, -1000,   431,   431,   431,   431,   431,
   431,   431,   431,   431,   431,   431,   431,   431,   431,   431,
   431,   431,   431,   431,   472,   453,   453,  -246,   472,    24,
    90,    70,    60,    60,   135,   384, -1000, -1000,  -245,   431,
   431,   431,  -251,   431,   431,    90,    60,   396,   396,   367,
   367,    60,   -15,   367,   384,   359,   359,   359,   359,   359,
   359,   135,   135,    90,   110,    22, -1000,    90,    -1,   -21,
   -23,   -71, -1000,    90,   -16,   -25,   -74, -1000, -1000,    21,
 -1000,   431,   431, -1000,     0,   -30,    50,    30,    90,  -265,
    90,    10, -1000,    17,   431,   431,   431,   -75,    14,   431,
   431, -1000, -1000,    90,    90, -1000,  -256,   431,   431, -1000,
   431, -1000,   472,    90,    90,    90, -1000,   453,    90,    90,
   431,   -33,    90,    90,   -35, -1000, -1000,    90,   431, -1000,
    90 };
int yypgo[]={

     0,    99,   738,    98,    94,    17,    54,    85,    82,    64,
    42,    29,    20 };
int yyr1[]={

     0,     1,     1,     1,     1,     1,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     9,     7,     8,     3,     3,     3,     3,     3,     3,
     6,     6,     6,     6,    11,    11,    11,    11,    11,    11,
    11,    10,    10,    12,    12,    12,    12,    12,     4,     4,
     4,     4,     4,     5 };
int yyr2[]={

     0,     1,     5,     7,     7,     5,     3,     3,     3,     3,
     7,     7,     5,     5,     5,     5,     5,     5,     7,     7,
     7,     7,     7,     7,     7,     7,     7,     7,     7,     7,
     7,     7,     7,     7,     7,     7,     7,    13,     9,     7,
    11,     7,     7,     5,    11,     9,     7,     7,     9,     3,
     3,     7,     7,    11,     1,     3,     7,     5,     7,     5,
     1,     3,     9,     7,     3,     7,     5,     7,     5,     5,
     7,     3,     9,     1,     3,     7,     5,     7,     1,     3,
     7,     7,    11,     1 };
int yychk[]={

 -1000,    -1,    10,    -2,   256,   258,   257,   259,   260,   123,
    40,    45,    43,    33,   126,    63,   261,   269,   267,   271,
   274,   272,   273,    10,    59,    58,    43,    45,    42,    47,
    94,   287,    37,   126,   277,   278,   279,   280,   276,   275,
   281,   282,   265,   266,    40,   263,    91,    36,    40,    -3,
    -2,    -2,    -2,    -2,    -2,    -2,   260,   257,    40,    -7,
    40,    -8,    40,    -9,    40,    -2,    -2,    -2,    -2,    -2,
    -2,    -2,    -2,    -2,    -2,    -2,    -2,    -2,    -2,    -2,
    -2,    -2,    -2,    -2,    -2,    -6,   -11,    -2,   260,   257,
   259,   -10,   -12,    -2,   260,   257,   -10,   260,   257,    -6,
   125,    59,    10,    41,    -4,   260,    -2,    -2,    -2,   260,
    -2,    -2,    41,    -5,    61,    61,    61,    93,    -5,    61,
    61,    93,    41,    -2,    -2,    41,    44,    61,   270,    41,
   268,    41,    44,    -2,    -2,    -2,    93,    44,    -2,    -2,
    -5,   260,    -2,    -2,    -2,   -11,   -12,    -2,    61,    41,
    -2 };
int yydef[]={

     1,    -2,     2,     0,     5,     6,     7,     8,     9,    54,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,    49,    50,     3,     4,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,    60,    73,    73,     0,    60,     0,
    55,     0,    12,    13,    14,    -2,    16,    17,    78,     0,
     0,     0,     0,     0,     0,    43,    18,    19,    20,    21,
    22,    23,    24,    25,    -2,    -2,    -2,    -2,    -2,    -2,
    -2,    33,    34,    35,    36,    83,    61,    64,     9,     7,
     8,    83,    71,    74,     9,     7,    83,    46,    47,    83,
    10,    57,    59,    11,     0,    79,    39,     0,    41,     0,
    42,     0,    38,     0,    66,    68,    69,     0,     0,    76,
     0,    45,    48,    56,    58,    83,     0,     0,     0,    52,
     0,    51,    63,    65,    67,    70,    44,    73,    75,    77,
     0,    81,    80,    40,     0,    62,    72,    37,     0,    53,
    82 };
typedef struct { char *t_name; int t_val; } yytoktype;
#ifndef YYDEBUG
#	define YYDEBUG	0	/* don't allow debugging */
#endif

#if YYDEBUG

yytoktype yytoks[] =
{
	"STR_CONST",	257,
	"NUM_CONST",	258,
	"NULL_CONST",	259,
	"SYMBOL",	260,
	"FUNCTION",	261,
	"LEX_ERROR",	262,
	"LBB",	263,
	"ERROR",	264,
	"LEFT_ASSIGN",	265,
	"RIGHT_ASSIGN",	266,
	"FOR",	267,
	"IN",	268,
	"IF",	269,
	"ELSE",	270,
	"WHILE",	271,
	"NEXT",	272,
	"BREAK",	273,
	"REPEAT",	274,
	"GT",	275,
	"GE",	276,
	"LT",	277,
	"LE",	278,
	"EQ",	279,
	"NE",	280,
	"AND",	281,
	"OR",	282,
	"LOW",	283,
	"UNOT",	284,
	"NOT",	285,
	"~",	126,
	"TILDE",	286,
	"+",	43,
	"-",	45,
	"*",	42,
	"/",	47,
	"%",	37,
	"?",	63,
	"SPECIAL",	287,
	":",	58,
	"UMINUS",	288,
	"UPLUS",	289,
	"^",	94,
	"$",	36,
	"(",	40,
	"[",	91,
	"-unknown-",	-1	/* ends search */
};

char * yyreds[] =
{
	"-no such reduction-",
	"prog : /* empty */",
	"prog : prog '\n'",
	"prog : prog expr '\n'",
	"prog : prog expr ';'",
	"prog : prog error",
	"expr : NUM_CONST",
	"expr : STR_CONST",
	"expr : NULL_CONST",
	"expr : SYMBOL",
	"expr : '{' exprlist '}'",
	"expr : '(' expr ')'",
	"expr : '-' expr",
	"expr : '+' expr",
	"expr : '!' expr",
	"expr : '~' expr",
	"expr : '?' SYMBOL",
	"expr : '?' STR_CONST",
	"expr : expr ':' expr",
	"expr : expr '+' expr",
	"expr : expr '-' expr",
	"expr : expr '*' expr",
	"expr : expr '/' expr",
	"expr : expr '^' expr",
	"expr : expr SPECIAL expr",
	"expr : expr '%' expr",
	"expr : expr '~' expr",
	"expr : expr LT expr",
	"expr : expr LE expr",
	"expr : expr EQ expr",
	"expr : expr NE expr",
	"expr : expr GE expr",
	"expr : expr GT expr",
	"expr : expr AND expr",
	"expr : expr OR expr",
	"expr : expr LEFT_ASSIGN expr",
	"expr : expr RIGHT_ASSIGN expr",
	"expr : FUNCTION '(' formlist ')' gobble expr",
	"expr : expr '(' arglist ')'",
	"expr : IF ifcond expr",
	"expr : IF ifcond expr ELSE expr",
	"expr : FOR forcond expr",
	"expr : WHILE cond expr",
	"expr : REPEAT expr",
	"expr : expr LBB sublist ']' ']'",
	"expr : expr '[' sublist ']'",
	"expr : expr '$' SYMBOL",
	"expr : expr '$' STR_CONST",
	"expr : SYMBOL '(' arglist ')'",
	"expr : NEXT",
	"expr : BREAK",
	"cond : '(' expr ')'",
	"ifcond : '(' expr ')'",
	"forcond : '(' SYMBOL IN expr ')'",
	"exprlist : /* empty */",
	"exprlist : expr",
	"exprlist : exprlist ';' expr",
	"exprlist : exprlist ';'",
	"exprlist : exprlist '\n' expr",
	"exprlist : exprlist '\n'",
	"arglist : /* empty */",
	"arglist : arg",
	"arglist : arglist gobble ',' arg",
	"arglist : arglist gobble ','",
	"arg : expr",
	"arg : SYMBOL '=' expr",
	"arg : SYMBOL '='",
	"arg : STR_CONST '=' expr",
	"arg : STR_CONST '='",
	"arg : NULL_CONST '='",
	"arg : NULL_CONST '=' expr",
	"sublist : sub",
	"sublist : sublist gobble ',' sub",
	"sub : /* empty */",
	"sub : expr",
	"sub : SYMBOL '=' expr",
	"sub : SYMBOL '='",
	"sub : STR_CONST '=' expr",
	"formlist : /* empty */",
	"formlist : SYMBOL",
	"formlist : SYMBOL '=' expr",
	"formlist : formlist ',' SYMBOL",
	"formlist : formlist ',' SYMBOL '=' expr",
	"gobble : /* empty */",
};
#endif /* YYDEBUG */
#line 1 "/usr/lib/yaccpar"
/*	@(#)yaccpar 1.10 89/04/04 SMI; from S5R3 1.10	*/

/*
** Skeleton parser driver for yacc output
*/

/*
** yacc user known macros and defines
*/
#define YYERROR		goto yyerrlab
#define YYACCEPT	{ free(yys); free(yyv); return(0); }
#define YYABORT		{ free(yys); free(yyv); return(1); }
#define YYBACKUP( newtoken, newvalue )\
{\
	if ( yychar >= 0 || ( yyr2[ yytmp ] >> 1 ) != 1 )\
	{\
		yyerror( "syntax error - cannot backup" );\
		goto yyerrlab;\
	}\
	yychar = newtoken;\
	yystate = *yyps;\
	yylval = newvalue;\
	goto yynewstate;\
}
#define YYRECOVERING()	(!!yyerrflag)
#ifndef YYDEBUG
#	define YYDEBUG	1	/* make debugging available */
#endif

/*
** user known globals
*/
int yydebug;			/* set to 1 to get debugging */

/*
** driver internal defines
*/
#define YYFLAG		(-1000)

/*
** static variables used by the parser
*/
static YYSTYPE *yyv;			/* value stack */
static int *yys;			/* state stack */

static YYSTYPE *yypv;			/* top of value stack */
static int *yyps;			/* top of state stack */

static int yystate;			/* current state */
static int yytmp;			/* extra var (lasts between blocks) */

int yynerrs;			/* number of errors */

int yyerrflag;			/* error recovery flag */
int yychar;			/* current input token number */


/*
** yyparse - return 0 if worked, 1 if syntax error not recovered from
*/
int
yyparse()
{
	register YYSTYPE *yypvt;	/* top of value stack for $vars */
	unsigned yymaxdepth = YYMAXDEPTH;

	/*
	** Initialize externals - yyparse may be called more than once
	*/
	yyv = (YYSTYPE*)malloc(yymaxdepth*sizeof(YYSTYPE));
	yys = (int*)malloc(yymaxdepth*sizeof(int));
	if (!yyv || !yys)
	{
		yyerror( "out of memory" );
		return(1);
	}
	yypv = &yyv[-1];
	yyps = &yys[-1];
	yystate = 0;
	yytmp = 0;
	yynerrs = 0;
	yyerrflag = 0;
	yychar = -1;

	goto yystack;
	{
		register YYSTYPE *yy_pv;	/* top of value stack */
		register int *yy_ps;		/* top of state stack */
		register int yy_state;		/* current state */
		register int  yy_n;		/* internal state number info */

		/*
		** get globals into registers.
		** branch to here only if YYBACKUP was called.
		*/
	yynewstate:
		yy_pv = yypv;
		yy_ps = yyps;
		yy_state = yystate;
		goto yy_newstate;

		/*
		** get globals into registers.
		** either we just started, or we just finished a reduction
		*/
	yystack:
		yy_pv = yypv;
		yy_ps = yyps;
		yy_state = yystate;

		/*
		** top of for (;;) loop while no reductions done
		*/
	yy_stack:
		/*
		** put a state and value onto the stacks
		*/
#if YYDEBUG
		/*
		** if debugging, look up token value in list of value vs.
		** name pairs.  0 and negative (-1) are special values.
		** Note: linear search is used since time is not a real
		** consideration while debugging.
		*/
		if ( yydebug )
		{
			register int yy_i;

			(void)printf( "State %d, token ", yy_state );
			if ( yychar == 0 )
				(void)printf( "end-of-file\n" );
			else if ( yychar < 0 )
				(void)printf( "-none-\n" );
			else
			{
				for ( yy_i = 0; yytoks[yy_i].t_val >= 0;
					yy_i++ )
				{
					if ( yytoks[yy_i].t_val == yychar )
						break;
				}
				(void)printf( "%s\n", yytoks[yy_i].t_name );
			}
		}
#endif /* YYDEBUG */
		if ( ++yy_ps >= &yys[ yymaxdepth ] )	/* room on stack? */
		{
			/*
			** reallocate and recover.  Note that pointers
			** have to be reset, or bad things will happen
			*/
			int yyps_index = (yy_ps - yys);
			int yypv_index = (yy_pv - yyv);
			int yypvt_index = (yypvt - yyv);
			yymaxdepth += YYMAXDEPTH;
			yyv = (YYSTYPE*)realloc((char*)yyv,
				yymaxdepth * sizeof(YYSTYPE));
			yys = (int*)realloc((char*)yys,
				yymaxdepth * sizeof(int));
			if (!yyv || !yys)
			{
				yyerror( "yacc stack overflow" );
				return(1);
			}
			yy_ps = yys + yyps_index;
			yy_pv = yyv + yypv_index;
			yypvt = yyv + yypvt_index;
		}
		*yy_ps = yy_state;
		*++yy_pv = yyval;

		/*
		** we have a new state - find out what to do
		*/
	yy_newstate:
		if ( ( yy_n = yypact[ yy_state ] ) <= YYFLAG )
			goto yydefault;		/* simple state */
#if YYDEBUG
		/*
		** if debugging, need to mark whether new token grabbed
		*/
		yytmp = yychar < 0;
#endif
		if ( ( yychar < 0 ) && ( ( yychar = yylex() ) < 0 ) )
			yychar = 0;		/* reached EOF */
#if YYDEBUG
		if ( yydebug && yytmp )
		{
			register int yy_i;

			(void)printf( "Received token " );
			if ( yychar == 0 )
				(void)printf( "end-of-file\n" );
			else if ( yychar < 0 )
				(void)printf( "-none-\n" );
			else
			{
				for ( yy_i = 0; yytoks[yy_i].t_val >= 0;
					yy_i++ )
				{
					if ( yytoks[yy_i].t_val == yychar )
						break;
				}
				(void)printf( "%s\n", yytoks[yy_i].t_name );
			}
		}
#endif /* YYDEBUG */
		if ( ( ( yy_n += yychar ) < 0 ) || ( yy_n >= YYLAST ) )
			goto yydefault;
		if ( yychk[ yy_n = yyact[ yy_n ] ] == yychar )	/*valid shift*/
		{
			yychar = -1;
			yyval = yylval;
			yy_state = yy_n;
			if ( yyerrflag > 0 )
				yyerrflag--;
			goto yy_stack;
		}

	yydefault:
		if ( ( yy_n = yydef[ yy_state ] ) == -2 )
		{
#if YYDEBUG
			yytmp = yychar < 0;
#endif
			if ( ( yychar < 0 ) && ( ( yychar = yylex() ) < 0 ) )
				yychar = 0;		/* reached EOF */
#if YYDEBUG
			if ( yydebug && yytmp )
			{
				register int yy_i;

				(void)printf( "Received token " );
				if ( yychar == 0 )
					(void)printf( "end-of-file\n" );
				else if ( yychar < 0 )
					(void)printf( "-none-\n" );
				else
				{
					for ( yy_i = 0;
						yytoks[yy_i].t_val >= 0;
						yy_i++ )
					{
						if ( yytoks[yy_i].t_val
							== yychar )
						{
							break;
						}
					}
					(void)printf( "%s\n", yytoks[yy_i].t_name );
				}
			}
#endif /* YYDEBUG */
			/*
			** look through exception table
			*/
			{
				register int *yyxi = yyexca;

				while ( ( *yyxi != -1 ) ||
					( yyxi[1] != yy_state ) )
				{
					yyxi += 2;
				}
				while ( ( *(yyxi += 2) >= 0 ) &&
					( *yyxi != yychar ) )
					;
				if ( ( yy_n = yyxi[1] ) < 0 )
					YYACCEPT;
			}
		}

		/*
		** check for syntax error
		*/
		if ( yy_n == 0 )	/* have an error */
		{
			/* no worry about speed here! */
			switch ( yyerrflag )
			{
			case 0:		/* new error */
				yyerror( "syntax error" );
				goto skip_init;
			yyerrlab:
				/*
				** get globals into registers.
				** we have a user generated syntax type error
				*/
				yy_pv = yypv;
				yy_ps = yyps;
				yy_state = yystate;
				yynerrs++;
			skip_init:
			case 1:
			case 2:		/* incompletely recovered error */
					/* try again... */
				yyerrflag = 3;
				/*
				** find state where "error" is a legal
				** shift action
				*/
				while ( yy_ps >= yys )
				{
					yy_n = yypact[ *yy_ps ] + YYERRCODE;
					if ( yy_n >= 0 && yy_n < YYLAST &&
						yychk[yyact[yy_n]] == YYERRCODE)					{
						/*
						** simulate shift of "error"
						*/
						yy_state = yyact[ yy_n ];
						goto yy_stack;
					}
					/*
					** current state has no shift on
					** "error", pop stack
					*/
#if YYDEBUG
#	define _POP_ "Error recovery pops state %d, uncovers state %d\n"
					if ( yydebug )
						(void)printf( _POP_, *yy_ps,
							yy_ps[-1] );
#	undef _POP_
#endif
					yy_ps--;
					yy_pv--;
				}
				/*
				** there is no state on stack with "error" as
				** a valid shift.  give up.
				*/
				YYABORT;
			case 3:		/* no shift yet; eat a token */
#if YYDEBUG
				/*
				** if debugging, look up token in list of
				** pairs.  0 and negative shouldn't occur,
				** but since timing doesn't matter when
				** debugging, it doesn't hurt to leave the
				** tests here.
				*/
				if ( yydebug )
				{
					register int yy_i;

					(void)printf( "Error recovery discards " );
					if ( yychar == 0 )
						(void)printf( "token end-of-file\n" );
					else if ( yychar < 0 )
						(void)printf( "token -none-\n" );
					else
					{
						for ( yy_i = 0;
							yytoks[yy_i].t_val >= 0;
							yy_i++ )
						{
							if ( yytoks[yy_i].t_val
								== yychar )
							{
								break;
							}
						}
						(void)printf( "token %s\n",
							yytoks[yy_i].t_name );
					}
				}
#endif /* YYDEBUG */
				if ( yychar == 0 )	/* reached EOF. quit */
					YYABORT;
				yychar = -1;
				goto yy_newstate;
			}
		}/* end if ( yy_n == 0 ) */
		/*
		** reduction by production yy_n
		** put stack tops, etc. so things right after switch
		*/
#if YYDEBUG
		/*
		** if debugging, print the string that is the user's
		** specification of the reduction which is just about
		** to be done.
		*/
		if ( yydebug )
			(void)printf( "Reduce by (%d) \"%s\"\n",
				yy_n, yyreds[ yy_n ] );
#endif
		yytmp = yy_n;			/* value to switch over */
		yypvt = yy_pv;			/* $vars top of value stack */
		/*
		** Look in goto table for next state
		** Sorry about using yy_state here as temporary
		** register variable, but why not, if it works...
		** If yyr2[ yy_n ] doesn't have the low order bit
		** set, then there is no action to be done for
		** this reduction.  So, no saving & unsaving of
		** registers done.  The only difference between the
		** code just after the if and the body of the if is
		** the goto yy_stack in the body.  This way the test
		** can be made before the choice of what to do is needed.
		*/
		{
			/* length of production doubled with extra bit */
			register int yy_len = yyr2[ yy_n ];

			if ( !( yy_len & 01 ) )
			{
				yy_len >>= 1;
				yyval = ( yy_pv -= yy_len )[1];	/* $$ = $1 */
				yy_state = yypgo[ yy_n = yyr1[ yy_n ] ] +
					*( yy_ps -= yy_len ) + 1;
				if ( yy_state >= YYLAST ||
					yychk[ yy_state =
					yyact[ yy_state ] ] != -yy_n )
				{
					yy_state = yyact[ yypgo[ yy_n ] ];
				}
				goto yy_stack;
			}
			yy_len >>= 1;
			yyval = ( yy_pv -= yy_len )[1];	/* $$ = $1 */
			yy_state = yypgo[ yy_n = yyr1[ yy_n ] ] +
				*( yy_ps -= yy_len ) + 1;
			if ( yy_state >= YYLAST ||
				yychk[ yy_state = yyact[ yy_state ] ] != -yy_n )
			{
				yy_state = yyact[ yypgo[ yy_n ] ];
			}
		}
					/* save until reenter driver code */
		yystate = yy_state;
		yyps = yy_ps;
		yypv = yy_pv;
	}
	/*
	** code supplied by user is placed in this switch
	*/
	switch( yytmp )
	{
		
case 1:
# line 66 "gram.y"
{ newline = 0; } break;
case 2:
# line 67 "gram.y"
{ R_CurrentExpr = NULL; return 2; } break;
case 3:
# line 68 "gram.y"
{ R_CurrentExpr = yypvt[-1]; UNPROTECT(1); YYRETURN(3); } break;
case 4:
# line 69 "gram.y"
{ R_CurrentExpr = yypvt[-1]; UNPROTECT(1); YYRETURN(4); } break;
case 5:
# line 70 "gram.y"
{ YYABORT; } break;
case 6:
# line 73 "gram.y"
{ yyval = yypvt[-0]; } break;
case 7:
# line 74 "gram.y"
{ yyval = yypvt[-0]; } break;
case 8:
# line 75 "gram.y"
{ yyval = yypvt[-0]; } break;
case 9:
# line 76 "gram.y"
{ yyval = yypvt[-0]; } break;
case 10:
# line 77 "gram.y"
{ UNPROTECT(1); TYPEOF(yypvt[-1]) = LANGSXP; CAR(yypvt[-1]) = yypvt[-2]; yyval = yypvt[-1]; PROTECT(yyval); eatln = 0; } break;
case 11:
# line 78 "gram.y"
{ UNPROTECT(1); yyval = lang2(yypvt[-2], yypvt[-1]); PROTECT(yyval); } break;
case 12:
# line 79 "gram.y"
{ UNPROTECT(1); yyval = lang2(yypvt[-1], yypvt[-0]); PROTECT(yyval); } break;
case 13:
# line 80 "gram.y"
{ UNPROTECT(1); yyval = lang2(yypvt[-1], yypvt[-0]); PROTECT(yyval); } break;
case 14:
# line 81 "gram.y"
{ UNPROTECT(1); yyval = lang2(yypvt[-1], yypvt[-0]); PROTECT(yyval); } break;
case 15:
# line 82 "gram.y"
{ UNPROTECT(1); yyval = lang2(yypvt[-1], yypvt[-0]); PROTECT(yyval); } break;
case 16:
# line 83 "gram.y"
{ UNPROTECT(1); yyval = lang2(yypvt[-1], yypvt[-0]); PROTECT(yyval); } break;
case 17:
# line 84 "gram.y"
{ UNPROTECT(1); yyval = lang2(yypvt[-1], yypvt[-0]); PROTECT(yyval); } break;
case 18:
# line 85 "gram.y"
{ UNPROTECT(2); yyval = lang3(yypvt[-1], yypvt[-2], yypvt[-0]); PROTECT(yyval); } break;
case 19:
# line 86 "gram.y"
{ UNPROTECT(2); yyval = lang3(yypvt[-1], yypvt[-2], yypvt[-0]); PROTECT(yyval); } break;
case 20:
# line 87 "gram.y"
{ UNPROTECT(2); yyval = lang3(yypvt[-1], yypvt[-2], yypvt[-0]); PROTECT(yyval); } break;
case 21:
# line 88 "gram.y"
{ UNPROTECT(2); yyval = lang3(yypvt[-1], yypvt[-2], yypvt[-0]); PROTECT(yyval); } break;
case 22:
# line 89 "gram.y"
{ UNPROTECT(2); yyval = lang3(yypvt[-1], yypvt[-2], yypvt[-0]); PROTECT(yyval); } break;
case 23:
# line 90 "gram.y"
{ UNPROTECT(2); yyval = lang3(yypvt[-1], yypvt[-2], yypvt[-0]); PROTECT(yyval); } break;
case 24:
# line 91 "gram.y"
{ UNPROTECT(3); yyval = lang3(yypvt[-1], yypvt[-2], yypvt[-0]); PROTECT(yyval); } break;
case 25:
# line 92 "gram.y"
{ UNPROTECT(2); yyval = lang3(yypvt[-1], yypvt[-2], yypvt[-0]); PROTECT(yyval); } break;
case 26:
# line 93 "gram.y"
{ UNPROTECT(2); yyval = lang3(yypvt[-1], yypvt[-2], yypvt[-0]); PROTECT(yyval); } break;
case 27:
# line 94 "gram.y"
{ UNPROTECT(2); yyval = lang3(yypvt[-1], yypvt[-2], yypvt[-0]); PROTECT(yyval); } break;
case 28:
# line 95 "gram.y"
{ UNPROTECT(2); yyval = lang3(yypvt[-1], yypvt[-2], yypvt[-0]); PROTECT(yyval); } break;
case 29:
# line 96 "gram.y"
{ UNPROTECT(2); yyval = lang3(yypvt[-1], yypvt[-2], yypvt[-0]); PROTECT(yyval); } break;
case 30:
# line 97 "gram.y"
{ UNPROTECT(2); yyval = lang3(yypvt[-1], yypvt[-2], yypvt[-0]); PROTECT(yyval); } break;
case 31:
# line 98 "gram.y"
{ UNPROTECT(2); yyval = lang3(yypvt[-1], yypvt[-2], yypvt[-0]); PROTECT(yyval); } break;
case 32:
# line 99 "gram.y"
{ UNPROTECT(2); yyval = lang3(yypvt[-1], yypvt[-2], yypvt[-0]); PROTECT(yyval); } break;
case 33:
# line 100 "gram.y"
{ UNPROTECT(2); yyval = lang3(yypvt[-1], yypvt[-2], yypvt[-0]); PROTECT(yyval); } break;
case 34:
# line 101 "gram.y"
{ UNPROTECT(2); yyval = lang3(yypvt[-1], yypvt[-2], yypvt[-0]); PROTECT(yyval); } break;
case 35:
# line 102 "gram.y"
{ UNPROTECT(2); yyval = lang3(yypvt[-1], yypvt[-2], yypvt[-0]); PROTECT(yyval); } break;
case 36:
# line 103 "gram.y"
{ UNPROTECT(2); yyval = lang3(yypvt[-1], yypvt[-0], yypvt[-2]); PROTECT(yyval); } break;
case 37:
# line 105 "gram.y"
{ UNPROTECT(2); yyval = lang3(yypvt[-5], CDR(yypvt[-3]), yypvt[-0]); PROTECT(yyval); } break;
case 38:
# line 106 "gram.y"
{ if(isString(yypvt[-3])) yypvt[-3]=install(CHAR(STRING(yypvt[-3])[0])); UNPROTECT(2); if(length(CDR(yypvt[-1])) == 1 && CADR(yypvt[-1]) == R_MissingArg )
										yyval = lang1(yypvt[-3]);
									else
										yyval = LCONS(yypvt[-3], CDR(yypvt[-1])); 
									PROTECT(yyval); } break;
case 39:
# line 111 "gram.y"
{ UNPROTECT(2); yyval = lang3(yypvt[-2], yypvt[-1], yypvt[-0]); PROTECT(yyval);  } break;
case 40:
# line 112 "gram.y"
{ UNPROTECT(3); yyval = lang4(yypvt[-4], yypvt[-3], yypvt[-2], yypvt[-0]); PROTECT(yyval); } break;
case 41:
# line 113 "gram.y"
{ UNPROTECT(2); yyval = lang4(yypvt[-2], CAR(yypvt[-1]), CDR(yypvt[-1]), yypvt[-0]); PROTECT(yyval); } break;
case 42:
# line 114 "gram.y"
{ UNPROTECT(2); yyval = lang3(yypvt[-2], yypvt[-1], yypvt[-0]); PROTECT(yyval); } break;
case 43:
# line 115 "gram.y"
{ UNPROTECT(1); yyval = lang2(yypvt[-1], yypvt[-0]); PROTECT(yyval); } break;
case 44:
# line 116 "gram.y"
{ UNPROTECT(2); yyval = lang3(yypvt[-3], yypvt[-4], CDR(yypvt[-2])); PROTECT(yyval); } break;
case 45:
# line 117 "gram.y"
{ UNPROTECT(2); yyval = lang3(yypvt[-2], yypvt[-3], CDR(yypvt[-1])); PROTECT(yyval); } break;
case 46:
# line 118 "gram.y"
{ yyval = lang3(yypvt[-1], yypvt[-2], lang1(yypvt[-0])); UNPROTECT(2); PROTECT(yyval); } break;
case 47:
# line 119 "gram.y"
{ yyval = lang3(yypvt[-1], yypvt[-2], lang1(yypvt[-0])); UNPROTECT(2); PROTECT(yyval); } break;
case 48:
# line 120 "gram.y"
{ UNPROTECT(2); TYPEOF(yypvt[-1]) = LANGSXP; CAR(yypvt[-1]) = yypvt[-3]; yyval = yypvt[-1]; PROTECT(yyval); } break;
case 49:
# line 121 "gram.y"
{ yyval = lang1(yypvt[-0]); PROTECT(yyval); } break;
case 50:
# line 122 "gram.y"
{ yyval = lang1(yypvt[-0]); PROTECT(yyval); } break;
case 51:
# line 126 "gram.y"
{ yyval = yypvt[-1];  eatln = 1; } break;
case 52:
# line 129 "gram.y"
{ yyval = yypvt[-1]; ifpush(); eatln = 1; } break;
case 53:
# line 132 "gram.y"
{ UNPROTECT(2); yyval = LCONS(yypvt[-3],yypvt[-1]); PROTECT(yyval); eatln=1;} break;
case 54:
# line 136 "gram.y"
{ yyval = newlist(); PROTECT(yyval); } break;
case 55:
# line 137 "gram.y"
{ UNPROTECT(1); yyval = growlist(newlist(), yypvt[-0]); PROTECT(yyval);addcomment(CAR(yyval));} break;
case 56:
# line 138 "gram.y"
{ UNPROTECT(2); yyval = growlist(yypvt[-2], yypvt[-0]); PROTECT(yyval); addcomment(CAR(yyval));} break;
case 57:
# line 139 "gram.y"
{ yyval = yypvt[-1]; addcomment(CAR(yyval)); } break;
case 58:
# line 140 "gram.y"
{ UNPROTECT(2); yyval = growlist(yypvt[-2], yypvt[-0]); PROTECT(yyval);addcomment(CAR(yyval));} break;
case 59:
# line 141 "gram.y"
{ yyval = yypvt[-1]; addcomment(CAR(yyval));} break;
case 60:
# line 144 "gram.y"
{ yyval = LCONS(R_MissingArg,R_NilValue); PROTECT(yyval); } break;
case 61:
# line 145 "gram.y"
{ UNPROTECT(1); yyval = firstarg(CAR(yypvt[-0]),CADR(yypvt[-0])); PROTECT(yyval); } break;
case 62:
# line 146 "gram.y"
{ UNPROTECT(2); yyval = nextarg(yypvt[-3], CAR(yypvt[-0]), CADR(yypvt[-0])); PROTECT(yyval); } break;
case 63:
# line 147 "gram.y"
{ UNPROTECT(1); yyval = nextarg(yypvt[-2], R_MissingArg, R_NilValue); PROTECT(yyval); } break;
case 64:
# line 150 "gram.y"
{ UNPROTECT(1); yyval = tagarg(yypvt[-0], R_NilValue); PROTECT(yyval); } break;
case 65:
# line 151 "gram.y"
{ UNPROTECT(2); yyval = tagarg(yypvt[-0], yypvt[-2]); PROTECT(yyval); } break;
case 66:
# line 152 "gram.y"
{ UNPROTECT(1); yyval = tagarg(R_MissingArg, yypvt[-1]); PROTECT(yyval); } break;
case 67:
# line 153 "gram.y"
{ UNPROTECT(2); yyval = tagarg(yypvt[-0], yypvt[-2]); PROTECT(yyval); } break;
case 68:
# line 154 "gram.y"
{ UNPROTECT(1); yyval = tagarg(R_MissingArg, yypvt[-1]); PROTECT(yyval); } break;
case 69:
# line 155 "gram.y"
{ UNPROTECT(1); yyval = tagarg(R_MissingArg, install("NULL")); PROTECT(yyval); } break;
case 70:
# line 156 "gram.y"
{ UNPROTECT(2); yyval = tagarg(yypvt[-0], install("NULL")); PROTECT(yyval); } break;
case 71:
# line 159 "gram.y"
{ UNPROTECT(1); yyval = firstarg(CAR(yypvt[-0]),CADR(yypvt[-0])); PROTECT(yyval); } break;
case 72:
# line 160 "gram.y"
{ UNPROTECT(2); yyval = nextarg(yypvt[-3], CAR(yypvt[-0]), CADR(yypvt[-0])); PROTECT(yyval); } break;
case 73:
# line 163 "gram.y"
{ yyval = lang2(R_MissingArg,R_NilValue); PROTECT(yyval); } break;
case 74:
# line 164 "gram.y"
{ UNPROTECT(1); yyval = tagarg(yypvt[-0], R_NilValue); PROTECT(yyval); } break;
case 75:
# line 165 "gram.y"
{ UNPROTECT(2); yyval = tagarg(yypvt[-0], yypvt[-2]); PROTECT(yyval); } break;
case 76:
# line 166 "gram.y"
{ UNPROTECT(1); yyval = tagarg(R_MissingArg, yypvt[-1]); PROTECT(yyval); } break;
case 77:
# line 167 "gram.y"
{ UNPROTECT(2); yyval = tagarg(yypvt[-0], yypvt[-2]); PROTECT(yyval); } break;
case 78:
# line 170 "gram.y"
{ yyval = R_NilValue; PROTECT(yyval); } break;
case 79:
# line 171 "gram.y"
{ UNPROTECT(1); yyval = firstarg(yypvt[-0], R_MissingArg); PROTECT(yyval); } break;
case 80:
# line 172 "gram.y"
{ UNPROTECT(2); yyval = firstarg(yypvt[-2], yypvt[-0]); PROTECT(yyval); } break;
case 81:
# line 173 "gram.y"
{ UNPROTECT(2); yyval = nextarg(yypvt[-2], yypvt[-0], R_MissingArg); PROTECT(yyval); } break;
case 82:
# line 174 "gram.y"
{ UNPROTECT(3); yyval = nextarg(yypvt[-4], yypvt[-2], yypvt[-0]); PROTECT(yyval); } break;
case 83:
# line 177 "gram.y"
{eatln = 1;} break;
	}
	goto yystack;		/* reset registers in driver code */
}
