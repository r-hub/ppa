/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Printing.h>

#define SBarWidth		15

/* File Menu */
#define newCommand		1
#define openCommand		2
#define saveCommand		3
#define	loadCommand		4
#define pageSetCommand	6
#define printCommand	7
#define quitCommand		9

/* Edit Menu */
#define undoCommand 	1
#define cutCommand		3
#define copyCommand		4
#define pasteCommand	5
#define clearCommand	6

extern	Cursor	waitCursor;

extern CursHandle	iBeam;
extern CursHandle	cross;
extern CursHandle	plus;
extern CursHandle	watch;
extern Rect			dragRect;

extern MenuHandle	appleMenu;
extern MenuHandle	fileMenu;
extern MenuHandle	editMenu;

typedef struct {
	int			active;										/* Active context flag */
	WindowPtr	theWindow;									/* Window */
	
	TEHandle		theTEH;									/* TE Handle */
	ControlHandle	vScroll;								/* Associated crud */
	ControlHandle	hScroll;
	int				lines;
	int				cols;
	int				fontWidth;
	int				fontHeight;
	
	Handle			pasteH;									/* Paste buffer */
	long			pasteOfs;								/* Paste buffer offset */
	long			pasteLen;								/* Paste buffer length */
	
	void	(*doCursor)(void);								/* Cursor maintenance */
	void	(*doKey)(int, EventRecord*);					/* Key press */
	void	(*doMenu)(long);								/* Cmd-Key press & Menus */
	void	(*doActive)(EventRecord*, WindowPtr, short);	/* Mouse click in active window */
	void	(*doInactive)(EventRecord*, WindowPtr, short);	/* Mouse click in inactive window */
	void	(*doNotWindow)(EventRecord*, WindowPtr, short);	/* Mouse click elsewhere (menu/desktop) */
	void	(*doUpdate)(WindowPtr);							/* Update event */
	void	(*doActivate)(int);								/* Activate/Deactivate */
}
WindowContext;

extern WindowContext	*activeContext;
extern WindowContext	stdioContext;
extern WindowContext	graphContext;
extern WindowContext	editorContext;
extern WindowContext	spreadContext;

extern TEHandle			scrollText;							/* TE buffer for scrolling */
extern ControlHandle	scrollVScroll;						/* Scrolling controls */
extern ControlHandle	scrollHScroll;
extern int				scrollLines;

extern void InitStdioConsole(Str255, int, int, WindowContext*);
extern void DoMenu(long);
extern void menuOpen(void);
extern void menuSave(int);
extern void menuLoad(void);

/* Text Window Manipulation */

extern void SetVScroll(void);
extern pascal Boolean CClikLoop(void);
extern void ScrollInsertPt(TEHandle hTE);
extern int AdjustText(void);
extern void SetView(WindowPtr w);
pascal void ScrollProc(ControlHandle theControl, short theCode);
