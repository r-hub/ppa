/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995, 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"

#define RELEASED	"May 31, 1996"
#define MAJOR		"0"
#define MINOR		"8"
#define STATUS		"Alpha"
#define STATUS_REV	"1"
#define YEAR		"1996"

#ifdef DecAlpha
#define PLATFORM	"DIGITAL_UNIX"
#define ARCH		"DEC Alpha"
#define OS		"Digital UNIX V3.2C"
#endif

#ifdef FreeBSD
#define PLATFORM	"FREEBSD_INTEL"
#define ARCH		"Intel iAPX 486"
#define OS		"FreeBSD 2.1R"
#endif

#ifdef HP
#define PLATFORM	"HP_UNIX"
#define ARCH		"Unknown"
#define OS		"Unknown"
#endif

#ifdef Irix
#define PLATFORM	"SGI_IRIX"
#define ARCH		"SGI_Indy"
#define OS		"IRIX 5.3"
#endif

#ifdef Linux
#define PLATFORM	"LINUX_INTEL"
#define ARCH		"Intel iAPX 486"
#define OS		"Unknown Linux"
#endif

#ifdef NetBSD
#define PLATFORM	"NETBSD_INTEL"
#define ARCH		"Intel iAPX 486"
#define OS		"Unknown NetBSD"
#endif

#ifdef SonyNews
#define PLATFORM	"SONY_NEWS"
#define ARCH		"Unknown"
#define OS		"NewsOS 4.1C"
#endif

#ifdef Solaris
#define PLATFORM	"SUNOS5_SPARC"
#define ARCH		"Sun SPARC"
#define OS		"SunOS 5.x"
#endif

#ifdef SunOS
#define PLATFORM	"SUNOS4_SPARC"
#define ARCH		"Sun SPARC"
#define OS		"SunOS 4.1.x"
#endif


#ifndef PLATFORM
#define PLATFORM	"UNKNOWN"
#endif
#ifndef ARCH
#define ARCH		"UNKNOWN"
#endif
#ifndef OS
#define OS		"UNKNOWN"
#endif


void PrintGreeting(void)
{
	Rprintf("\nR : Copyright (c) %s, Robert Gentleman and Ross Ihaka\n", YEAR);
	Rprintf("Version %s.%s, (Released: %s)\n\n", MAJOR, MINOR, RELEASED);
	Rprintf("R is free software and comes with ABSOLUTELY NO WARRANTY.\n");
	Rprintf("You are welcome to redistribute it under certain conditions.\n");
	Rprintf("Type \"license()\" for details.\n\n");
}

SEXP do_makeversion(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP a, ans;
	char buf[128];
	checkArity(op, args);

	PROTECT(a = ans = allocList(10));
	TAG(a) = install("platform");
	CAR(a) = mkString(PLATFORM);
	a= CDR(a);
	TAG(a) = install("arch");
	CAR(a) = mkString(ARCH);
	a= CDR(a);
	TAG(a) = install("os");
	CAR(a) = mkString(OS);
	a= CDR(a);
	sprintf(buf,"%s, %s", ARCH, OS);
	TAG(a) = install("system");
	CAR(a) = mkString(buf);
	a= CDR(a);
	TAG(a) = install("status");
	CAR(a) = mkString(STATUS);
	a= CDR(a);
	TAG(a) = install("status.rev");
	CAR(a) = mkString(STATUS_REV);
	a= CDR(a);
	TAG(a) = install("major");
	CAR(a) = mkString(MAJOR);
	a= CDR(a);
	TAG(a) = install("minor");
	CAR(a) = mkString(MINOR);
	a= CDR(a);
	TAG(a) = install("year");
	CAR(a) = mkString(YEAR);
	a= CDR(a);
	TAG(a) = install("language");
	CAR(a) = mkString("R");
	UNPROTECT(1);
	return ans;
}
