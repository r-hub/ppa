/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"
#include <string.h>
#include <stdlib.h>


#ifdef DLSupport

	/* This code adds dynamic loading of code to R.  It */
	/* replaces the original dotcode.c and contains code */
	/* from that file. This code should work on a system */
	/* that implements the Solaris dlopen interface */
	/* standard. Shared libraries are loaded by dlopen */
	/* and symbols are looked for by dlsym. Unloading of */
	/* code is not implemented. This code was developed */
	/* on ELF-Linux. */
	/* Modifications Copyright (C) 1996 Heiner Schwarte */
	/* Minor cleanup and bug fix (C) 1996 Ross Ihaka */


#ifdef SHL
#include <dl.h>
#else
#include <dlfcn.h>
#endif
	/* The dlopen function returns a handle after successfully */
	/* loading a library. These handles are collected in a list. */

struct voidptrlist{
#ifdef SHL
	shl_t *ptr;
#else
	void *ptr;
#endif
	struct voidptrlist *next;
};

static struct voidptrlist *list=NULL;

#ifdef SHL
static void add_ptr(shl_t *p)
#else
static void add_ptr(void *p)
#endif
{
	struct voidptrlist *tmp;
	if (p==NULL)
		return;
	tmp=(struct voidptrlist *)malloc(sizeof(struct voidptrlist));
	tmp->ptr=p;
	tmp->next=list;
	list=tmp;
}


	/* findDynProc checks whether one of the libraries */
	/* that have been loaded contains the symbol name and */
	/* returns a pointer to that symbol upon success. */

int (*findDynProc(char *name))()
{
	struct voidptrlist *tmp;
	void *fcnptr;
	char buf[64];

#ifndef SHL
	sprintf(buf, "_%s", name);
#endif
	tmp = list;
	while(tmp != NULL){
#ifdef SHL
	        if (shl_findsym(tmp->ptr, name, TYPE_PROCEDURE, &fcnptr) == 0)
#else
		if((fcnptr = dlsym(tmp->ptr, buf)) != NULL)
#endif
			return fcnptr;
		tmp = tmp->next;
	}
	return NULL;
}


	/* do_dynload implements the R-Interface for the */
	/* loading of libraries */

#ifndef RTLD_LAZY
#define RTLD_LAZY 1
#endif

/* I have no idea why this needs to be defined out here, but it does */
#ifdef SHL
shl_t handle;
#endif
SEXP do_dynload(SEXP call, SEXP op, SEXP args, SEXP env)
{
#ifndef SHL
	void *handle;
#endif
	char *error;
	checkArity(op,args);
	if (!isString(CAR(args)))
		errorcall(call, "character argument expected\n");
	/* Is BIND_DEFERRED the right thing to do? */
#ifdef SHL
	handle = shl_load(CHAR(STRING(CAR(args))[0]), BIND_DEFERRED, 0L);
	add_ptr(&handle);
#else
	handle = dlopen(CHAR(STRING(CAR(args))[0]), RTLD_LAZY);
	if(!handle) {
		error = dlerror();
		errorcall(call, error);
		free(error); 
	}
	add_ptr(handle);
#endif
	return R_NilValue;
}

#else

SEXP do_dynload(SEXP call, SEXP op, SEXP args, SEXP env)
{
	error("no dyn.load support in this R version\n");
}

#endif




#define NIL -1

typedef int (*FUNC) ();

typedef struct {
	char *name;
	FUNC func;
} CFunTabEntry;

#ifdef no_f77_underscore
# define F77_SUBROUTINE(x) int x ## ();
#else
# define F77_SUBROUTINE(x) int x ## _();
#endif
#define C_FUNCTION(x) int x ## ();
#include "dotcode.h"
#undef F77_SUBROUTINE
#undef C_FUNCTION

#ifdef no_f77_underscore
#define F77_SUBROUTINE(x) {#x, x},
#else
#define F77_SUBROUTINE(x) {#x ## "_", x ## _ },
#endif
#define C_FUNCTION(x) {#x, x },
static CFunTabEntry CFunTab[] =
{
#include "dotcode.h"
	{NULL, NULL}
};
#undef F77_SUBROUTINE
#undef C_FUNCTION


	/* HashTable stores name - pointer pairs. Open addressing */
	/* with linear probing is used. Sometimes the hashtable */
	/* will be expanded and reorganized. The implementation */
	/* is entirely elementary.  Possible sizes of the */
	/* table are 2^p+1 where p is a positive integer. */

static CFunTabEntry *HashTable;
static int HASHSIZE;
static int NumberElem;


static int HashCode(char *symbol)
{
	unsigned int  code=0;
	char *p = symbol;

	while (*p)
		code = 8 * code + *p++;
	return code % HASHSIZE;
}


static void HashInstall(char *name, FUNC func)
{
	int key;
	NumberElem++;
	key = HashCode(name);
	while (HashTable[key].name != NULL)
		key = (key + 1) % HASHSIZE;
	HashTable[key].name = (char*)malloc(strlen(name)+1);
	strcpy(HashTable[key].name,name);
	HashTable[key].func = func;
}

static void HashExpand()
{
	int oldsize;
	int i;
	CFunTabEntry *OldTable;
	oldsize=HASHSIZE;
	OldTable=HashTable;
	HASHSIZE=2*HASHSIZE-1;
	NumberElem=0;
	HashTable = (CFunTabEntry *) malloc(HASHSIZE * sizeof(CFunTabEntry));
	for (i = 0; i < HASHSIZE; i++)
		HashTable[i].name = NULL;
	for(i=0;i<oldsize;i++) {
		if(OldTable[i].name!=NULL)
			HashInstall(OldTable[i].name,OldTable[i].func);
	}	
	for(i=0;i<oldsize;i++)
		free(OldTable[i].name);
	free(OldTable);
}

static FUNC HashLookup(char *symbol)
{
	int key;
	key = HashCode(symbol);
	while (HashTable[key].name != NULL) {
		if (strcmp(symbol, HashTable[key].name) == 0)
			return HashTable[key].func;
		else
			key = (key + 1) % HASHSIZE;
	}
	return NULL;
}


	/* Initialization of the hashed load table */

static SEXP NaokSymbol;

void InitFunctionHashing()
{
	int n;
	int i, size = 3;
	NaokSymbol = install("NAOK");
	n = sizeof(CFunTab)/sizeof(CFunTabEntry);
	while(size < n)
		size = 2*size-1;
	HASHSIZE = size;	
	NumberElem = 0;
	HashTable = (CFunTabEntry*) malloc(HASHSIZE * sizeof(CFunTabEntry));
	for (i = 0; i < HASHSIZE; i++)
		HashTable[i].name = NULL;
	for (i = 0; CFunTab[i].name; i++)
		HashInstall(CFunTab[i].name, CFunTab[i].func);
	HashExpand();
}

	/* Convert an R object to a non-moveable C object */
	/* and return a pointer to it.  This leaves pointers */
	/* for anything other than vectors and lists unaltered. */

static void *RObjToCPtr(SEXP s, int naok)
{
	int *iptr;
	double *rptr;
	char **cptr;
	int i, l, n;

	switch(TYPEOF(s)) {
		case LGLSXP:
		case FACTSXP:
		case ORDSXP:
		case INTSXP:
			n = LENGTH(s);
			iptr = (int*)R_alloc(n, sizeof(int));
			for(i=0 ; i<n ; i++) {
				iptr[i] = INTEGER(s)[i];
				if(!naok && iptr[i] == NA_INTEGER)
					error("NAs non permitted in foreign function calls\n");
			}
			return (void*)iptr;
			break;
		case REALSXP:
			n = LENGTH(s);
			rptr = (double*)R_alloc(n, sizeof(double));
			for(i=0 ; i<n ; i++) {
				rptr[i] = REAL(s)[i];
				if(!naok && rptr[i] == NA_REAL)
					error("NAs non permitted in foreign function calls\n");
			}
			return (void*)rptr;
			break;
		case STRSXP:
			n = LENGTH(s);
			cptr = (char**)R_alloc(n, sizeof(char*));
			for(i=0 ; i<n ; i++) {
				l = strlen(CHAR(STRING(s)[i]));
				cptr[i] = (char*)R_alloc(l+1, sizeof(char));
				strcpy(cptr[i], CHAR(STRING(s)[i]));
			}
			return (void*)cptr;
			break;
		case LISTSXP:
			n = length(s);
			cptr = (char**)R_alloc(n, sizeof(char*));
			for(i=0 ; i<n ; i++) {
				cptr[i] = (char*)s;
				s = CDR(s);
			}
			return (void*)cptr;
		default:
			return (char*)s;
	}
}

static SEXP CPtrToRObj(void *p, int n, SEXPTYPE type)
{
	int *iptr;
	double *rptr;
	char **cptr;
	SEXP *lptr;
	int i;
	SEXP s, t;

	switch(type) {
		case LGLSXP:
		case FACTSXP:
		case ORDSXP:
		case INTSXP:
			s = allocVector(type, n);
			iptr = (int*)p;
			for(i=0 ; i<n ; i++) {
				INTEGER(s)[i] = iptr[i];
			}
			break;
		case REALSXP:
			s = allocVector(type, n);
			rptr = (double*)p;
			for(i=0 ; i<n ; i++) {
				REAL(s)[i] = rptr[i];
			}
			break;
		case STRSXP:
			PROTECT(s = allocVector(type, n));
			cptr = (char**)p;
			for(i=0 ; i<n ; i++) {
				STRING(s)[i] = mkChar(cptr[i]);
			}
			UNPROTECT(1);
			break;
		case LISTSXP:
			PROTECT(t = s = allocList(n));
			lptr = (SEXP*)p;
			for(i=0 ; i<n ; i++) {
				CAR(t) = lptr[i];
				t = CDR(t);
			}
			UNPROTECT(1);
		default:
			s = (SEXP)p;
	}
	return s;
}

	/* Foreign Function Interface.  This code allows a */
	/* user to call C or Fortran code which is either */
	/* statically or dynamically linked into R. */


static SEXP naoktrim(SEXP s, int * len, int *naok)
{
	SEXP value;

	if(s == R_NilValue) {
		value = R_NilValue;
		*naok = 0;
		*len = 0;
	}
	else if(TAG(s) == NaokSymbol) {
		value = naoktrim(CDR(s), len, naok);
		*naok = asLogical(CAR(s));
	}
	else {
		CDR(s) = naoktrim(CDR(s), len, naok);
		*len = *len + 1;
	}
	return s;
}

#define MAX_ARGS 35

SEXP do_dotCode(SEXP call, SEXP op, SEXP args, SEXP env)
{
	void **cargs;
	int naok, nargs, which;
	FUNC fun;
	SEXP pargs, s;
	char buf[128], *p, *q, *vmax;
	
	vmax = vmaxget();
	which = PRIMVAL(op);

	op = CAR(args);
	if (!isString(op))
		errorcall(call, "function name must be a string\n");
	
	args = naoktrim(CDR(args), &nargs, &naok);
	if(naok == NA_LOGICAL)
		errorcall(call, "invalid naok value\n");
	if(nargs > MAX_ARGS)
		errorcall(call, "too many arguments in foreign function call\n");
	cargs = (void**)R_alloc(nargs, sizeof(void*));
	
		/* Convert the arguments for use in foreign */
		/* function calls.  Note that we copy twice */
		/* once here, on the way into the call, and */
		/* once below on the way out. */

	nargs = 0;
	for(pargs = args ; pargs != R_NilValue; pargs = CDR(pargs)) {
		cargs[nargs++] = RObjToCPtr(CAR(pargs), naok);
	}
	
	/* make up load symbol & look it up */
	
	p = CHAR(STRING(op)[0]);
	q = buf;
	while ((*q = *p) != '\0') {
		p++;
		q++;
	}
#ifdef no_f77_underscore
#else
	if (which)
		*q++ = '_';
	*q = '\0';
#endif
	if (!(fun = HashLookup(buf))){
#ifdef DLSupport
		if(!(fun = findDynProc(buf))) {
			errorcall(call, "C/Fortran function not in load table\n");
		}
		else {
			if((1.0*NumberElem)/HASHSIZE > 0.5)
				HashExpand();
			HashInstall(buf,fun);
		}
#else
		errorcall(call, "C/Fortran function not in load table\n");
#endif
	}
	
	switch (nargs) {
	case 0:
		/* Silicon graphics C chokes if there is */
		/* no argument to fun */
		fun(0);
		break;
	case 1:
		fun(cargs[0]);
		break;
	case 2:
		fun(cargs[0], cargs[1]);
		break;
	case 3:
		fun(cargs[0], cargs[1], cargs[2]);
		break;
	case 4:
		fun(cargs[0], cargs[1], cargs[2], cargs[3]);
		break;
	case 5:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4]);
		break;
	case 6:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5]);
		break;
	case 7:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6]);
		break;
	case 8:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6],  cargs[7]);
		break;
	case 9:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6],  cargs[7],  cargs[8]);
		break;
	case 10:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6],  cargs[7],  cargs[8],  cargs[9]);
		break;
	case 11:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6],  cargs[7],  cargs[8],  cargs[9],
		    cargs[10]);
		break;
	case 12:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6],  cargs[7],  cargs[8],  cargs[9],
		    cargs[10], cargs[11]);
		break;
	case 13:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6],  cargs[7],  cargs[8],  cargs[9],
		    cargs[10], cargs[11], cargs[12]);
		break;
	case 14:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6],  cargs[7],  cargs[8],  cargs[9],
		    cargs[10], cargs[11], cargs[12], cargs[13]);
		break;
	case 15:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6],  cargs[7],  cargs[8],  cargs[9],
		    cargs[10], cargs[11], cargs[12], cargs[13], cargs[14]);
		break;
	case 16:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6],  cargs[7],  cargs[8],  cargs[9],
		    cargs[10], cargs[11], cargs[12], cargs[13], cargs[14],
		    cargs[15]);
		break;
	case 17:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6],  cargs[7],  cargs[8],  cargs[9],
		    cargs[10], cargs[11], cargs[12], cargs[13], cargs[14],
		    cargs[15], cargs[16]);
		break;
	case 18:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6],  cargs[7],  cargs[8],  cargs[9],
		    cargs[10], cargs[11], cargs[12], cargs[13], cargs[14],
		    cargs[15], cargs[16], cargs[17]);
		break;
	case 19:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6],  cargs[7],  cargs[8],  cargs[9],
		    cargs[10], cargs[11], cargs[12], cargs[13], cargs[14],
		    cargs[15], cargs[16], cargs[17], cargs[18]);
		break;
	case 20:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6],  cargs[7],  cargs[8],  cargs[9],
		    cargs[10], cargs[11], cargs[12], cargs[13], cargs[14],
		    cargs[15], cargs[16], cargs[17], cargs[18], cargs[19]);
		break;
	case 21:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6],  cargs[7],  cargs[8],  cargs[9],
		    cargs[10], cargs[11], cargs[12], cargs[13], cargs[14],
		    cargs[15], cargs[16], cargs[17], cargs[18], cargs[19],
		    cargs[20]);
		break;
	case 22:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6],  cargs[7],  cargs[8],  cargs[9],
		    cargs[10], cargs[11], cargs[12], cargs[13], cargs[14],
		    cargs[15], cargs[16], cargs[17], cargs[18], cargs[19],
		    cargs[20], cargs[21]);
		break;
	case 23:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6],  cargs[7],  cargs[8],  cargs[9],
		    cargs[10], cargs[11], cargs[12], cargs[13], cargs[14],
		    cargs[15], cargs[16], cargs[17], cargs[18], cargs[19],
		    cargs[20], cargs[21], cargs[22]);
		break;
	case 24:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6],  cargs[7],  cargs[8],  cargs[9],
		    cargs[10], cargs[11], cargs[12], cargs[13], cargs[14],
		    cargs[15], cargs[16], cargs[17], cargs[18], cargs[19],
		    cargs[20], cargs[21], cargs[22], cargs[23]);
		break;
	case 25:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6],  cargs[7],  cargs[8],  cargs[9],
		    cargs[10], cargs[11], cargs[12], cargs[13], cargs[14],
		    cargs[15], cargs[16], cargs[17], cargs[18], cargs[19],
		    cargs[20], cargs[21], cargs[22], cargs[23], cargs[24]);
		break;
	case 26:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6],  cargs[7],  cargs[8],  cargs[9],
		    cargs[10], cargs[11], cargs[12], cargs[13], cargs[14],
		    cargs[15], cargs[16], cargs[17], cargs[18], cargs[19],
		    cargs[20], cargs[21], cargs[22], cargs[23], cargs[24],
		    cargs[25]);
		break;
	case 27:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6],  cargs[7],  cargs[8],  cargs[9],
		    cargs[10], cargs[11], cargs[12], cargs[13], cargs[14],
		    cargs[15], cargs[16], cargs[17], cargs[18], cargs[19],
		    cargs[20], cargs[21], cargs[22], cargs[23], cargs[24],
		    cargs[25], cargs[26]);
		break;
	case 28:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6],  cargs[7],  cargs[8],  cargs[9],
		    cargs[10], cargs[11], cargs[12], cargs[13], cargs[14],
		    cargs[15], cargs[16], cargs[17], cargs[18], cargs[19],
		    cargs[20], cargs[21], cargs[22], cargs[23], cargs[24],
		    cargs[25], cargs[26], cargs[27]);
		break;
	case 29:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6],  cargs[7],  cargs[8],  cargs[9],
		    cargs[10], cargs[11], cargs[12], cargs[13], cargs[14],
		    cargs[15], cargs[16], cargs[17], cargs[18], cargs[19],
		    cargs[20], cargs[21], cargs[22], cargs[23], cargs[24],
		    cargs[25], cargs[26], cargs[27], cargs[28]);
		break;
	case 30:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6],  cargs[7],  cargs[8],  cargs[9],
		    cargs[10], cargs[11], cargs[12], cargs[13], cargs[14],
		    cargs[15], cargs[16], cargs[17], cargs[18], cargs[19],
		    cargs[20], cargs[21], cargs[22], cargs[23], cargs[24],
		    cargs[25], cargs[26], cargs[27], cargs[28], cargs[29]);
		break;
	case 31:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6],  cargs[7],  cargs[8],  cargs[9],
		    cargs[10], cargs[11], cargs[12], cargs[13], cargs[14],
		    cargs[15], cargs[16], cargs[17], cargs[18], cargs[19],
		    cargs[20], cargs[21], cargs[22], cargs[23], cargs[24],
		    cargs[25], cargs[26], cargs[27], cargs[28], cargs[29],
		    cargs[30]);
		break;
	case 32:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6],  cargs[7],  cargs[8],  cargs[9],
		    cargs[10], cargs[11], cargs[12], cargs[13], cargs[14],
		    cargs[15], cargs[16], cargs[17], cargs[18], cargs[19],
		    cargs[20], cargs[21], cargs[22], cargs[23], cargs[24],
		    cargs[25], cargs[26], cargs[27], cargs[28], cargs[29],
		    cargs[30], cargs[31]);
		break;
	case 33:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6],  cargs[7],  cargs[8],  cargs[9],
		    cargs[10], cargs[11], cargs[12], cargs[13], cargs[14],
		    cargs[15], cargs[16], cargs[17], cargs[18], cargs[19],
		    cargs[20], cargs[21], cargs[22], cargs[23], cargs[24],
		    cargs[25], cargs[26], cargs[27], cargs[28], cargs[29],
		    cargs[30], cargs[31], cargs[32]);
		break;
	case 34:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6],  cargs[7],  cargs[8],  cargs[9],
		    cargs[10], cargs[11], cargs[12], cargs[13], cargs[14],
		    cargs[15], cargs[16], cargs[17], cargs[18], cargs[19],
		    cargs[20], cargs[21], cargs[22], cargs[23], cargs[24],
		    cargs[25], cargs[26], cargs[27], cargs[28], cargs[29],
		    cargs[30], cargs[31], cargs[32], cargs[33]);
		break;
	case 35:
		fun(cargs[0],  cargs[1],  cargs[2],  cargs[3],  cargs[4],
		    cargs[5],  cargs[6],  cargs[7],  cargs[8],  cargs[9],
		    cargs[10], cargs[11], cargs[12], cargs[13], cargs[14],
		    cargs[15], cargs[16], cargs[17], cargs[18], cargs[19],
		    cargs[20], cargs[21], cargs[22], cargs[23], cargs[24],
		    cargs[25], cargs[26], cargs[27], cargs[28], cargs[29],
		    cargs[30], cargs[31], cargs[32], cargs[33], cargs[34]);
		break;
	default:
		errorcall(call, "too many arguments, sorry\n");
	}

	nargs = 0;
	for(pargs=args ; pargs != R_NilValue ; pargs=CDR(pargs)) {
		PROTECT(s = CPtrToRObj(cargs[nargs], LENGTH(CAR(pargs)),
				TYPEOF(CAR(pargs))));
		ATTRIB(s) = duplicate(ATTRIB(CAR(pargs)));
		CAR(pargs) = s;
		nargs++;
		UNPROTECT(1);
	}
	vmaxset(vmax);
	return (args);
}

static struct {
	char *name;
	SEXPTYPE type;
} typeinfo[] = {
	{"logical",	LGLSXP},
	{"integer",	INTSXP},
	{"double",	REALSXP},
	{"character",	STRSXP},
	{"list",	LISTSXP},
	{NULL,		0}
};

static int string2type(char *s)
{
	int i;
	for(i=0 ; typeinfo[i].name ; i++) {
		if(!strcmp(typeinfo[i].name, s)) {
			return typeinfo[i].type;
		}
	}
	error("type \"%s\" not supported in interlanguage calls\n", s);
}

void call_R(char *func, long nargs, void **arguments, char **modes,
	long *lengths, char **names, long nres, char **results)
{
	SEXP call, pcall, s;
	SEXPTYPE type;
	int i, j, n;

	if(!isFunction((SEXP)func))
		error("invalid function in call_R\n");
	if(nargs < 0)
		error("invalid argument count in call_R\n");
	if(nres < 0)
		error("invalid return value count in call_R\n");
	PROTECT(pcall = call = allocList(nargs+1));
	TYPEOF(call) = LANGSXP;
	CAR(pcall) = (SEXP)func;

	for(i=0 ; i<nargs ; i++) {
		pcall = CDR(pcall);
		type = string2type(modes[i]);
		switch(type) {
		case LGLSXP:
		case INTSXP:
			CAR(pcall) = allocSExp(type);
			INTEGER(CAR(pcall)) = (int*)(arguments[i]);
			LENGTH(CAR(pcall)) = lengths[i];
			break;
		case REALSXP:
			CAR(pcall) = allocSExp(REALSXP);
			REAL(CAR(pcall)) = (double*)(arguments[i]);
			LENGTH(CAR(pcall)) = lengths[i];
			break;
		case STRSXP:
			n = lengths[i];
			CAR(pcall) = allocVector(STRSXP, n);
			for(j=0 ; j<n ; j++) {
				s = allocSExp(CHARSXP);
				CHAR(s) = (char*)(arguments[i]);
				LENGTH(s) = strlen(CHAR(s));
				STRING(CAR(pcall))[i] = s;
			}
			break;
		case LISTSXP:
			n = lengths[i];
			CAR(pcall) = allocList(n);
			s = CAR(pcall);
			for(j=0 ; j<n ; j++) {
				CAR(s) = (SEXP)(arguments[i]);
				s = CDR(s);
			}
			break;
		}
		if(names && names[i])
			TAG(pcall) = install(names[i]);
		NAMED(CAR(pcall)) = 2;
	}

	PROTECT(s = eval(call, R_GlobalEnv));

	switch(TYPEOF(s)) {
	case LGLSXP:
	case INTSXP:
	case REALSXP:
	case STRSXP:
		if(nres > 0)
			results[0] = RObjToCPtr(s, 1);
		break;
	case LISTSXP:
		n = length(s);
		if(nres < n) n = nres;
		for(i=0 ; i<n ; i++) {
			results[i] = RObjToCPtr(s, 1);
			s = CDR(s);
		}
	}
	UNPROTECT(2);
	return;
}

void call_S(char *func, long nargs, void **arguments, char **modes,
	long *lengths, char **names, long nres, char **results)
{
	call_R(func, nargs, arguments, modes,
		lengths, names, nres, results);
}

