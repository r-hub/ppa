	/* This file is included to define platform dependent */
	/* behavior.  The main thing here is to work out the */
	/* way in  Fortran and C communicate.  The macros below */
	/* are for the traditional postpend "_" to symbol names */
	/* recipe.  The HP.h file has a recipe for no "_" */

#ifndef _PLATFORM_H_
#define _PLATFORM_H_

#define SunOS
#define Unix
#define PosixArith
#define DLSupport
#define Proctime
#define F77_SYMBOL(x)	x ## _
#define F77_QSYMBOL(x)	#x ## "_"

#endif
