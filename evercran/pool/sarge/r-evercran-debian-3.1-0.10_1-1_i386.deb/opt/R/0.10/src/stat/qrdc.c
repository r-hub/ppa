/*
 *     DQRDC2 uses Householder transformations to compute the QR
 *     factorization of an n by p matrix x.  A limited column
 *     pivoting strategy based on the 2-norms of the reduced columns
 *     moves columns with near-zero norm to the right-hand edge of
 *     the x matrix.  This strategy means that sequential one
 *     degree-of-freedom effects can be computed in a natural way.
 *
 *     I am very nervous about modifying linpack code in this way.
 *     If you are a computational linear algebra guru and you really
 *     understand how to solve this problem please feel free to
 *     suggest improvements to this code.
 *
 *     On Entry
 *
 *        x       double(ldx, p),  where ldx >= n.
 *                x contains the matrix whose decomposition is to be
 *                computed.
 *
 *        ldx     int
 *                ldx is the leading dimension of the array x.
 *
 *        n       int
 *                n is the number of rows of the matrix x.
 *
 *        p       int
 *                p is the number of columns of the matrix x.
 *
 *        tol     double
 *                tol is the nonnegative tolerance used to
 *                determine the subset of the columns of x
 *                included in the solution.
 *
 *        jpvt    int(p)
 *                integers which are swapped in the same way as the
 *                the columns of x during pivoting.  on entry these
 *                should be set equal to the column indices of the
 *                columns of the x matrix (typically 1 to p).
 *
 *        work    double(p, 2)
 *                work is a work array.
 *
 *     On Return
 *
 *        x       x contains in its upper triangle the upper
 *                triangular matrix r of the QR factorization.
 *                below its diagonal x contains information from
 *                which the orthogonal part of the decomposition
 *                can be recovered.  Note that if pivoting has
 *                occurred,  the decomposition is not that
 *                of the original matrix x but that of x
 *                with its columns permuted as described by jpvt.
 *
 *        k       int
 *                k contains the number of columns of x judged
 *                to be linearly independent.
 *
 *        qraux   double(p)
 *                qraux contains further information required to recover
 *                the orthogonal part of the decomposition.
 *
 *        jpvt    jpvt(k) contains the index of the column of the
 *                original matrix that has been interchanged into
 *                the k-th column,  if pivoting was requested.
 *
 *     This version dated 22 august 1995
 *     Ross Ihaka
 */

#include "Linpack.h"

void DQRDC2(double *x, int ldx, int n, int p,
	double tol, int *k, double *qraux, int *jpvt, double *work)
{
	double *work1, *work2;
	double nrmxl, t, tt, ttt;
	int i, j, l, lp1, lup;

	x -= (ldx + 1);
	work1 = (work - 1);
	work2 = (work + p);
	qraux -= 1;
	jpvt -= 1;

		/* compute the norms of the columns of x */

	for(j=1 ; j<=p ; j++) {
		qraux[j] = DNRM2(n, &x[1+j*ldx], 1);
		work1[j] = qraux[j];
		work2[j] = qraux[j];
	}

		/* perform the householder reduction of x */

	lup = imin(n, p);
	*k = lup + 1;
	for(l=1 ; l<=lup ; l++) {
		while (l < *k  &&  qraux[l] < work2[l]*tol) {
			lp1 = l+1;
			for(i=1 ; i<=n ; i++) {
				t = x[i+l*ldx];
				for(j=lp1 ; j<=lup ; j++)
					x[i+(j-1)*ldx] = x[i+j*ldx];
				x[i+lup*ldx] = t;
			}
			i = jpvt[l];
			t = qraux[l];
			tt = work1[l];
			ttt = work2[l];
			for(j=lp1 ; j<=lup ; j++) {
				jpvt[j-1] = jpvt[j];
				qraux[j-1] = qraux[j];
				work1[j-1] = work1[j];
				work2[j-1] = work2[j];
			}
			jpvt[lup] = i;
			qraux[lup] = t;
			work1[lup] = tt;
			work2[lup] = ttt;
			*k = *k - 1;
		}
		if (l!=n) {
	
			/* compute the householder transformation for column l */

			nrmxl = DNRM2(n-l+1, &x[l+l*ldx], 1);
			if (nrmxl != 0.0) {
				if (x[l+l*ldx] != 0.0)
					nrmxl = fsign(nrmxl, x[l+l*ldx]);
				DSCAL(n-l+1, 1.0/nrmxl, &x[l+l*ldx], 1);
				x[l+l*ldx] = 1.0+x[l+l*ldx];

				/* apply the transformation to the */
				/* remaining columns, updating the norms. */

				lp1 = l+1;
				if (p >= lp1)
					for(j=lp1 ; j<=p ; j++) {
						t = -DDOT(n-l+1, &x[l+l*ldx], 1, &x[l+j*ldx], 1)/x[l+l*ldx];
						DAXPY(n-l+1, t, &x[l+l*ldx], 1, &x[l+j*ldx], 1);
						if (qraux[j] != 0.0) {
							tt = 1.0-fsquare(fabs(x[l+j*ldx])/qraux[j]);
							tt = fmax(tt, 0.0);
							t = tt;
							tt = 1.0+0.05*tt*fsquare(qraux[j]/work1[j]);
							if (tt != 1.0)
								qraux[j] = qraux[j]*sqrt(t);
							else {
								qraux[j] = DNRM2(n-l, &x[l+1+j*ldx], 1);
								work1[j] = qraux[j];
							}
						}
					}

				/* save the transformation */

				qraux[l] = x[l+l*ldx];
				x[l+l*ldx] = -nrmxl;
			}
		}
	}
	*k = *k - 1;
}

/*
 *     DQRLS is a subroutine to compute least squares solutions
 *     to the system
 *
 *     (1)               x * b = y
 *
 *     which may be either under-determined or over-determined.
 *     the user must supply a tolerance to limit the columns of
 *     x used in computing the solution.  In effect, a set of
 *     columns with a condition number approximately bounded by
 *     1/tol is used, the other components of b being set to zero.
 *
 *     On Entry
 *
 *        x      double(n,p).
 *               x contains n-by-p coefficient matrix of
 *               the system (1), x is destroyed by DQRLS.
 *
 *        n      the number of rows of the matrix x.
 *
 *        p      the number of columns of the matrix x.
 *
 *        y      double(n,ny)
 *               y contains the right hand side(s) of the system (1).
 *
 *        ny     the number of right hand sides of the system (1).
 *
 *        tol    double
 *               tol is the nonnegative tolerance used to
 *               determine the subset of columns of x included
 *               in the solution.  columns are pivoted out of
 *               decomposition if
 *
 *        jpvt   int(p)
 *               the values in jpvt are permuted in the same
 *               way as the columns of x.  this can be useful
 *               in unscrambling coefficients etc.
 *
 *        work   double(2*p)
 *               work is an array used by DQRDC2 and DQRSL.
 *
 *     On Return
 *
 *        x      contains the output array from DQRDC2.
 *               namely the QR decomposition of x stored in
 *               compact form.
 *
 *        b      double(p,ny)
 *               b contains the solution vectors with rows permuted
 *               in the same way as the columns of x.  components
 *               corresponding to columns not used are set to zero.
 *
 *        rsd    double(n,ny)
 *               rsd contains the residual vectors y-x*b.
 *
 *        qty    double(n,ny)               t
 *               qty contains the vectors  q y.   note that
 *               the initial p elements of this vector are
 *               permuted in the same way as the columns of x.
 *
 *        k      int
 *               k contains the number of columns used in the
 *               solution.
 *
 *        jpvt   has its contents permuted as described above.
 *
 *        qraux  double(p)
 *               qraux contains auxiliary information on the
 *               QR decomposition of x.
 *
 *
 *     On return the arrays x, jpvt and qraux contain the
 *     usual output from dqrdc, so that the QR decomposition
 *     of x with pivoting is fully available to the user.
 *     in particular, columns jpvt(1), jpvt(2),...,jpvt(k)
 *     were used in the solution, and the condition number
 *     associated with those columns is estimated by
 *     abs(x(1,1)/x(k,k)).
 *
 *     DQRLS uses the routines DQRDC2 and DQRSL.
 */


static void DQRLS(double *x, int n, int p, double *y, int ny, double tol,
	double *b, double *rsd, double *qty, int *k, int *jpvt,
	double *qraux, double *work)
{
	int info, j, jj, job, kk, m;
	double t;

		/* reduce x */

	DQRDC2(x, n, n, p, tol, k, qraux, jpvt, work);

	/* solve the truncated least squares problem for each rhs */

	job = 1110;

	if (*k != 0)
		for(jj=0 ; jj<ny ; jj++)
			DQRSL(x, n, n, *k, qraux, &y[jj*n],
				&rsd[jj*n], &qty[jj*n], &b[jj*p],
				&rsd[jj*n], &rsd[jj*n], job, &info);

		/* set the unused components of b to zero */

	b -= (p + 1);

	kk = *k + 1;
	for(j=kk ; j<=p ; j++)
		for(jj=1 ; jj<ny ; jj++)
			b[j+jj*p] = 0.0;
}

		/*  P u b l i c   I n t e r f a c e s  */

/*
 *     qr_dc performs a QR decomposition.  It is just a wrapper
 *     around the routine DQRDC2.
 */

int qr_dc(double *x, int *ldx, int *n, int *p,
	double *tol, int *k, double *qraux, int *jpvt, double *work)
{
	DQRDC2(x, *ldx, *n, *p, *tol, k, qraux, jpvt, work);
}


/*
 *     qrls solves least squares problems.  It is in fact just a
 *     wrapper around the routines DQRDC2 and DQRSL.
 */

int qr_ls(double *x, int *n, int *p, double *y, int *ny, double *tol,
	double *b, double *rsd, double *qty, int *k, int *jpvt,
	double *qraux, double *work)
{
	DQRLS(x, *n, *p, y, *ny, *tol, b, rsd, qty, k, jpvt, qraux, work);
}

/*
 *     Code to pull out various components of the least-squares
 *     solution to the problem norm2(y-xb) = min.  these are
 *     just wrappers around the linpack routine dqrsl.
 */

int qr_qty(double *x, int *n, int *k, double *qraux,
	double *y, int *ny, double *qty)
{
	int info, j;
	double dum;

	for(j=0; j<*ny ; j++)
		DQRSL(x, *n, *n, *k, qraux, &y[j*(*n)], &dum, &qty[j*(*n)],
			&dum, &dum, &dum, 1000, &info);
}

int qr_qy(double *x, int *n, int *k, double *qraux,
	double *y, int *ny, double *qy)
{
	int info, j;
	double dum;

	for(j=0; j<*ny ; j++)
		DQRSL(x, *n, *n, *k, qraux, &y[j*(*n)], &qy[j*(*n)],
			&dum,  &dum, &dum, &dum, 10000, &info);
}

int qr_cf(double *x, int *n, int *k, double *qraux,
	double *y, int *ny, double *b, int *info)
{
	int j;
	double dum;

	for(j=0; j<*ny ; j++)
		DQRSL(x, *n, *n, *k, qraux, &y[j*(*n)], &dum,
			&y[j*(*n)], &b[j*(*k)], &dum, &dum, 100, info);
}

int qr_rsd(double *x, int *n, int *k, double *qraux,
	double *y, int *ny, double *rsd)
{
	int info, j;
	double dum;

	for(j=0; j<*ny ; j++)
		DQRSL(x, *n, *n, *k, qraux, &y[j*(*n)], &dum,
			&y[j*(*n)], &dum, &rsd[j*(*n)], &dum, 10, &info);
}

int qr_xb(double *x, int *n, int *k, double *qraux,
	double *y, int *ny, double *xb)
{
	int info, j;
	double dum;

	for(j=0; j<*ny ; j++)
		DQRSL(x, *n, *n, *k, qraux, &y[j*(*n)], &dum,
			&y[j*(*n)], &dum, &dum, &xb[j*(*n)], 1, &info);
}
