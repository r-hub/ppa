#ifndef _PLATFORM_H_
#define _PLATFORM_H_

#define HP
#define SHL
#define Unix
#define PosixArith
#define DLSupport
#define Proctime
#define F77_SYMBOL(x)	x
#define F77_QSYMBOL(x)	#x

#endif
