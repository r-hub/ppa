/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DPOFA factors a double symmetric positive definite
 *     matrix.
 *
 *     DPOFA is usually called by DPOCO, but it can be called
 *     directly with a saving in time if  rcond  is not needed.
 *     (time for DPOCO) = (1 +18/n)*(time for DPOFA).
 *
 *     On Entry
 *
 *        a       double(lda, n)
 *                the symmetric matrix to be factored.  only the
 *                diagonal and upper triangle are used.
 *
 *        lda     int
 *                the leading dimension of the array  a.
 *
 *        n       int
 *                the order of the matrix  a.
 *
 *     On Return
 *
 *        a       an upper triangular matrix  r  so that  a = trans(r)*r
 *                where  trans(r)  is the transpose.
 *                the strict lower triangle is unaltered.
 *                if  info != 0 , the factorization is not complete.
 *
 *        info    int*
 *                = 0  for normal return.
 *                = k  signals an error condition.  the leading minor
 *                     of order  k  is not positive definite.
 *
 *     LINPACK.  This version dated 08/14/78 .
 *     Cleve Moler, University of New Mexico, Argonne National Lab.
 *     C Translation by Ross Ihaka.
 */

void DPOFA(double *a, int lda, int n, int *info)
{
	double ddot, t;
	double s;
	int j, jm1, k;
	
	a -= (lda+1);

	for(j=1 ; j <= n  ; j++) {
		*info = j;
		s = 0.0;
		jm1 = j-1;
		if(jm1 >= 1)
			for(k=1 ; k <= jm1  ; k++) {
				t = a[k+j*lda]-DDOT(k-1, &a[1+k*lda], 1, &a[1+j*lda], 1);
				t = t/a[k+k*lda];
				a[k+j*lda] = t;
				s = s+t*t;
			}
		s = a[j+j*lda]-s;
		if(s <= 0.0)
			return;
		a[j+j*lda] = sqrt(s);
	}
	*info = 0;
	return;
}

int dpofa_(double *a, int *lda, int *n, int *info)
{
	DPOFA(a, *lda, *n, info);
}
