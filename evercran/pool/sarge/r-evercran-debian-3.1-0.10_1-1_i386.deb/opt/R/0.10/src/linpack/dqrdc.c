/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DQRDC uses householder transformations to compute the qr
 *     factorization of an n by p matrix x.  column pivoting
 *     based on the 2-norms of the reduced columns may be
 *     performed at the users option.
 *
 *     on entry
 *
 *        x       double(ldx,p), where ldx >= n.
 *                x contains the matrix whose decomposition is to be
 *                computed.
 *
 *        ldx     int.
 *                ldx is the leading dimension of the array x.
 *
 *        n       int.
 *                n is the number of rows of the matrix x.
 *
 *        p       int.
 *                p is the number of columns of the matrix x.
 *
 *        jpvt    int(p).
 *                jpvt contains ints that control the selection
 *                of the pivot columns.  the k-th column x(k) of x
 *                is placed in one of three classes according to the
 *                value of jpvt(k).
 *
 *                   if jpvt(k) > 0, then x(k) is an initial
 *                                      column.
 *
 *                   if jpvt(k) == 0, then x(k) is a free column.
 *
 *                   if jpvt(k) < 0, then x(k) is a final column.
 *
 *                before the decomposition is computed, initial columns
 *                are moved to the beginning of the array x and final
 *                columns to the end.  both initial and final columns
 *                are frozen in place during the computation and only
 *                free columns are moved.  at the k-th stage of the
 *                reduction, if x(k) is occupied by a free column
 *                it is interchanged with the free column of largest
 *                reduced norm.  jpvt is not referenced if
 *                job == 0.
 *
 *        work    double(p).
 *                work is a work array.  work is not referenced if
 *                job == 0.
 *
 *        job     int.
 *                job is an int that initiates column pivoting.
 *                if job == 0, no pivoting is done.
 *                if job != 0, pivoting is done.
 *
 *     on return
 *
 *        x       x contains in its upper triangle the upper
 *                triangular matrix r of the qr factorization.
 *                below its diagonal x contains information from
 *                which the orthogonal part of the decomposition
 *                can be recovered.  note that if pivoting has
 *                been requested, the decomposition is not that
 *                of the original matrix x but that of x
 *                with its columns permuted as described by jpvt.
 *
 *        qraux   double(p).
 *                qraux contains further information required to recover
 *                the orthogonal part of the decomposition.
 *
 *        jpvt    jpvt(k) contains the index of the column of the
 *                original matrix that has been interchanged into
 *                the k-th column, if pivoting was requested.
 *
 *     LINPACK. This version dated 08/14/78.
 *     G.W. Stewart, University of Maryland, Argonne National Lab.
 *     C Translation by Ross Ihaka.
 */

#define x(i,j)		x[i+(j)*ldx]
#define qraux(i)	qraux[i]
#define jpvt(i)		jpvt[i]
#define work(i)		work[i]

void DQRDC(double *x, int ldx, int n, int p, double *qraux, int *jpvt, double *work, int job)
{
	int j, jj, jp, l, lp1, lup, maxj, pl, pu;
	double maxnrm, tt;
	double nrmxl, t;
	int negj, swapj;

	x -= (ldx+1);
	qraux -= 1;
	work -= 1;
	jpvt -= 1;

	pl = 1;
	pu = 0;
	if(job != 0) {

		/* pivoting has been requested.  rearrange the columns */
		/* according to jpvt. */

		for(j=1 ; j <= p  ; j++) {
			swapj = jpvt(j) > 0;
			negj = jpvt(j) < 0;
			jpvt(j) = j;
			if(negj)
				jpvt(j) = -j;
			if(swapj) {
				if(j != pl)
					DSWAP(n, &x(1, pl), 1, &x(1, j), 1);
				jpvt(j) = jpvt(pl);
				jpvt(pl) = j;
				pl = pl+1;
			}
		}
		pu = p;
		for(jj=1 ; jj <= p  ; jj++) {
			j = p-jj+1;
			if(jpvt(j) < 0) {
				jpvt(j) = -jpvt(j);
				if(j != pu) {
					DSWAP(n, &x(1, pu), 1, &x(1, j), 1);
					jp = jpvt(pu);
					jpvt(pu) = jpvt(j);
					jpvt(j) = jp;
				}
				pu = pu-1;
			}
		}
	}

	/* compute the norms of the free columns. */

	if(pu >= pl)
		for(j=pl ; j <= pu  ; j++) {
			qraux(j) = DNRM2(n, &x(1, j), 1);
			work(j) = qraux(j);
		}

	/* perform the householder reduction of x. */

	lup = imin(n, p);
	for(l=1 ; l <= lup  ; l++) {
		if(l >= pl && l < pu) {

			/* locate the column of largest norm and bring it */
			/* into the pivot position. */

			maxnrm = 0.0;
			maxj = l;
			for(j=l ; j <= pu ; j++) 
				if(qraux(j) > maxnrm) {
					maxnrm = qraux(j);
					maxj = j;
				}
			if(maxj != l) {
				DSWAP(n, &x(1, l), 1, &x(1, maxj), 1);
				qraux(maxj) = qraux(l);
				work(maxj) = work(l);
				jp = jpvt(maxj);
				jpvt(maxj) = jpvt(l);
				jpvt(l) = jp;
			}
		}
		qraux(l) = 0.0;
		if(l != n) {

			/* compute the householder transformation for column l. */

			nrmxl = DNRM2(n-l+1, &x(l, l), 1);
			if(nrmxl != 0.0) {
				if(x(l, l) != 0.0)
					nrmxl = fsign(nrmxl, x(l, l));
				DSCAL(n-l+1, 1.0/nrmxl, &x(l, l), 1);
				x(l, l) = 1.0+x(l, l);

				/* apply the transformation to the remaining columns, */
				/* updating the norms. */

				lp1 = l+1;
				if(p >= lp1)
					for(j=lp1 ; j <= p  ; j++) {
						t = -DDOT(n-l+1, &x(l, l), 1, &x(l, j), 1)/x(l, l);
						DAXPY(n-l+1, t, &x(l, l), 1, &x(l, j), 1);
						if(j >= pl && j <= pu)
							if(qraux(j) != 0.0) {
								tt = 1.0-fsquare(fabs(x(l, j))/qraux(j));
								tt = fmax(tt, 0.0);
								t = tt;
								tt = 1.0+0.05*tt*fsquare(qraux(j)/work(j));
								if(tt != 1.0)
									qraux(j) = qraux(j)*sqrt(t);
								else {
									qraux(j) = DNRM2(n-l, &x(l+1, j), 1);
									work(j) = qraux(j);
								}
							}
					}

				/* save the transformation. */

				qraux(l) = x(l, l);
				x(l, l) = -nrmxl;
			}
		}
	}
	return;
}

int dqrdc_(double *x, int *ldx, int *n, int *p, double *qraux, int *jpvt, double *work, int *job)
{
	DQRDC(x, *ldx, *n, *p, qraux, jpvt, work, *job);
}
