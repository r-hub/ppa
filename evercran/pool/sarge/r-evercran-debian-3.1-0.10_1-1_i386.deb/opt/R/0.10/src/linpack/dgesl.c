/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DGESL solves the double system
 *     a * x = b  or  trans(a) * x = b
 *     using the factors computed by DGECO or DGEFA.
 *
 *     On Entry
 *
 *        a       double(lda, n)
 *                the output from DGECO or DGEFA.
 *
 *        lda     int
 *                the leading dimension of the array  a .
 *
 *        n       int
 *                the order of the matrix  a .
 *
 *        ipvt    int(n)
 *                the pivot vector from dgeco or dgefa.
 *
 *        b       double(n)
 *                the right hand side vector.
 *
 *        job     int
 *                = 0         to solve  a*x = b ,
 *                = nonzero   to solve  trans(a)*x = b  where
 *                            trans(a)  is the transpose.
 *
 *     On Return
 *
 *        b       the solution vector  x .
 *
 *     Error Condition
 *
 *        A division by zero will occur if the input factor contains a
 *        zero on the diagonal.  Technically this indicates singularity
 *        but it is often caused by improper arguments or improper
 *        setting of lda.  It will not occur if the subroutines are
 *        called correctly and if DGECO has set rcond > 0.0
 *        or DGEFA has set info == 0 .
 *
 *     To compute  inverse(a) * c  where  c  is a matrix
 *     with  p  columns
 *           DGECO(a,lda,n,ipvt,rcond,z)
 *           if (rcond is too small) go to ...
 *           do 10 j = 1, p
 *              DGESL(a,lda,n,ipvt,c(1,j),0)
 *        10 continue
 *
 *     LINPACK. This version dated 08/14/78 .
 *     Cleve Moler, University of New Mexico, Argonne National Lab.
 *     C Translation by Ross Ihaka.
 */

void DGESL(double *a, int lda, int n, int *ipvt, double *b, int job)
{
	int k, kb, l, nm1;
	double t;

	a -= (lda+1);
	ipvt -= 1;
	b -= 1;

	nm1 = n-1;
	if(job != 0) {

		/* job = nonzero, solve  trans(a) * x = b */
		/* first solve  trans(u)*y = b */

		for(k=1 ; k <= n  ; k++) {
			t = DDOT(k-1, &a[1+ k*lda], 1, &b[1], 1);
			b[k] = (b[k]-t)/a[k+ k*lda];
		}

		/* now solve trans(l)*x = y */

		if(nm1 >= 1)
			for(kb=1 ; kb <= nm1  ; kb++) {
				k = n-kb;
				b[k] = b[k]+DDOT(n-k, &a[k+1+ k*lda], 1, &b[k+1], 1);
				l = ipvt[k];
				if(l != k) {
					t = b[l];
					b[l] = b[k];
					b[k] = t;
				}
			}
	}
	else {

		/* job = 0 , solve  a * x = b */
		/* first solve  l*y = b */

		if(nm1 >= 1)
			for(k=1 ; k <= nm1  ; k++) {
				l = ipvt[k];
				t = b[l];
				if(l != k) {
					b[l] = b[k];
					b[k] = t;
				}
				DAXPY(n-k, t, &a[k+1+ k*lda], 1, &b[k+1], 1);
			}

		/* now solve  u*x = y */

		for(kb=1 ; kb <= n  ; kb++) {
			k = n+1-kb;
			b[k] = b[k]/a[k+ k*lda];
			t = -b[k];
			DAXPY(k-1, t, &a[1+ k*lda], 1, &b[1], 1);
		}
	}
	return;
}

int dgesl_(double *a, int *lda, int *n, int *ipvt, double *b, int *job)
{
	DGESL(a, *lda, *n, ipvt, b, *job);
}
