/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DPOCO factors a double symmetric positive definite
 *     matrix and estimates the condition of the matrix.
 *
 *     If  rcond  is not needed, DPOFA is slightly faster.
 *     To solve  a*x = b , follow DPOCO by DPOSL.
 *     To compute  inverse(a)*c , follow DPOCO by DPOSL.
 *     To compute  determinant(a) , follow DPOCO by DPODI.
 *     To compute  inverse(a) , follow DPOCO by DPODI.
 *
 *     On Entry
 *
 *        a       double(lda, n)
 *                the symmetric matrix to be factored.  only the
 *                diagonal and upper triangle are used.
 *
 *        lda     int
 *                the leading dimension of the array  a.
 *
 *        n       int
 *                the order of the matrix  a.
 *
 *     On Return
 *
 *        a       an upper triangular matrix  r  so that  a = trans(r)*r
 *                where  trans(r)  is the transpose.
 *                the strict lower triangle is unaltered.
 *                if  info != 0 , the factorization is not complete.
 *
 *        rcond   double*
 *                an estimate of the reciprocal condition of  a .
 *                for the system  a*x = b , relative perturbations
 *                in  a  and  b  of size  epsilon  may cause
 *                relative perturbations in  x  of size  epsilon/rcond .
 *                if  rcond  is so small that the int expression
 *                           1.0 + rcond == 1.0
 *                is true, then  a  may be singular to working
 *                precision.  in particular,  rcond  is zero  if
 *                exact singularity is detected or the estimate
 *                underflows.  if info != 0 , rcond is unchanged.
 *
 *        z       double(n)
 *                a work vector whose contents are usually unimportant.
 *                if  a  is close to a singular matrix, then  z  is
 *                an approximate null vector in the sense that
 *                norm(a*z) = rcond*norm(a)*norm(z) .
 *                if  info != 0 , z  is unchanged.
 *
 *        info    int*
 *                = 0  for normal return.
 *                = k  signals an error condition.  the leading minor
 *                     of order  k  is not positive definite.
 *
 *     LINPACK.  This version dated 08/14/78 .
 *     Cleve Moler, University of New Mexico, Argonne National Lab.
 *     C Translation by Ross Ihaka.
 */

void DPOCO(double *a, int lda, int n, double *rcond, double *z, int *info)
{
	double ek, t, wk, wkm;
	double anorm, s, sm, ynorm;
	int i, j, jm1, k, kb, kp1;

	a -= (lda+1);
	z -= 1;

	/* find norm of a using only upper half */

	for(j=1 ; j <= n  ; j++) {
		z[j] = DASUM(j, &a[1+j*lda], 1);
		jm1 = j-1;
		if(jm1 >= 1)
			for(i=1 ; i <= jm1 ; i++) 
				z[i] = z[i]+fabs(a[i+j*lda]);
	}
	anorm = 0.0;
	for(j=1 ; j <= n ; j++) 
		anorm = fmax(anorm, z[j]);

	/* factor */

	DPOFA(&a[1+lda], lda, n, info);

	if(*info == 0) {

		/* rcond = 1/(norm(a)*(estimate of norm(inverse(a)))) . */
		/* estimate = norm(z)/norm(y) where  a*z = y  and  a*y = e . */
		/* the components of  e  are chosen to cause maximum local */
		/* growth in the elements of w  where  trans(r)*w = e . */
		/* the vectors are frequently rescaled to avoid overflow. */

		/* solve trans(r)*w = e */

		ek = 1.0;
		for(j=1 ; j <= n ; j++) 
			z[j] = 0.0;
		for(k=1 ; k <= n  ; k++) {
			if(z[k] != 0.0)
				ek = fsign(ek, -z[k]);
			if(fabs(ek-z[k]) > a[k+k*lda]) {
				s = a[k+k*lda]/fabs(ek-z[k]);
				DSCAL(n, s, &z[1], 1);
				ek = s*ek;
			}
			wk = ek-z[k];
			wkm = -ek-z[k];
			s = fabs(wk);
			sm = fabs(wkm);
			wk = wk/a[k+k*lda];
			wkm = wkm/a[k+k*lda];
			kp1 = k+1;
			if(kp1 <= n) {
				for(j=kp1 ; j <= n  ; j++) {
					sm = sm+fabs(z[j]+wkm*a[k+j*lda]);
					z[j] = z[j]+wk*a[k+j*lda];
					s = s+fabs(z[j]);
				}
				if(s < sm) {
					t = wkm-wk;
					wk = wkm;
					for(j=kp1 ; j <= n ; j++) 
						z[j] = z[j]+t*a[k+j*lda];
				}
			}
			z[k] = wk;
		}
		s = 1.0/DASUM(n, &z[1], 1);
		DSCAL(n, s, &z[1], 1);

		/* solve r*y = w */

		for(kb=1 ; kb <= n  ; kb++) {
			k = n+1-kb;
			if(fabs(z[k]) > a[k+k*lda]) {
				s = a[k+k*lda]/fabs(z[k]);
				DSCAL(n, s, &z[1], 1);
			}
			z[k] = z[k]/a[k+k*lda];
			t = -z[k];
			DAXPY(k-1, t, &a[1+k*lda], 1, &z[1], 1);
		}
		s = 1.0/DASUM(n, &z[1], 1);
		DSCAL(n, s, &z[1], 1);

		ynorm = 1.0;

		/* solve trans(r)*v = y */

		for(k=1 ; k <= n  ; k++) {
			z[k] = z[k]-DDOT(k-1, &a[1+k*lda], 1, &z[1], 1);
			if(fabs(z[k]) > a[k+k*lda]) {
				s = a[k+k*lda]/fabs(z[k]);
				DSCAL(n, s, &z[1], 1);
				ynorm = s*ynorm;
			}
			z[k] = z[k]/a[k+k*lda];
		}
		s = 1.0/DASUM(n, &z[1], 1);
		DSCAL(n, s, &z[1], 1);
		ynorm = s*ynorm;

		/* solve r*z = v */

		for(kb=1 ; kb <= n  ; kb++) {
			k = n+1-kb;
			if(fabs(z[k]) > a[k+k*lda]) {
				s = a[k+k*lda]/fabs(z[k]);
				DSCAL(n, s, &z[1], 1);
				ynorm = s*ynorm;
			}
			z[k] = z[k]/a[k+k*lda];
			t = -z[k];
			DAXPY(k-1, t, &a[1+k*lda], 1, &z[1], 1);
		}

		/* make znorm = 1.0 */

		s = 1.0/DASUM(n, &z[1], 1);
		DSCAL(n, s, &z[1], 1);
		ynorm = s*ynorm;

		if(anorm != 0.0)
			*rcond = ynorm/anorm;
		else
			*rcond = 0.0;
	}
	return;
}

int dpoco_(double *a, int *lda, int *n, double *rcond, double *z, int *info)
{
	DPOCO(a, *lda, *n, rcond, z, info);
}
