/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DSICO factors a double symmetric matrix by elimination
 *     with symmetric pivoting and estimates the condition of the
 *     matrix.
 *
 *     If  rcond  is not needed, DSIFA is slightly faster.
 *     To solve  a*x = b, follow DSICO by DSISL.
 *     To compute  inverse(a)*c, follow DSICO by DSISL.
 *     To compute  inverse(a), follow DSICO by DSIDI.
 *     To compute  determinant(a), follow DSICO by DSIDI.
 *     To compute  inertia(a), follow DSICO by DSIDI.
 *
 *     On Entry
 *
 *        a       double(lda, n)
 *                the symmetric matrix to be factored.
 *                only the diagonal and upper triangle are used.
 *
 *        lda     int
 *                the leading dimension of the array  a.
 *
 *        n       int
 *                the order of the matrix  a.
 *
 *     Output
 *
 *        a       a block diagonal matrix and the multipliers which
 *                were used to obtain it.
 *                the factorization can be written  a = u*d*trans(u)
 *                where  u  is a product of permutation and unit
 *                upper triangular matrices, trans(u) is the
 *                transpose of  u, and  d  is block diagonal
 *                with 1 by 1 and 2 by 2 blocks.
 *
 *        kpvt    int(n)
 *                an int vector of pivot indices.
 *
 *        rcond   double
 *                an estimate of the reciprocal condition of  a.
 *                for the system  a*x = b, relative perturbations
 *                in  a  and  b  of size  epsilon  may cause
 *                relative perturbations in  x  of size  epsilon/rcond.
 *                if  rcond  is so small that the int expression
 *                           1.0 + rcond == 1.0
 *                is true, then  a  may be singular to working
 *                precision.  in particular,  rcond  is zero  if
 *                exact singularity is detected or the estimate
 *                underflows.
 *
 *        z       double(n)
 *                a work vector whose contents are usually unimportant.
 *                if  a  is close to a singular matrix, then  z  is
 *                an approximate null vector in the sense that
 *                norm(a*z) = rcond*norm(a)*norm(z).
 *
 *     LINPACK. This version dated 08/14/78.
 *     Cleve Moler, University of New Mexico, Argonne National Lab.
 *     C Translation by Ross Ihaka.
 */

#define a(i,j)	a[i+(j)*lda]
#define kpvt(i)	kpvt[i]
#define z(i)	z[i]

void DSICO(double *a, int lda, int n, int *kpvt, double *rcond, double *z)
{
	double ak, akm1, bk, bkm1, denom, ek, t;
	double anorm, s, ynorm;
	int i, info, j, jm1, k, kp, kps, ks;

	a -= (lda+1);
	kpvt -= 1;
	z -= 1;

	/* find norm of a using only upper half */

	for(j=1 ; j <= n  ; j++) {
		z(j) = DASUM(j, &a(1, j), 1);
		jm1 = j-1;
		if(jm1 >= 1)
			for(i=1 ; i <= jm1 ; i++) 
				z(i) = z(i)+fabs(a(i, j));
	}
	anorm = 0.0;
	for(j=1 ; j <= n ; j++) 
		anorm = fmax(anorm, z(j));

	/* factor */

	DSIFA(&a(1,1), lda, n, &kpvt(1), &info);

	/* rcond = 1/(norm(a)*(estimate of norm(inverse(a)))). */
	/* estimate = norm(z)/norm(y) where  a*z = y  and  a*y = e. */
	/* the components of  e  are chosen to cause maximum local */
	/* growth in the elements of w  where  u*d*w = e. */
	/* the vectors are frequently rescaled to avoid overflow. */

	/* solve u*d*w = e */

	ek = 1.0;
	for(j=1 ; j <= n ; j++) 
		z(j) = 0.0;
	k = n;
	while (k != 0) {
		ks = 1;
		if(kpvt(k) < 0)
			ks = 2;
		kp = abs(kpvt(k));
		kps = k+1-ks;
		if(kp != kps) {
			t = z(kps);
			z(kps) = z(kp);
			z(kp) = t;
		}
		if(z(k) != 0.0)
			ek = fsign(ek, z(k));
		z(k) = z(k)+ek;
		DAXPY(k-ks, z(k), &a(1, k), 1, &z(1), 1);
		if(ks != 1) {
			if(z(k-1) != 0.0)
				ek = fsign(ek, z(k-1));
			z(k-1) = z(k-1)+ek;
			DAXPY(k-ks, z(k-1), &a(1, k-1), 1, &z(1), 1);
		}
		if(ks == 2) {
			ak = a(k, k)/a(k-1, k);
			akm1 = a(k-1, k-1)/a(k-1, k);
			bk = z(k)/a(k-1, k);
			bkm1 = z(k-1)/a(k-1, k);
			denom = ak*akm1-1.0;
			z(k) = (akm1*bk-bkm1)/denom;
			z(k-1) = (ak*bkm1-bk)/denom;
		}
		else {
			if(fabs(z(k)) > fabs(a(k, k))) {
				s = fabs(a(k, k))/fabs(z(k));
				DSCAL(n, s, &z(1), 1);
				ek = s*ek;
			}
			if(a(k, k) != 0.0)
				z(k) = z(k)/a(k, k);
			if(a(k, k) == 0.0)
				z(k) = 1.0;
		}
		k = k-ks;
	}
	s = 1.0/DASUM(n, &z(1), 1);
	DSCAL(n, s, &z(1), 1);

	/* solve trans(u)*y = w */

	k = 1;
	while (k <= n) {
		ks = 1;
		if(kpvt(k) < 0)
			ks = 2;
		if(k != 1) {
			z(k) = z(k)+DDOT(k-1, &a(1, k), 1, &z(1), 1);
			if(ks == 2)
				z(k+1) = z(k+1)+DDOT(k-1, &a(1, k+1), 1, &z(1), 1);
			kp = abs(kpvt(k));
			if(kp != k) {
				t = z(k);
				z(k) = z(kp);
				z(kp) = t;
			}
		}
		k = k+ks;
	}
	s = 1.0/DASUM(n, &z(1), 1);
	DSCAL(n, s, &z(1), 1);

	ynorm = 1.0;

	/* solve u*d*v = y */

	k = n;
	while (k != 0) {
		ks = 1;
		if(kpvt(k) < 0)
			ks = 2;
		if(k != ks) {
			kp = abs(kpvt(k));
			kps = k+1-ks;
			if(kp != kps) {
				t = z(kps);
				z(kps) = z(kp);
				z(kp) = t;
			}
			DAXPY(k-ks, z(k), &a(1, k), 1, &z(1), 1);
			if(ks == 2)
				DAXPY(k-ks, z(k-1), &a(1, k-1), 1, &z(1), 1);
		}
		if(ks == 2) {
			ak = a(k, k)/a(k-1, k);
			akm1 = a(k-1, k-1)/a(k-1, k);
			bk = z(k)/a(k-1, k);
			bkm1 = z(k-1)/a(k-1, k);
			denom = ak*akm1-1.0;
			z(k) = (akm1*bk-bkm1)/denom;
			z(k-1) = (ak*bkm1-bk)/denom;
		}
		else {
			if(fabs(z(k)) > fabs(a(k, k))) {
				s = fabs(a(k, k))/fabs(z(k));
				DSCAL(n, s, &z(1), 1);
				ynorm = s*ynorm;
			}
			if(a(k, k) != 0.0)
				z(k) = z(k)/a(k, k);
			if(a(k, k) == 0.0)
				z(k) = 1.0;
		}
		k = k-ks;
	}
	s = 1.0/DASUM(n, &z(1), 1);
	DSCAL(n, s, &z(1), 1);
	ynorm = s*ynorm;

	/* solve trans(u)*z = v */

	k = 1;
	while (k <= n) {
		ks = 1;
		if(kpvt(k) < 0)
			ks = 2;
		if(k != 1) {
			z(k) = z(k)+DDOT(k-1, &a(1, k), 1, &z(1), 1);
			if(ks == 2)
				z(k+1) = z(k+1)+DDOT(k-1, &a(1, k+1), 1, &z(1), 1);
			kp = abs(kpvt(k));
			if(kp != k) {
				t = z(k);
				z(k) = z(kp);
				z(kp) = t;
			}
		}
		k = k+ks;
	}

	/* make znorm = 1.0 */

	s = 1.0/DASUM(n, &z(1), 1);
	DSCAL(n, s, &z(1), 1);
	ynorm = s*ynorm;

	if(anorm != 0.0)
		*rcond = ynorm/anorm;
	else
		*rcond = 0.0;
	return;
}

int dsico_(double *a, int *lda, int *n, int *kpvt, double *rcond, double *z)
{
	DSICO(a, *lda, *n, kpvt, rcond, z);
}
