###--- >>> `predict.lqs' <<<----- Predict from an lqs Fit

	## alias	 help(predict.lqs)

##___ Examples ___:

data(stackloss)
.Random.seed <- 1:4
fm <- lqs(stack.loss ~ ., data = stackloss, method = "S", nsamp = "exact")
predict(fm, stackloss)

## Keywords: 'models'.


