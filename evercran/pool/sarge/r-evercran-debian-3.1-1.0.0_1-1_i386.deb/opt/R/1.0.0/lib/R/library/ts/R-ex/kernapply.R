###--- >>> `kernapply' <<<----- Apply Smoothing Kernel

	## alias	 help(kernapply)
	## alias	 help(kernapply.default)
	## alias	 help(kernapply.ts)
	## alias	 help(kernapply.tskernel)
	## alias	 help(kernapply.vector)

##___ Examples ___:

## see `kernel' for examples

## Keywords: 'ts'.


