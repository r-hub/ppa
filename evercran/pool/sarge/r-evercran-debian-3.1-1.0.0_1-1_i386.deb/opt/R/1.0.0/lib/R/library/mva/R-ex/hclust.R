###--- >>> `hclust' <<<----- Hierarchical Clustering

	## alias	 help(hclust)
	## alias	 help(plot.hclust)
	## alias	 help(print.hclust)

##___ Examples ___:

library(mva)
data(USArrests)
hc <- hclust(dist(USArrests), "ave")
plot(hc, hang=-1)
plot(hc)

## Keywords: 'multivariate', 'cluster'.


