###--- >>> `stl' <<<----- Seasonal Decomposition of Time Series by Loess

	## alias	 help(stl)
	## alias	 help(print.stl)
	## alias	 help(plot.stl)

##___ Examples ___:

data(nottem)
plot(stl(nottem, "per"))
data(co2)
plot(stl(log(co2), s.window=21))
## linear trend, strict period.
plot(stl(log(co2), s.window="per", t.window=1000))

## Keywords: 'ts'.


