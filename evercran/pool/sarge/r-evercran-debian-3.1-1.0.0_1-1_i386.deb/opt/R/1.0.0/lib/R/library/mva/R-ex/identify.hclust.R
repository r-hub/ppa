###--- >>> `identify.hclust' <<<----- Identify Clusters in a Dendrogram

	## alias	 help(identify.hclust)

##___ Examples ___:

##Don't run: 
##D library(mva)
##D data(USArrests)
##D hca <- hclust(dist(USArrests))
##D plot(hca)
##D x <- identify.hclust(hca)
##D x
##D 
##D data(iris)
##D hci <- hclust(dist(iris[,1:4]))
##D plot(hci)
##D identify.hclust(hci, function(k) print(table(iris[k,5])))
##D 
##D x11()
##D dev.set(2)
##D plot(hci)
##D identify.hclust(hci, function(k) barplot(table(iris[k,5])), DEV.FUN=3)


## Keywords: 'cluster', 'iplot'.


