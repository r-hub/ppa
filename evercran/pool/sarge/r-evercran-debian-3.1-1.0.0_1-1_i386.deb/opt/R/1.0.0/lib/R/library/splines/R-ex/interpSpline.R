###--- >>> `interpSpline' <<<----- Create an Interpolation Spline

	## alias	 help(interpSpline)
	## alias	 help(interpSpline.default)
	## alias	 help(interpSpline.formula)
	## alias	 help(print.bSpline)
	## alias	 help(print.ppolySpline)

##___ Examples ___:

library( splines )
data( women )
ispl <- interpSpline( women$height, women$weight )
ispl2 <- interpSpline( weight ~ height,  women )
# ispl and ispl2 should be the same
plot( predict( ispl, seq( 55, 75, len = 51 ) ), type = "l" )
points( women$height, women$weight )
plot( ispl )    # plots over the range of the knots
points( women$height, women$weight )
splineKnots( ispl )

## Keywords: 'models'.


