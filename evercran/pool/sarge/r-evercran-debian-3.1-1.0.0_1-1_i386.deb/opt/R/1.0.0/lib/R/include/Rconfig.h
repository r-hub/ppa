/* src/include/Rconfig.h.  Generated automatically */
#ifndef R_VERSION_H
#define R_VERSION_H

#ifndef _CONFIG_H

#define F77_SYMBOL(x)	x ## _

#define IEEE_754 1
/* #undef WORDS_BIGENDIAN */

#endif
#endif
