###--- >>> `biplot' <<<----- Biplot of Multivariate Data

	## alias	 help(biplot)
	## alias	 help(biplot.default)

## Keywords: 'hplot', 'multivariate'.


