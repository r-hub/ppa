###--- >>> `dist' <<<----- Distance Matrix Computation

	## alias	 help(dist)
	## alias	 help(print.dist)
	## alias	 help(as.matrix.dist)

##___ Examples ___:

x<-matrix(rnorm(100),nrow=5)
dist(x)
dist(x, diag = TRUE)
dist(x, upper = TRUE)
as.matrix(dist(x))

## Keywords: 'multivariate', 'cluster'.


