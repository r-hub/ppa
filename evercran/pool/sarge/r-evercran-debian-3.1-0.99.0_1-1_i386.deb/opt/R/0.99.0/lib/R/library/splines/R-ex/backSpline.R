###--- >>> `backSpline' <<<----- Monotone Inverse Spline

	## alias	 help(backSpline)
	## alias	 help(backSpline.nbSpline)
	## alias	 help(backSpline.npolySpline)

##___ Examples ___:

library( splines )
data( women )
ispl <- interpSpline( women$height, women$weight )
bspl <- backSpline( ispl )
plot( bspl )                   # plots over the range of the knots
points( women$weight, women$height )

## Keywords: 'models'.


