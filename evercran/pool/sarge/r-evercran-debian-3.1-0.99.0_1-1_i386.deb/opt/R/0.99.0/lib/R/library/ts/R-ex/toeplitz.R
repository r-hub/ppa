###--- >>> `toeplitz' <<<----- Form Symmetric Toeplitz Matrix

	## alias	 help(toeplitz)

##___ Examples ___:

x <- 1:5
toeplitz (x)

## Keywords: 'ts'.


