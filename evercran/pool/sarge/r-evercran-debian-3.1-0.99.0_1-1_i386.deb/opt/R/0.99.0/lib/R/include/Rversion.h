#define R_VERSION 25344
#define R_Version(v,p,s) (((v) * 65536) + ((p) * 256) + (s))
#define R_MAJOR  "0"
#define R_MINOR  "99.0"
#define R_STATUS "Patched"
#define R_YEAR   "2000"
#define R_MONTH  "February"
#define R_DAY    "9"
