###--- >>> `polySpline' <<<----- Piecewise Polynomial Spline Representation

	## alias	 help(polySpline)
	## alias	 help(polySpline.bSpline)
	## alias	 help(polySpline.nbSpline)
	## alias	 help(polySpline.pbSpline)
	## alias	 help(polySpline.polySpline)
	## alias	 help(as.polySpline)
	## alias	 help(plot.polySpline)
	## alias	 help(predict.polySpline)
	## alias	 help(print.polySpline)

##___ Examples ___:

library( splines )
data( women )
ispl <- polySpline( interpSpline( weight ~ height,  women ) )
print( ispl )   # print the piecewise polynomial representation
plot( ispl )    # plots over the range of the knots
points( women$weight, women$height )

## Keywords: 'models'.


