###--- >>> `princomp' <<<----- Principal Components Analysis

	## alias	 help(princomp)
	## alias	 help(plot.princomp)
	## alias	 help(print.princomp)
	## alias	 help(predict.princomp)
	## alias	 help(summary.princomp)
	## alias	 help(loadings)
	## alias	 help(screeplot)

##___ Examples ___:

## the variances of the variables in the
## USArrests data vary by orders of magnitude
data(USArrests)
(pc.cr <- princomp(USArrests))
princomp(USArrests, cor = TRUE)
princomp(scale(USArrests, scale = TRUE, center = TRUE), cor = FALSE)

summary(pc.cr <- princomp(USArrests))
loadings(pc.cr)
plot(pc.cr) # does a screeplot.
biplot(pc.cr)

## Keywords: 'multivariate'.


