###--- >>> `spec.ar' <<<----- Estimate Spectral Density of a Time Series from AR Fit

	## alias	 help(spec.ar)

##___ Examples ___:

data(lh)
spec.ar(lh)

data(UKLungDeaths)
spec.ar(ldeaths)
spec.ar(ldeaths, method="burg")

## Keywords: 'ts'.


