#ifndef COMPLEX_H
#define COMPLEX_H

typedef struct {
	double r;
	double i;
} complex;

#endif
