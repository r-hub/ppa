###--- >>> `cancor' <<<----- Canonical Correlations

	## alias	 help(cancor)

##___ Examples ___:

data(savings)
pop <- savings[, 2:3]
oec <- savings[,-(2:3)]
str(cancor(pop, oec))

x <- matrix(rnorm(150), 50, 3)
y <- matrix(rnorm(250), 50, 5)
str(cxy <- cancor(x, y))
all(abs(cor(x %*% cxy$xcoef,
            y %*% cxy$ycoef)[,1:3] - diag(cxy $ cor)) < 1e-15)
all(abs(cor(x %*% cxy$xcoef) - diag(3)) < 1e-15)
all(abs(cor(y %*% cxy$ycoef) - diag(5)) < 1e-15)

## Keywords: 'multivariate'.


