###--- >>> `princomp' <<<----- Principal Components Analysis

	## alias	 help(princomp)
	## alias	 help(plot.princomp)
	## alias	 help(print.princomp)
	## alias	 help(predict.princomp)
	## alias	 help(summary.princomp)

##___ Examples ___:

## the variances of the variables in the
## crimes data vary by orders of magnitude
data(crimes)
princomp(crimes)
princomp(crimes, cor = TRUE)
princomp(scale(crimes, scale = TRUE, center = TRUE), cor = FALSE)
plot(princomp(crimes))
biplot(princomp(crimes))
summary(princomp(crimes))
loadings(princomp(crimes))



