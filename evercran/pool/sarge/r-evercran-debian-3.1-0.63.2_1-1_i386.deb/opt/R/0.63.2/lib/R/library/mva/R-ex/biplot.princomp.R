###--- >>> `biplot.princomp' <<<----- Biplot for Principal Components

	## alias	 help(biplot.princomp)

## Keywords: 'multivariate', 'hplot'.


