###--- >>> `prcomp' <<<----- Principal Components Analysis

	## alias	 help(prcomp)
	## alias	 help(plot.prcomp)
	## alias	 help(print.prcomp)
	## alias	 help(summary.prcomp)
	## alias	 help(print.summary.prcomp)

##___ Examples ___:

## the variances of the variables in the
## crimes data vary by orders of magnitude
data(crimes)
prcomp(crimes)
prcomp(crimes, scale = TRUE)
plot(prcomp(crimes))
summary(prcomp(crimes))



