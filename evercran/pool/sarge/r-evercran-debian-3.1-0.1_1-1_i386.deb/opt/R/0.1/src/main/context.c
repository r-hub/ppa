/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*------------------------------------------------------------------------------

Contexts:

A linked-list of execution contexts is kept so that control-flow constructs
like "next", "break" and "return" will work.  It is also used for error
returns to top-level.

	context[k] -> context[k-1] -> ... -> context[0]
	^					^
	globalcontext				toplevelcontext

Contexts are allocated on the stack as the evaluator invokes itself
recursively.  The memory is reclaimed naturally on return through the
recursions (the globalcontext pointer needs adjustment).

A context contains the following information:

	nextcontext	the next level context
	cjmpbuf		longjump information for non-local return
	cstacktop	the current level of the pointer protection stack
	callflag	the context "type"
	cenvir		closure environments (closures only)
			the environment the closure was called from (sysparent)
	conexit		code for on.exit calls, to be executed in cenvir
			at exit from the closure (normal or abnormal).
	cend		a pointer to function which executes if there is
			non-local return (i.e. an error)

Context types can be one of:

	1	while/for - targets for break/next
	2	closures - targets for return
	3	other functions that need clean up if an error occurs

A context is created with a call to

	void begincontext(RCONTEXT *cptr, int flags, SEXP env)

which sets up the context pointed to by cptr in the appropriate way.
When the context goes "out-of-scope" a call to 

	void endcontext(RCONTEXT *cptr)

restores the previous context (i.e. it adjusts the globalcontext pointer).

The non-local jump to a given context takes place in a call to

	void findcontext(int mask, SEXP val)

This causes "val" to be stuffed into a globally accessable place and
then a search to take place back through the context list for an
appropriate context.  The kind of context sort is determined by the
value of "mask".  If "mask" is less than 10 a break/next context is
sort, otherwise a return context is sort.

The value of "mask" is returned as the value of the setjump call at the
level longjumped to.  This is used to distinguish between break and
next actions.

Contexts can be used as a wrapper around functions that create windows or
open files. These can then be shut/closed gracefully if an error occurs.

------------------------------------------------------------------------------*/

#include "Defn.h"

static void jumpfun(RCONTEXT *, int, SEXP);

/* begincontext - begin an execution context */
void begincontext(RCONTEXT * cptr, int flags, SEXP sysparent, SEXP env)
{
	cptr->nextcontext = globalcontext;
	cptr->cstacktop = stacktop;
	cptr->callflag = flags;
	cptr->cenvir = sysparent;
	cptr->cloenv = env;
	cptr->conexit = NULL;
	cptr->cend = NULL;
	globalcontext = cptr;
}

/* endcontext - end an execution context */
void endcontext(RCONTEXT * cptr)
{
	int savevis = visible;
	if (cptr->cloenv != nilValue && cptr->conexit)
		eval(cptr->conexit, cptr->cloenv);
	visible = savevis;
	globalcontext = cptr->nextcontext;
}

/* findcontext - find the correct context */
void findcontext(int mask, SEXP val)
{
	RCONTEXT *cptr;

	cptr = globalcontext;

	/* look to see if we are stopping in a loop  */
	if (mask < 10)
		if (cptr->callflag != 1)
			error("No loop to break from, jumping to top level\n");
		else
			jumpfun(cptr, mask, val);
	else			/* we are in  a closure */
		for (cptr = globalcontext; cptr; cptr = cptr->nextcontext)
			if (cptr->callflag == 2)
				jumpfun(cptr, mask, val);
	error("No function to return from, jumping to top level\n");
}

/* jumpfun - jump to the named context */
static void jumpfun(RCONTEXT * cptr, int mask, SEXP val)
{
	stacktop = cptr->cstacktop;
	returnedValue = val;
	if (cptr != toplevelcontext)
		globalcontext = cptr->nextcontext;
	else
		globalcontext = toplevelcontext;
	longjmp(cptr->cjmpbuf, mask);
}

/*
 * sysparent - look back up the context stack until the nth closure 
 * context and return that cenvir (sysparent)
 */
SEXP sysparent(int n)
{
	RCONTEXT *cptr;

	cptr = globalcontext;
	while (cptr != toplevelcontext) {
		if (cptr->callflag == 2)
			if (n == 1)
				return (cptr->cenvir);
			else
				n--;
		cptr = cptr->nextcontext;
	}
	error("sysparent: not that many enclosing functions\n");
	/*NOTREACHED*/
}

SEXP do_sysparent(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	int n;
	checkArity(op, args);
	n = asInteger(CAR(args));
	if(n == NA_INTEGER || n < 0)
		errorcall(call, "invalid number of environment levels\n");
	return sysparent(n);
}
