/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"

/*      MEMORY MANAGEMENT
 *
 *	Separate areas are maintained for fixed and variable sized
 *	objects.  The first of these is allocated as an array of
 *	SEXPRECs and the second as an array of VECRECs.  The fixed
 *	sized objects are assembled into a free list and cons cells
 *	are allocated from it.  When the list is exhausted, a
 *	mark-sweep garbarge collection takes place and the free list
 *	is rebuilt.  Variable size objects are allocated in the VECREC
 *	area.  During a garbage collection, these are compacted to the
 *	beginning of the VECREC array.
 *
 *	The top end of the VECREC array is also used by R_alloc to
 *	maintain a stack of non-relocatable memory blocks.  These are
 *	used in calls to .Fortran and .C (and for other temporary
 *	purposes).  They are freed using a stack discipline.
 *
 *	+---------------------------------------------------+
 *	| allocated vectors |	free	| R-alloc'ed blocks |
 *	+---------------------------------------------------+
 *	                    ^           ^
 *	                    |           |
 *	                    R_vtop      R_vmax
 *
 *	If a piece of code R-allocs some blocks, it is required to
 *	reset the R_vmax pointer back to its original value before it
 *	exits.  This can be done with the functions getvmax and
 *	setvmax.
 */

static VECREC *R_vmax;		/* bottom of R_alloc'ed heap */

static int gc_reporting = 0;

void installIntVector(SEXP, int, FILE *);

SEXP do_gcinfo(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	int i;
	checkArity(op, args);
	i = asLogical(CAR(args));
	if (i != NA_LOGICAL)
		gc_reporting = i;
	visible = 0;
	return nilValue;
}

SEXP do_gc(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	checkArity(op, args);
	gc();
	visible = 0;
	return nilValue;
}


/* MEMORY MANAGEMENT */

/* initMemory - initialize memory */
void InitMemory(int nnode, int vbytes)
{
	int i;

	if (!(argStack = (SEXP *) malloc(stacksize * sizeof(SEXP))))
		suicide("couldn't allocate memory for pointer stack");

	nsize = nnode;
	if (!(nheap = (SEXPREC *) malloc(nnode * sizeof(SEXPREC))))
		suicide("couldn't allocate memory for node heap");

	vsize = ((vbytes / sizeof(VECREC)) + 1);
	if (!(vheap = (VECREC *) malloc(vsize * sizeof(VECREC))))
		suicide("couldn't allocate memory for vector heap");
	R_vtop = &vheap[0];
	R_vmax = &vheap[vsize - 1];

	for (i = 0; i < nsize - 1; i++)
		CDR(&nheap[i]) = &nheap[i + 1];
	CDR(&nheap[nsize - 1]) = NULL;
	freeSEXP = &nheap[0];
}

char *vmaxget(void)
{
	return (char *) R_vmax;
}

void vmaxset(char *ovmax)
{
	if (ovmax)
		R_vmax = (VECREC *) ovmax;
	else
		R_vmax = &vheap[vsize - 1];
}

char *R_alloc(long nelem, int eltsize)
{
	unsigned int size = INT2VEC(nelem * eltsize);
	if (size != 0) {
		if (R_vmax - R_vtop < size) {
			gc();
			if (R_vmax - R_vtop < size)
				error("memory exhausted\n");
		}
		R_vmax -= size;
	}
	return (char *) R_vmax;
}

/* allocSExp - get SEXPREC from free list; call gc if necessary */
SEXP allocSExp(SEXPTYPE t)
{
	SEXP s;

	if (freeSEXP == NULL) {
		gc();
		if (freeSEXP == NULL)
			error("memory exhausted\n");
	}
	s = freeSEXP;
	freeSEXP = CDR(s);
	CAR(s) = nilValue;
	CDR(s) = nilValue;
	TAG(s) = nilValue;
	NAMED(s) = 0;
	ATTRIB(s) = nilValue;
	TYPEOF(s) = t;
	LEVELS(s) = 0;
	return s;
}


/* allocString - allocate a string on the (vector) heap */
/* all vector objects must be a multiple of sizeof(ALIGN) bytes */
/* so that alignment is preserved for all objects */

SEXP allocString(int length)
{
	SEXP s;
	long size;

	/* number of vector cells to allocate */
	size = 1 + BYTE2VEC(length + 1);

	if (freeSEXP == NULL || size + R_nvcell >= vsize) {
		gc();
		if (freeSEXP == NULL || size + R_nvcell >= vsize)
			error("memory exhausted\n");
	}

	s = freeSEXP;
	freeSEXP = CDR(s);
	TYPEOF(s) = CHARSXP;
	CHAR(s) = (char *) (R_vtop + 1);
	LENGTH(s) = length;
	TAG(s) = nilValue;
	NAMED(s) = 0;
	ATTRIB(s) = nilValue;
	BACKPOINTER(*R_vtop) = s;
	R_vtop += size;
	R_nvcell += size;
	return s;
}


/* allocVector - allocate a vector object on the heap */
SEXP allocVector(SEXPTYPE type, int length)
{
	SEXP s;
	int i;
	long size;

	/* number of vector cells to allocate */
	switch (type) {
	case NILSXP:
		return nilValue;
	case CHARSXP:
		size = 1 + BYTE2VEC(length + 1);
		break;
	case LGLSXP:
	case INTSXP:
	case FACTSXP:
	case ORDSXP:
		if (length <= 0)
			size = 0;
		else
			size = 1 + INT2VEC(length);
		break;
	case REALSXP:
		if (length <= 0)
			size = 0;
		else
			size = 1 + FLOAT2VEC(length);
		break;
	case STRSXP:
		if (length <= 0)
			size = 0;
		else
			size = 1 + PTR2VEC(length);
		break;
	case LISTSXP:
		return allocList(length);
	default:
		error("invalid type/length (%d/%d) in vector allocation\n", type, length);
	}

	if (freeSEXP == NULL || size + R_nvcell >= vsize) {
		gc();
		if (freeSEXP == NULL || size + R_nvcell >= vsize)
			error("memory exhausted\n");
	}

	s = freeSEXP;
	freeSEXP = CDR(s);
	TYPEOF(s) = type;
	LENGTH(s) = length;
	NAMED(s) = 0;
	ATTRIB(s) = nilValue;
	if (size > 0) {
		CHAR(s) = (char *) (R_vtop + 1);
		BACKPOINTER(*R_vtop) = s;
		R_vtop += size;
		R_nvcell += size;
	}
	else
		CHAR(s) = (char *) 0;

	/*
	 * The following prevents disaster in the case that
	 * an uninitialised string vector is marked
	 */

	if (type == STRSXP) {
		for (i = 0; i < length; i++)
			STRING(s)[i] = nilValue;
	}
	return s;
}

SEXP allocList(int n)
{
	int i;
	SEXP result;

	result = nilValue;
	for (i = 0; i < n; i++) {
		result = CONS(nilValue, result);
		TAG(result) = nilValue;
	}
	return result;
}




/* gc - mark-scan garbage collector */
void gc(void)
{
	int vcells, vfrac;
	if (gc_reporting)
		REprintf("Garbage collection ...");
	unmarkPhase();
	markPhase();
	compactPhase();
	scanPhase();
	if (gc_reporting) {
		REprintf("\n%ld cons cells free (%ld%%)\n",
			 R_collected, (100 * R_collected / nsize));
		vcells = vsize - (R_vtop - vheap);
		vfrac = 100 * vcells / vsize;
		REprintf("%ldk bytes of heap free (%ld%%)\n",
			 vcells * sizeof(VECREC) / 1000, vfrac);
	}
}


/* unmarkPhase - reset mark in ALL cons cells */
void unmarkPhase(void)
{
	int i;

	for (i = 0; i < nsize; i++)
		MARK(&nheap[i]) = 0;
}


/* markPhase - set mark in all accessible cons cells */
void markPhase(void)
{
	int i;

	markSExp(nilValue);	/* Builtin constants */
	markSExp(NA_STRING);
	markSExp(trueValue);
	markSExp(falseValue);
	markSExp(unboundValue);
	markSExp(missingArg);
	markSExp(commentSxp);

	markSExp(globalEnv);	/* Global environent */

	for (i = 0; i < HSIZE; i++)	/* Symbol table */
		markSExp(SYMBOL_TABLE[i]);

	if (currentExp != NULL)	/* Current expression */
		markSExp(currentExp);

	for (i = 0; i < stacktop; i++)	/* protected pointers */
		markSExp(argStack[i]);
}


/* markSExp - set mark in s and all cells accessible from it */
void markSExp(SEXP s)
{
	int i;

	if (s && !MARK(s)) {
		MARK(s) = 1;
		if (ATTRIB(s) != nilValue)
			markSExp(ATTRIB(s));
		switch (TYPEOF(s)) {
		case NILSXP:
		case BUILTINSXP:
		case SPECIALSXP:
		case CHARSXP:
		case LGLSXP:
		case FACTSXP:
		case ORDSXP:
		case INTSXP:
		case REALSXP:
			break;
		case STRSXP:
			for (i = 0; i < LENGTH(s); i++)
				markSExp(STRING(s)[i]);
			break;
		case ENVSXP:
			markSExp(FRAME(s));
			markSExp(ENCLOS(s));
			break;
		case CLOSXP:
		case PROMSXP:
		case LISTSXP:
		case LANGSXP:
		case DOTSXP:
		case SYMSXP:
		case FRAMESXP:
			markSExp(TAG(s));
			markSExp(CAR(s));
			markSExp(CDR(s));
			break;
		default:
			abort();
		}
	}
}


/* compactPhase - compact the vector heap */
void compactPhase(void)
{
	VECREC *vto, *vfrom;
	SEXP s;
	int i, size;

	vto = vfrom = vheap;

	while (vfrom < R_vtop) {
		s = BACKPOINTER(*vfrom);
		switch (TYPEOF(s)) {	/* get size in bytes */
		case CHARSXP:
			size = LENGTH(s) + 1;
			break;
		case LGLSXP:
		case FACTSXP:
		case ORDSXP:
		case INTSXP:
			size = LENGTH(s) * sizeof(int);
			break;
		case REALSXP:
			size = LENGTH(s) * sizeof(double);
			break;
		case STRSXP:
			size = LENGTH(s) * sizeof(SEXP);
			break;
		default:
			abort();
		}
		size = 1 + BYTE2VEC(size);
		if (MARK(s)) {
			if (vfrom != vto) {
				for (i = 0; i < size; i++)
					vto[i] = vfrom[i];
			}
			CHAR(BACKPOINTER(*vto)) = (char *) (vto + 1);
			vto += size;
			vfrom += size;
		}
		else {
			vfrom += size;
		}
	}
	R_vtop = vto;
	R_nvcell = (R_vtop - vheap);
}


/* scanPhase - reconstruct free list from cells not marked */
void scanPhase(void)
{
	int i;

	freeSEXP = NULL;
	R_collected = 0;
	for (i = 0; i < nsize; i++) {
		if (!MARK(&nheap[i])) {
			CDR(&nheap[i]) = freeSEXP;
			freeSEXP = &nheap[i];
			CAR(&nheap[i]) = nilValue;
			TAG(&nheap[i]) = nilValue;
			R_collected = R_collected + 1;
		}
	}
}


/* protect - push a single argument onto argStack */
void protect(SEXP s)
{
	if (stacktop >= stacksize)
		error("stack overflow\n");
	argStack[stacktop] = s;
	stacktop = stacktop + 1;
}


/* unprotect - pop argument list from top of argStack */
void unprotect(int l)
{
	if (stacktop > 0)
		stacktop = stacktop - l;
	else
		error("stack imbalance in \"unprotect\"\n");
}


/* initStack - initialize environment stack */
void initStack(void)
{
	stacktop = 0;
}
