/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"

#define CHECKOPEN {int c; while( isspace(c=fgetc(fp)) ); if (c != '(') abort();}
#define CHECKCLOSED {int c; while( isspace(c=fgetc(fp)) ); if (c != ')') abort();}

extern FILE *yyin;


static void restorevec(FILE *, SEXP);
static void writeINT(FILE *, int *, int);
static void writereal(FILE *, double *, int);
static void writechar(FILE *, char *, int);
static void readINT(FILE *, int *, int);
static void readreal(FILE *, double *, int);
static void readchar(FILE *, char *, int);
#ifdef OLD
static void saveerror(int, FILE *);
#endif

extern void installFunTab(int);
extern int R_DirtyImage;

void installIntVector(SEXP, int, FILE *);
int markSym(char *);
void mkSymTab();
void scrub();

#ifdef Macintosh

static int saved_vol;

unsigned char *__c2p(const char *, char *);

static long _ftype = 'RIMG', _fcreator = 'RGRI';

#endif

#ifndef FILENAME_MAX
#define FILENAME_MAX 255
#endif

static char savedfilename[FILENAME_MAX];


/* markSym marks symbols in FunTab that have been read in */
int markSym(char *inchar)
{
	int i;

	for (i = 0; FunTab[i].name; i++)
		if (streql(FunTab[i].name, inchar)) {
			FunTab[i].mark = 1;
			return (i);
		}
	/* if we can't find it return deprecated */
	return (0);
}

/*
 * MkSymTab checks all of the entries in the builtins of the current
 * environment and if they are not marked it installs them.
 * We also make sure all the global variable point to the correct items.
 */

void mkSymTab()
{
	int i;
	SEXP s;

	SymbolShortcuts();

	for (i = 0; FunTab[i].name; i++)
		if (!FunTab[i].mark) {
			s = install(FunTab[i].name);
			if (SYMVALUE(s) == unboundValue)
				installFunTab(i);
		}
}

static void fwriteByte(unsigned int b, FILE * fp)
{
	unsigned char i = b;
	if (fwrite(&i, sizeof(i), 1, fp) != 1)
		 error("write error occured");
}

static void fwriteShort(unsigned int s, FILE * fp)
{
	unsigned short i = s;
	if (fwrite(&i, sizeof(i), 1, fp) != 1)
		 error("write error occured");
}

static void fwrite3Bytes(unsigned int t, FILE *fp)
{
	struct { unsigned int tb : 24; } i;
	i.tb = t;
	if (fwrite(&i, 3, 1, fp) != 1)
		 error("write error occured");
}

static void fwriteInteger(unsigned int i, FILE * fp)
{
	if (fwrite(&i, sizeof(i), 1, fp) != 1)
		 error("write error occured");
}

static unsigned int freadByte(FILE * fp)
{
	unsigned char i;
	fread(&i, sizeof(i), 1, fp);
	return i;
}

static unsigned int freadShort(FILE * fp)
{
	unsigned short i;
	fread(&i, sizeof(i), 1, fp);
	return i;
}

static unsigned int fread3Bytes(FILE *fp)
{
	struct { unsigned int tb : 24; } i;
	fread(&i, 3, 1, fp);
	return i.tb;
}

static unsigned int freadInteger(FILE * fp)
{
	unsigned int i;
	fread(&i, sizeof(i), 1, fp);
	return i;
}

typedef struct {
	unsigned int flag1 : 2;
	unsigned int flag2 : 2;
	unsigned int flag3 : 2;
	unsigned int flag4 : 2;
	unsigned int index : 24;
} Info;

#ifdef OLD
static void fwriteInfo(Info *info, FILE * fp)
{
	if (fwrite(info, sizeof(Info), 1, fp) != 1)
		 error("write error occured");
}
#endif

static void freadInfo(Info *info, FILE * fp)
{
	fread(info, sizeof(Info), 1, fp);
}

static int nodecode(unsigned int k)
{
	if(k == 0) return 0;
	if(k <= 255) return 1;
	if(k <= 65535) return 2;
	if(k <= 16777215) return 3;
	return 4;
}

static void writenode(FILE *fp,
		unsigned int index,
		unsigned int offset1,
		unsigned int offset2,
		unsigned int offset3,
		unsigned int offset4)
{
	Info info;
	info.index = index;
	info.flag1 = nodecode(offset1);
	info.flag2 = nodecode(offset2);
	info.flag3 = nodecode(offset3);
	info.flag4 = nodecode(offset4);
	fwrite(&info, sizeof(info), 1, fp);
	switch(info.flag1) {
		case 1:
			fwriteByte(offset1, fp); break;
		case 2:
			fwriteShort(offset1, fp); break;
		case 3:
			fwrite3Bytes(offset1, fp); break;
		case 4:
			fwriteInteger(offset1, fp); break;
	}
	switch(info.flag2) {
		case 1:
			fwriteByte(offset2, fp); break;
		case 2:
			fwriteShort(offset2, fp); break;
		case 3:
			fwrite3Bytes(offset2, fp); break;
		case 4:
			fwriteInteger(offset2, fp); break;
	}
	switch(info.flag3) {
		case 1:
			fwriteByte(offset3, fp); break;
		case 2:
			fwriteShort(offset3, fp); break;
		case 3:
			fwrite3Bytes(offset3, fp); break;
		case 4:
			fwriteInteger(offset3, fp); break;
	}
	switch(info.flag4) {
		case 1:
			fwriteByte(offset4, fp); break;
		case 2:
			fwriteShort(offset4, fp); break;
		case 3:
			fwrite3Bytes(offset4, fp); break;
		case 4:
			fwriteInteger(offset4, fp); break;
	}
	if(TYPEOF(&nheap[index]) == FACTSXP || TYPEOF(&nheap[index]) == ORDSXP)
		fwrite(&nheap[index], sizeof(unsigned char), 3, fp);
	else
		fwrite(&nheap[index], sizeof(unsigned char), 1, fp);
}

static void readnode(FILE *fp,
		unsigned int *index,
		unsigned int *offset1,
		unsigned int *offset2,
		unsigned int *offset3,
		unsigned int *offset4)
{
	short levels;
	Info info;

	freadInfo(&info, fp);
	*index = info.index;
	switch(info.flag1) {
		case 0:
			*offset1 = 0; break;
		case 1:
			*offset1 = freadByte(fp); break;
		case 2:
			*offset1 = freadShort(fp); break;
		case 3:
			*offset1 = fread3Bytes(fp); break;
		case 4:
			*offset1 = freadInteger(fp); break;
	}
	switch(info.flag2) {
		case 0:
			*offset2 = 0; break;
		case 1:
			*offset2 = freadByte(fp); break;
		case 2:
			*offset2 = freadShort(fp); break;
		case 3:
			*offset2 = fread3Bytes(fp); break;
		case 4:
			*offset2 = freadInteger(fp); break;
	}
	switch(info.flag3) {
		case 0:
			*offset3 = 0; break;
		case 1:
			*offset3 = freadByte(fp); break;
		case 2:
			*offset3 = freadShort(fp); break;
		case 3:
			*offset3 = fread3Bytes(fp); break;
		case 4:
			*offset3 = freadInteger(fp); break;
	}
	switch(info.flag4) {
		case 0:
			*offset4 = 0; break;
		case 1:
			*offset4 = freadByte(fp); break;
		case 2:
			*offset4 = freadShort(fp); break;
		case 3:
			*offset4 = fread3Bytes(fp); break;
		case 4:
			*offset4 = freadInteger(fp); break;
	}
	scrub(&nheap[*index]);
	fread(&nheap[*index], sizeof(unsigned char), 1, fp);
	if(TYPEOF(&nheap[*index]) == FACTSXP || TYPEOF(&nheap[*index]) == ORDSXP) {
		fread(&levels, sizeof(unsigned short), 1, fp);
		LEVELS(&nheap[*index]) = levels;
	}
}

void scrub(SEXP s)
{
	CAR(s) = CDR(s) = TAG(s) = ATTRIB(s) = nilValue;
	LEVELS(s) = MARK(s) = TYPEOF(s) = OBJECT(s) = 0;
}

/* 
 * We want to know how large the image is going to be so that we can
 * decide whether there is enough room on the disk to store it.
 * It is important that gc have been called immediately prior to this.
 */
int PtrSize(unsigned int iptr)
{
	if (iptr == 0) return 0;
	if (iptr < 256) return 1;
	if (iptr < 65536) return 2;
	if (iptr < 16777216) return 3;
	return 4;
}

int CountSize()
{
	unsigned int i, len, nbytes;

	nbytes = (4 + HSIZE) * sizeof(int);

	for (i = 0; i < nsize; i++) {
		if (MARK(&nheap[i])) {
			/* header info */
			nbytes += (4 + PtrSize(ATTRIB(&nheap[i]) - nheap));
			switch (TYPEOF(&nheap[i])) {
			case NILSXP:
			case SYMSXP:
			case LISTSXP:
			case LANGSXP:
			case CLOSXP:
			case PROMSXP:
			case FRAMESXP:
				nbytes += (PtrSize(CAR(&nheap[i]) - nheap)
					+ PtrSize(CDR(&nheap[i]) - nheap)
					+ PtrSize(TAG(&nheap[i]) - nheap));
				break;
			case ENVSXP:
				nbytes += (PtrSize(FRAME(&nheap[i]) - nheap)
					+ PtrSize(ENCLOS(&nheap[i]) - nheap));
				break;
			case SPECIALSXP:
			case BUILTINSXP:
				len = strlen(PRIMNAME(&nheap[i]));
				nbytes += PtrSize(len)+len;
				break;
			case CHARSXP:
				len = LENGTH(&nheap[i]);
				nbytes += PtrSize(len)+len;
				break;
			case REALSXP:
				len = LENGTH(&nheap[i]);
				nbytes += PtrSize(len) + len*sizeof(double);
				break;
			case LGLSXP:
			case INTSXP:
			case FACTSXP:
			case ORDSXP:
				len = LENGTH(&nheap[i]);
				nbytes += PtrSize(len) + len*sizeof(int);
				break;
			case STRSXP:
				len = LENGTH(&nheap[i]);
				nbytes += PtrSize(len) + len*sizeof(int);
				break;
			}
		}
	}
	return nbytes;
}

#ifdef OLD
/* need to close and remove the image if writing it was unsuccessful */
static void saveerror(int errnum, FILE * fp)
{
	fclose(fp);
	remove(savedfilename);
	error("an error occurred while trying to save the image\n");
}
#endif

/*dump a binary image of the environment */

void dump_image(FILE *fp, int check, long Vsize, char *fname)
{
	int i, j, len;

	strcpy(savedfilename, fname);
	stacktop = 0;
	currentExp = NULL;
	gc();

	/*
	if( check ) {
		i = CountSize();
		if (i > Vsize)
			saveerror(5, fp);
	}
	*/

	/* first write out some global variables and the symbol table */
	/* 1959 is a magic number discovered by Gentleman */
	/* 1954 is a magic number discovered by Ihaka */
	/* 1946 is the next number in the sequence */
	/* fwriteInteger(1959, fp); */
	fwriteInteger(1954, fp);

	/* Memory sizes, etc */
	fwriteInteger(nsize - R_collected - 1, fp);
	fwriteInteger(R_vtop - vheap, fp);
	fwriteInteger(globalEnv - nheap, fp);

	/* Symbol hash table state */
	for (i = 0; i < HSIZE; i++)
		fwriteInteger(SYMBOL_TABLE[i] - nheap, fp);

	/* All marked SEXPRECS on the heap */
	for (i = 0; i < nsize; i++) {
		if (MARK(&nheap[i])) {
			switch (TYPEOF(&nheap[i])) {
			case NILSXP:
			case SYMSXP:
			case LISTSXP:
			case LANGSXP:
			case CLOSXP:
			case PROMSXP:
			case FRAMESXP:
				writenode(fp, i,
					ATTRIB(&nheap[i]) - nheap,
					CAR(&nheap[i]) - nheap,
					CDR(&nheap[i]) - nheap,
					TAG(&nheap[i]) - nheap);
				break;
			case ENVSXP:
				writenode(fp, i,
					ATTRIB(&nheap[i]) - nheap,
					FRAME(&nheap[i]) - nheap,
					ENCLOS(&nheap[i]) - nheap,
					0);
				break;
			case SPECIALSXP:
			case BUILTINSXP:
				len = strlen(PRIMNAME(&nheap[i]));
				writenode(fp, i,
					ATTRIB(&nheap[i]) - nheap,
					len, 0, 0);
				writechar(fp, PRIMNAME(&nheap[i]), len);
				break;
			case CHARSXP:
				len = LENGTH(&nheap[i]);
				writenode(fp, i,
					ATTRIB(&nheap[i]) - nheap,
					len, 0, 0);
				writechar(fp, CHAR(&nheap[i]), len);
				break;
			case REALSXP:
				len = LENGTH(&nheap[i]);
				writenode(fp, i,
					ATTRIB(&nheap[i]) - nheap,
					len, 0, 0);
				writereal(fp, REAL(&nheap[i]), len);
				break;
			case INTSXP:
			case FACTSXP:
			case ORDSXP:
			case LGLSXP:
				len = LENGTH(&nheap[i]);
				writenode(fp, i,
					ATTRIB(&nheap[i]) - nheap,
					len, 0, 0);
				writeINT(fp, INTEGER(&nheap[i]), len);
				break;
			case STRSXP:
				len = LENGTH(&nheap[i]);
				writenode(fp, i,
					ATTRIB(&nheap[i]) - nheap,
					len, 0, 0);
				for (j = 0; j < len; j++)
					fwriteInteger(STRING(&nheap[i])[j] - nheap, fp);
				break;
			default:
				UNIMPLEMENTED("dump_image");
			}
		}
	}
	fclose(fp);
	R_DirtyImage = 0;
}

SEXP do_restoreb(SEXP call, SEXP op, SEXP args, SEXP env)
{
	/* open the file for reading the image */
	switch (length(args)) {
	case 1:
		op = CAR(args);
		if (TYPEOF(op) != STRSXP)
			error("invalid argument to \"restore\"\n");
		break;
	default:
		error("incorrect number of arguments to \"restore\"\n");
	}
	restore_image(CHAR(STRING(op)[0]));
	visible = 0;
	return nilValue;
}

int restore_image(char *filename)
{
	unsigned int index, offset1, offset2, offset3, offset4;
	int i, nread;
	char tmpchar[512];
	FILE *fp;

	fp = fopen(filename, "rb");
	if (!fp)
		error("restore: unable to open file\n");

	/* Initialise */
	unmarkPhase();
	for (i = 0; FunTab[i].name; i++)
		FunTab[i].mark = 0;

	/* Magic number check */
	if ((i = freadInteger(fp)) == 1959) {
		fclose(fp);
		error("binary restore (old image, new binary)\n");
	}

	if (i != 1954) {
		fclose(fp);
		error("binary restore (file is not an R binary dump)\n");
	}

	/* Memory sizes */
	nread = freadInteger(fp);
	if (nread > nsize) {
		fclose(fp);
		error("restore: not enough CONS-cell space\n");
	}
	if (freadInteger(fp) > vsize) {
		fclose(fp);
		error("restore: not enough heap space\n");
	}
	globalEnv = &nheap[freadInteger(fp)];
	R_vtop = vheap;

	/* Symbol table hashing */
	for (i = 0; i < HSIZE; i++)
		SYMBOL_TABLE[i] = nheap + freadInteger(fp);

	/* Read in the records into the heap */
	for (i = 0; i <= nread; i++) {
		readnode(fp, &index, &offset1,
			 &offset2, &offset3, &offset4);
		if (TYPEOF(&nheap[index]) < 0 || TYPEOF(&nheap[index]) > DOTSXP)
			UNIMPLEMENTED("restore_image");
		ATTRIB(&nheap[index]) = &nheap[offset1];
		MARK(&nheap[index]) = 1;
		switch (TYPEOF(&nheap[index])) {
		case NILSXP:
		case SYMSXP:
		case LISTSXP:
		case LANGSXP:
		case CLOSXP:
		case PROMSXP:
		case FRAMESXP:
			CAR(&nheap[index]) = &nheap[offset2];
			CDR(&nheap[index]) = &nheap[offset3];
			TAG(&nheap[index]) = &nheap[offset4];
			break;
		case ENVSXP:
			FRAME(&nheap[index]) = &nheap[offset2];
			ENCLOS(&nheap[index]) = &nheap[offset3];
			break;
		case SPECIALSXP:
		case BUILTINSXP:
			readchar(fp, tmpchar, offset2);
			nheap[index].u.primsxp.offset = markSym(tmpchar);
			break;
		case CHARSXP:
		case REALSXP:
		case INTSXP:
		case FACTSXP:
		case ORDSXP:
		case LGLSXP:
		case STRSXP:
			LENGTH(&nheap[index]) = offset2;
			restorevec(fp, &nheap[index]);
			break;
		default:
			UNIMPLEMENTED("restore_image");
		}
	}
	fclose(fp);

	stacktop = 0;
	currentExp = NULL;

	/* Rebuild the free list */
	scanPhase();
	mkSymTab();
	R_DirtyImage = 0;
	CacheOptions();
	jump_to_toplevel();
	/*NOTREACHED*/
}

void restorevec(FILE * fp, SEXP csexp)
{
	int size, length, i, j;

	length = LENGTH(csexp);

	/* number of vector cells to allocate */
	switch (TYPEOF(csexp)) {
	case CHARSXP:
		size = 1 + BYTE2VEC(length + 1);
		break;
	case LGLSXP:
	case INTSXP:
	case FACTSXP:
	case ORDSXP:
		if (length <= 0)
			size = 0;
		else
			size = 1 + INT2VEC(length);
		break;
	case REALSXP:
		if (length <= 0)
			size = 0;
		else
			size = 1 + FLOAT2VEC(length);
		break;
	case STRSXP:
		if (length <= 0)
			size = 0;
		else
			size = 1 + PTR2VEC(length);
		break;
	}
	if (size > 0) {
		BACKPOINTER(*R_vtop) = csexp;
		CHAR(BACKPOINTER(*R_vtop)) = (char *) (R_vtop + 1);
		R_vtop += size;
		R_nvcell += size;
		switch (TYPEOF(csexp)) {
		case CHARSXP:
			readchar(fp, CHAR(csexp), length);
			break;
		case INTSXP:
		case LGLSXP:
		case FACTSXP:
		case ORDSXP:
			readINT(fp, INTEGER(csexp), length);
			break;
		case REALSXP:
			readreal(fp, REAL(csexp), length);
			break;
		case STRSXP:
			for (i = 0; i < length; i++) {
				j = freadInteger(fp);
				STRING(csexp)[i] = &nheap[j];
			}
			break;
		}
	}
	else
		CHAR(csexp) = (char *) 0;
}



/* Primitives for reading and writing SEXPs in binary */

static void readINT(FILE * fp, int * intvec, int len)
{
	if (len > 0)
		fread(intvec, sizeof(int), len, fp);
}

static void readreal(FILE * fp, double * fvec, int len)
{
	if (len > 0)
		fread(fvec, sizeof(double), len, fp);
}

static void readchar(FILE * fp, char *cvec, int len)
{
	if (len > 0) {
		fread(cvec, sizeof(char), len, fp);
	}
	cvec[len] = '\0';
}

static void writeINT(FILE * fp, int * intvec, int len)
{
	if (len > 0)
		fwrite(intvec, sizeof(int), len, fp);
}


static void writereal(FILE * fp, double * fvec, int len)
{
	if (len > 0)
		fwrite(fvec, sizeof(double), len, fp);
}

static void writechar(FILE * fp, char *cvec, int len)
{
	if (len > 0)
		fwrite(cvec, sizeof(char), len, fp);
}
