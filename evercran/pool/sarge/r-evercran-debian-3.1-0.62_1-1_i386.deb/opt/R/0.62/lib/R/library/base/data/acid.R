acid <- data.frame(
 carb  = c(0.1, 0.3, 0.5, 0.6, 0.7, 0.9),
optden = c(0.086, 0.269, 0.446, 0.538, 0.626, 0.782), row.names = paste(1:6))
