/* src/include/Platform.h.  Generated automatically by configure.  */
#ifndef PLATFORM_H_
#define PLATFORM_H_

#define Unix

/* (Long) Integers */

#define LONG_32_BITS 1

/* Floating Point Arithmetic */
#define HAVE_MATHERR 1		/* System V */
#define HAVE_ISNAN 1		/* IEEE Arith indicator */
#define HAVE_FINITE 1

/* #undef HAVE_IEEEFP_H */		/* "-Wall" */
#define HAVE_IEEE754_H 1		/* Linux */

#ifdef HAVE_ISNAN
#ifdef HAVE_FINITE
#define IEEE_754
#endif
#endif

/* Signal Handler Type */
#define RETSIGTYPE void

/* Dynamic Linking */
/* #undef HAVE_DL_H */		/* hpux */
#define HAVE_DLFCN_H 1		/* Everything else */

/* ELF Binary Format */
#define HAVE_ELF_H 1

/* Process Timing */
#define HAVE_TIMES 1
/* #undef HAVE_TIMES_H */
#define HAVE_SYS_TIMES_H 1

/* XDR Library Available */
#define HAVE_RPC_XDR_H 1

/* HDF5 Library Available */
/* #undef HAVE_HDF5_H */

/* General String Comparison */
#define HAVE_STRCOLL 1

/* Inverse Hyperbolics */
#define HAVE_ASINH 1
#define HAVE_ACOSH 1
#define HAVE_ATANH 1

/* Unix commands through a subshell */
#define HAVE_SYSTEM 1

/* IEEE Rounding */
#define HAVE_RINT 1

/* HPUX rint is broken */
/* #undef USE_BUILTIN_RINT */

/* POSIX Regular Expressions Available */
#define HAVE_REGCOMP 1

/* Compatibility for "memmove" on older BSD platforms */
#define HAVE_MEMMOVE 1
#define HAVE_MEMCPY 1
#define HAVE_BCOPY 1

/* Compatibility for setjmp / longjmp */
#define HAVE_SIGLONGJMP 1

#ifdef HAVE_SIGLONGJMP
#define JMP_BUF sigjmp_buf
#define SETJMP(x) sigsetjmp(x,1)
#define LONGJMP(x,i) siglongjmp(x,i)
#else
#define JMP_BUF jmp_buf
#define SETJMP(x) setjmp(x)
#define LONGJMP(x,i) longjmp(x,i)
#endif


/* Some Linux systems may need this */
/* #undef HAVE___SETFPUCW */

/* Fortran and C Links */
#define HAVE_F77_UNDERSCORE 1

#ifdef HAVE_F77_UNDERSCORE
#define F77_SYMBOL(x)	x ## _
#define F77_QSYMBOL(x)	#x ## "_"
#else
#define F77_SYMBOL(x)	x
#define F77_QSYMBOL(x)	#x
#endif

/* GNU Readline Library */
#define HAVE_LIBREADLINE 1
#define HAVE_READLINE_HISTORY_H 1

#define HAVE_LOCALE_H 1
#define HAVE_UNISTD_H 1

/* Bug Workarounds */
/* #undef HAVE_OSF_SPRINTF_BUG */

/* Some platforms other than ELF drop the leading _ */
/* #undef HAVE_NO_SYMBOL_UNDERSCORE */
#ifndef HAVE_NO_SYMBOL_UNDERSCORE
#ifdef HAVE_ELF_H
#define HAVE_NO_SYMBOL_UNDERSCORE
#endif
#endif

/* SunOS 4 is famous for broken header files */
/* #undef SunOS4 */
#ifdef SunOS4
# ifndef NULL
#  define	NULL		0
# endif
# ifndef RAND_MAX
#  define	RAND_MAX	32767
# endif
#endif /* SunOS4 */

/* Printing Command */
#define R_PRINTCMD	""

/* for platform.c to put in .Platform */
#ifdef Unix
#define OSTYPE      "Unix"
#define FILESEP     "/"
#define SHLIBEXT    "so"
#define DYNLOADEXT  "." ## SHLIBEXT
#endif

#ifdef Macintosh
#define OSTYPE      "Macintosh"
#define FILESEP     ":"
#define DYNLOADEXT  ".dll"
#endif

#ifdef Win32
#define OSTYPE      "Windows"
#define FILESEP     "\\"
#define DYNLOADEXT  ".dll"
#endif

#define R_PLATFORM	"i686-unknown-linux"
#define R_CPU		"i686"
#define R_VENDOR	"unknown"
#define R_OS		"linux"
#define R_MAJOR		"0"
#define R_MINOR		"64.0"
#define R_STATUS	""
#define R_STATUS_REV	"0"
#define R_DAY		"8"
#define R_MONTH		"April"
#define R_YEAR		"1999"

#endif
