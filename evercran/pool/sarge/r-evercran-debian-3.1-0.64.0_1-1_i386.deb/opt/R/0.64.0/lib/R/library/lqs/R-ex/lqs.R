###--- >>> `lqs' <<<----- Resistant Regression

	## alias	 help(lqs)
	## alias	 help(lqs.formula)
	## alias	 help(lqs.default)
	## alias	 help(lmsreg)
	## alias	 help(ltsreg)
	## alias	 help(print.lqs)
	## alias	 help(residuals.lqs)

##___ Examples ___:

data(stackloss)
.Random.seed <- 1:4
lqs(stack.loss ~ ., data=stackloss)
lqs(stack.loss ~ ., data=stackloss, method="S", nsamp="exact")

## Keywords: 'model', 'robust'.


