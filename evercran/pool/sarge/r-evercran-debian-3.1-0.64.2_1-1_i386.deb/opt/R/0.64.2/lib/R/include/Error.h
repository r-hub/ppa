void	error(const char *, ...);
void	warning(const char *, ...);
void	WrongArgCount(char *);
void	UNIMPLEMENTED(char *);

