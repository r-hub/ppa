###--- >>> `hclust' <<<----- Hierarchical Clustering

	## alias	 help(hclust)
	## alias	 help(plot.hclust)

##___ Examples ___:

library(mva)
data(crimes)
hc <- hclust(dist(crimes), "ave")
plot(hc, hang=-1)
plot(hc)

## Keywords: 'multivariate', 'cluster'.


