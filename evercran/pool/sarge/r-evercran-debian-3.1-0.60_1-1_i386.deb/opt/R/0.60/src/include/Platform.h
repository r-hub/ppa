/* src/include/Platform.h.  Generated automatically by configure.  */
#ifndef PLATFORM_H_
#define PLATFORM_H_

#define Unix

/* Floating Point Arithmetic */
#define HAVE_MATHERR 1		/* System V */
#define HAVE_ISNAN 1		/* IEEE Arith indicator */
#define HAVE_FINITE 1

/* Signal Handler Type */
#define RETSIGTYPE void

/* Dynamic Linking */
/* #undef HAVE_DL_H */		/* hpux */
#define HAVE_DLFCN_H 1		/* Everything else */

/* ELF Binary Format */
#define HAVE_ELF_H 1

/* Process Timing */
#define HAVE_TIMES 1
/* #undef HAVE_TIMES_H */
#define HAVE_SYS_TIMES_H 1

/* XDR Library Available */
#define HAVE_RPC_XDR_H 1

/* General String Comparison */
#define HAVE_STRCOLL 1

/* Inverse Hypobolics */
#define HAVE_ASINH 1
#define HAVE_ACOSH 1
#define HAVE_ATANH 1

/* IEEE Rounding */
#define HAVE_RINT 1

/* HPUX rint is broken */
/* #undef USE_BUILTIN_RINT */

/* POSIX Regular Expressions Available */
#define HAVE_REGCOMP 1

/* Compatibility for "memmove" on older BSD platforms */
#define HAVE_MEMMOVE 1
#define HAVE_MEMCPY 1
#define HAVE_BCOPY 1

/* Fortran and C Links */
#define HAVE_F77_UNDERSCORE 1

#ifdef HAVE_F77_UNDERSCORE
#define F77_SYMBOL(x)	x ## _
#define F77_QSYMBOL(x)	#x ## "_"
#else
#define F77_SYMBOL(x)	x
#define F77_QSYMBOL(x)	#x
#endif

/* GNU Readline Library */
#define HAVE_LIBREADLINE 1

/* Bug Workarounds */
/* #undef HAVE_OSF_SPRINTF_BUG */

/* Some platforms other than ELF drop the leading _ */
/* #undef HAVE_NO_SYMBOL_UNDERSCORE */
#ifndef HAVE_NO_SYMBOL_UNDERSCORE
#ifdef HAVE_ELF_H
#define HAVE_NO_SYMBOL_UNDERSCORE
#endif
#endif

#define R_PLATFORM	"i686-unknown-linux"
#define R_CPU		"i686"
#define R_VENDOR	"unknown"
#define R_OS		"linux"
#define R_MAJOR		"0"
#define R_MINOR		"60"
#define R_STATUS	"Alpha"
#define R_STATUS_REV	"0"
#define R_DAY		"2"
#define R_MONTH		"December"
#define R_YEAR		"1997"

#endif
