/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <X11/X.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <X11/cursorfont.h>
#include <math.h>
#include <signal.h>
#include <stdio.h>
#include <signal.h>
#include "Graphics.h"
#include "xvertext.h"

	/* Start of Tunable Defaults */

#define CURSOR		XC_crosshair	/* Default cursor */
#define WINDOW_X_ORIGIN	0		/* Default window origin x coord */
#define WINDOW_Y_ORIGIN	0		/* Default window origin y coord */
#define WINDOW_WIDTH	650		/* Default window width */
#define WINDOW_HEIGHT	650		/* Default window height */

#ifdef FIXED
static char *fontname = "fixed";
#else
static char *fontname = "-adobe-helvetica-medium-r-normal--%d-*-*-*-*-*-*";
#endif

	/* End of Tunable Defaults */

/* R Device Driver code */

	/* Graphics Parameters for last driver call. */

static double cex = 1.0;
static double srt = 0.0;
static int col = 1;
static int lty = 1;

static int inColor = 0;
static int windowWidth = WINDOW_WIDTH;
static int windowHeight = WINDOW_HEIGHT;
static int newWindowWidth;
static int newWindowHeight;
static int resize = 0;

static Display *display;			/* Display */
static int screen;				/* Screen */
static int depth;				/* Pixmap depth */
static Window rootWindow;			/* Root Window */
static Window window;				/* Graphics Window */
static Cursor gcursor;				/* Graphics Cursor */

static GC wgc;					/* GC for window */

static XSetWindowAttributes attributes;		/* Window attributes */
static XEvent event;				/* Event */

static Colormap cmap;				/* Default color map */
static XColor fgcolor;				/* Foreground color */
static XColor bgcolor;				/* Background color */
static int blackpixel;				/* Black */
static int whitepixel;				/* White */

static void ProcessEvents(void);
static void X11_NewPlot(void);

static char* colors[] = {
	"white",
	"black",
	"red",
	"forestgreen",
	"blue",
	"cyan",
	"magenta",
	"yellow",
	0
};

static void SetColor(color)
{
	int result;
	XColor exact;

	col = color;
	color = abs(color%8);
	result = XAllocNamedColor(display, cmap, colors[color], &exact, &fgcolor);
	if (result == 0) error("color allocation error");
	blackpixel = fgcolor.pixel;
	XSetState(display, wgc, blackpixel, whitepixel, GXcopy, AllPlanes);
}


	/* ---- Utility Functions ---- */

#define MM_PER_INCH 25.4

static double pixelWidth(void)
{
	double width, widthMM;
	width = DisplayWidth(display, screen);
	widthMM = DisplayWidthMM(display, screen);
	return (widthMM / width) / MM_PER_INCH;
}

static double pixelHeight(void)
{
	double height, heightMM;
	height = DisplayHeight(display, screen);
	heightMM = DisplayHeightMM(display, screen);
	return (heightMM / height) / MM_PER_INCH;
}

	/* Font information array. */
	/* Fonts at point sizes 8, 10, 12, 14, 18, 24. */
	/* Rotated to multiples of 90 degrees */
	/* This uses the xvertext code */

XRotFontStruct *fontarray[6][4] = {
	{NULL, NULL, NULL, NULL},
	{NULL, NULL, NULL, NULL},
	{NULL, NULL, NULL, NULL},
	{NULL, NULL, NULL, NULL},
	{NULL, NULL, NULL, NULL},
	{NULL, NULL, NULL, NULL},
};

	/* The current font */

XRotFontStruct *font;

	/* Determine the closest font size to that required. */
	/* If the font of this size and at that the specified */
	/* rotation is not present it is loaded. */

static void SetFont(double newcex, double newsrt)
{
	char buf[128];
	int pointsize, size, rot;

	pointsize = (((int)(newcex*12.0))/2)*2;
	if (pointsize < 8)
		pointsize = 8;
	else if(pointsize > 24)
		pointsize = 24;
	switch(pointsize) {
	    case 8:
		size = 0;
		break;
	    case 10:
		size = 1;
		break;
	    case 12:
		size = 2;
		break;
	    case 14:
	    case 16:
		size = 3;
		break;
	    case 18:
	    case 20:
	    case 22:
		size = 4;
		break;
	    case 24:	
		size = 5;
		break;
	}
	rot = (((int)newsrt) / 90) % 4;

	if(fontarray[size][rot] == NULL) {
		sprintf(buf, fontname, pointsize);
		fontarray[size][rot] = XRotLoadFont(display, buf, 90.0*rot);
		if (!fontarray[size][rot])
			error("unable to load (rotated) font in x11 graphics driver\n");
	}
	font = fontarray[size][rot];
	cex = newcex;
	srt = newsrt;
}

static unsigned char short_dash_list[] = {4, 4};
static unsigned char dotted_list[]     = {1, 3};
static unsigned char dot_dash_list[]   = {4, 3, 1, 3};
static unsigned char long_dash_list[]  = {7, 4};

static void SetLineType(int newlty)
{
	switch (newlty) {
	case 1:		/* solid */
		lty = newlty;
		XSetLineAttributes(display, wgc, 1, LineSolid, CapRound, JoinRound);
		break;
	case 2:		/* short dash */
		lty = newlty;
		XSetDashes(display, wgc, 0, short_dash_list, 2);
		XSetLineAttributes(display, wgc, 1, LineOnOffDash, CapRound, JoinRound);
		break;
	case 3:		/* dotted */
		lty = newlty;
		XSetDashes(display, wgc, 0, dotted_list, 2);
		XSetLineAttributes(display, wgc, 1, LineOnOffDash, CapRound, JoinRound);
		break;
	case 4:		/* dot-dash */
		lty = newlty;
		XSetDashes(display, wgc, 0, dot_dash_list, 4);
		XSetLineAttributes(display, wgc, 1, LineOnOffDash, CapRound, JoinRound);
		break;
	case 5:		/* long-dash */
		lty = newlty;
		XSetDashes(display, wgc, 0, long_dash_list, 4);
		XSetLineAttributes(display, wgc, 1, LineOnOffDash, CapRound, JoinRound);
		break;
	default:
		break;
	}
}


static int X11_Open(void)
{
	int result;
	XColor exact;
	XGCValues gcv;

	/* open the default display */
	/* return value of 0 indicates failure */

	if ((display = XOpenDisplay(NULL)) == NULL)
		return 0;

	/* Default Screen and Root Window */

	screen = XDefaultScreen(display);
	rootWindow = XDefaultRootWindow(display);
	depth = XDefaultDepth(display, screen);

	/* Get black and white pixel values */

	cmap = DefaultColormap(display, screen);

	/* gray80 */
	/* lightslategray */
	/* white */
	result = XAllocNamedColor(display, cmap, "gray80", &exact, &bgcolor);
	if (result == 0) error("color allocation error");

	result = XAllocNamedColor(display, cmap, "black", &exact, &fgcolor);
	if (result == 0) error("color allocation error");

	/* blackpixel = BlackPixel(display, screen); */
	/* whitepixel = WhitePixel(display,screen); */
	whitepixel = bgcolor.pixel;
	blackpixel = fgcolor.pixel;

	/* Try to create a simple window */
	/* Want to know about exposures */
	/* and window-resizes and locations */

	attributes.background_pixel = whitepixel;
	attributes.border_pixel = blackpixel;
	attributes.backing_store = Always;
	attributes.event_mask = ButtonPressMask
	    | ExposureMask
	    | StructureNotifyMask;

	if ((window = XCreateWindow(
		display,
		rootWindow,
		DisplayWidth(display, screen) - WINDOW_X_ORIGIN - WINDOW_WIDTH - 10,
		WINDOW_Y_ORIGIN + 10,
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		1,
		DefaultDepth(display, screen),
		InputOutput,
		DefaultVisual(display, screen),
		CWEventMask | CWBackPixel | CWBorderPixel | CWBackingStore,
		&attributes)) == 0)
		return 0;

	XChangeProperty( display, window, XA_WM_NAME, XA_STRING,
		8, PropModeReplace, "R Graphics", 13);

	gcursor = XCreateFontCursor(display, CURSOR);
	XDefineCursor(display, window, gcursor);

		/* map the window */

	XSelectInput(display, window,
		   ExposureMask | ButtonPressMask | StructureNotifyMask);
	XMapWindow(display, window);
	XSync(display, 0);

		/* gobble expose events */

	XNextEvent(display, &event);
	if (event.xany.type == Expose) {
		while (event.xexpose.count)
			XNextEvent(display, &event);
	}

		/* set the graphics context */

	wgc = XCreateGC(display, window, 0, NULL);
	XSetState(display, wgc, blackpixel, whitepixel, GXcopy, AllPlanes);
	SetFont(1.0, 0.0);
	SetLineType(1);
	return 1;
}

static XRectangle clip;

static void X11_Clip(int x0, int x1, int y0, int y1)
{
	if (x0 < x1) {
		clip.x = x0;
		clip.width = x1 - x0;
	}
	else {
		clip.x = x1;
		clip.width = x0 - x1;
	}
	if (y0 < y1) {
		clip.y = y0;
		clip.height = y1 - y0;
	}
	else {
		clip.y = y1;
		clip.height = y0 - y1;
	}
	XSetClipRectangles(display, wgc, 0, 0, &clip, 1, Unsorted);
}

static void X11_Resize()
{
	ProcessEvents();
	if (resize) {
		DP->left = 0.0;
		DP->right = windowWidth;
		DP->bottom = windowHeight;
		DP->top = 0.0;
		resize = 0;
	}
}

static void X11_NewPlot()
{
	XClearWindow(display, window);
	XSync(display, 0);
}

static void X11_Close(void)
{
	int i, j;

	/* Free Resources Here */
	for(i=0 ; i<6 ; i++)
		for(j=0 ; j<4 ; j++)
			if(fontarray[i][j] != NULL) {
				XRotUnloadFont(display, fontarray[i][j]);
				fontarray[i][j] = NULL;
			}
	XCloseDisplay(display);
	XVertEnd();
}


static int xlast;
static int ylast;

static void X11_MoveTo(int x, int y)
{
	if(GP->col != col) SetColor(GP->col);
	xlast = x;
	ylast = y;
}

static void X11_Dot(void)
{
	XFillRectangle(display, window, wgc, xlast, ylast, 2, 2);
}

static void X11_LineTo(int x, int y)
{
	if (GP->lty != lty)
		SetLineType(GP->lty);
	XDrawLine(display, window, wgc, xlast, ylast, x, y);
	xlast = x;
	ylast = y;
	XSync(display, 0);
}

static void X11_Rect(int x0, int y0, int x1, int y1, int fill)
{
	int tmp;
	if (x0 > x1) {
		tmp = x0;
		x0 = x1;
		x1 = tmp;
	}
	if (y0 > y1) {
		tmp = y0;
		y0 = y1;
		y1 = tmp;
	}
	if (GP->col != col) SetColor(GP->col);
	if (GP->lty != lty) SetLineType(GP->lty);
	if (fill)
		XFillRectangle(display, window, wgc, x0, y0, x1 - x0, y1 - y0);
	else
		XDrawRectangle(display, window, wgc, x0, y0, x1 - x0, y1 - y0);
	XSync(display, 0);
}


static void X11_Polygon(int n, int *x, int *y)
{
	XPoint *points;
	char *vmax, *vmaxget();
	int i;
	
	if((points=(XPoint*)R_alloc(n, sizeof(XPoint))) == NULL)
		error("out of memory while drawing polygon\n");
	if (GP->col != col) SetColor(GP->col);
	if (GP->lty != lty) SetLineType(GP->lty);
	for(i=0 ; i<n ; i++) {
		points[i].x = x[i];
		points[i].y = y[i];
	}
	XFillPolygon(display, window, wgc, points, n, Complex, CoordModeOrigin);
	XSync(display, 0);
	vmaxset(vmax);
}


static double deg2rad = 0.01745329251994329576;

static void X11_RText(char *str, double xc, double yc, int rot)
{
	XCharStruct inf;
	int dret, asc, desc;
	double xoff, yoff, xl, yl;
	int i, len, x, y;
	double angle;

	if (GP->col != col)
		SetColor(GP->col);
	/* should reference srt in next two lines */
	if (GP->cex != cex || rot != srt)
		SetFont(GP->cex, rot);
	len = strlen(str);
#ifdef OLD
	XTextExtents(font->xfontstruct, str, len, &dret, &asc, &desc, &inf);
	xl = (inf.rbearing - inf.lbearing);
	yl = (asc + desc);
#else
	xl = XRotTextWidth(font, str, strlen(str));
	yl = font->max_ascent+font->max_descent;
#endif
	xoff = -xc * xl * cos(deg2rad * rot) - yc * yl * sin(deg2rad * rot);
	yoff =  xc * xl * sin(deg2rad * rot) + yc * yl * cos(deg2rad * rot);
	x = xlast + xoff;
	y = ylast + yoff;
	angle = rot;
	XRotDrawString(display, font, window, wgc, x, y, str, strlen(str));
	XSync(display, 0);
}

static void X11_Text(char *str, double xc, double yc)
{
	X11_RText(str, xc, yc, 0);
#ifdef JUNK
	XCharStruct inf;
	int dret, asc, desc;
	int len, xloc, yloc;

	if (GP->col != col) SetColor(GP->col);
	if (GP->cex != cex) SetFontMag(GP->cex);
	len = strlen(str);
	XTextExtents(font, str, len, &dret, &asc, &desc, &inf);
	xloc = xlast-inf.lbearing+1-xc*(inf.rbearing-inf.lbearing+1);
	yloc = ylast + yc * (inf.ascent /*+inf.descent */);
	XDrawString(display, window, wgc, xloc, yloc, str, len);
	XSync(display, 0);
#endif
}

static int X11_Locator(int *x, int *y)
{
	ProcessEvents();	/* discard pending events */
	XSync(display, 1);
	XNextEvent(display, &event);
	if (event.xbutton.button == Button1 /* || event.xbutton.button==Button2 */ ) {
		*x = event.xbutton.x;
		*y = event.xbutton.y;
		fprintf(stderr, "\07");
		fflush(stderr);
		XSync(display, 0);
		return 1;
	}
	else {
		XSync(display, 0);
		return 0;
	}
}

static void ProcessEvents(void)
{
	while (XPending(display)) {
		XNextEvent(display, &event);
		if (event.xany.type == Expose) {
			while (event.xexpose.count) {
				XNextEvent(display, &event);
			}
		}
		else if (event.type == ConfigureNotify) {
			windowWidth = event.xconfigure.width;
			windowHeight = event.xconfigure.height;
			resize = 1;
		}
	}
}

/* Set Graphics mode - not needed for X11 */
static void X11_Mode(int mode)
{
}


/* Hold the Picture Onscreen - not needed for X11 */
/* GraphicsInteraction() for the Mac */
static void X11_Hold()
{
}


X11DeviceDriver(char *p, double *q)
{
	DevInit = 0;
	windowWidth = WINDOW_WIDTH;
	windowHeight = WINDOW_HEIGHT;

	if (!X11_Open())
		return 0;
	ProcessEvents();

	DevOpen = X11_Open;
	DevClose = X11_Close;
	DevResize = X11_Resize;
	DevNewPlot = X11_NewPlot;
	DevClip = X11_Clip;
	DevMoveTo = X11_MoveTo;
	DevLineTo = X11_LineTo;
	DevText = X11_Text;
	DevRText = X11_RText;
	DevDot = X11_Dot;
	DevRect = X11_Rect;
	DevPolygon = X11_Polygon;
	DevLocator = X11_Locator;
	DevMode = X11_Mode;
	DevHold = X11_Hold;

	/* Screen Dimensions in Pixels */

	GP->left = 0;			/* left */
	GP->right = windowWidth;	/* right */
	GP->bottom = windowHeight;	/* bottom */
	GP->top = 0;			/* top */

	/* Nominal Character Sizes in Pixels */

	/*
	   GP->cra[0] = font_str->max_bounds.rbearing - font_str->min_bounds.lbearing;
	   GP->cra[1] = font_str->max_bounds.ascent + font_str->max_bounds.descent;
	 */
	GP->cra[0] = 7.0;
	GP->cra[1] = 12.0;

	/* Character Addressing Offsets */
	/* These are used to plot a single plotting character */
	/* so that it is exactly over the plotting point */

	GP->xCharOffset = 0.3333;
	GP->yCharOffset = 0.3333;

	/* Inches per Raster Unit */

	GP->ipr[0] = 0.01;	/* pixelWidth(); */
	GP->ipr[1] = 0.01;	/* pixelHeight(); */

	GP->canResizePlot = 1;
	GP->canChangeFont = 0;
	GP->canRotateText = 1;
	GP->canResizeText = 1;
	GP->canClip = 1;

	DevInit = 1;
	cex = 1.0;
	lty = 1;
	xlast = 250;
	ylast = 250;
	return 1;
}
