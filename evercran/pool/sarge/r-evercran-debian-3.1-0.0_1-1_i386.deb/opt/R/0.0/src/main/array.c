/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"

static CheckDims(SEXP dims)
{
	int i;

	for (i = 0; i < LENGTH(dims); i++) {
		if (INTEGER(dims)[i] <= 0)
			error("invalid array extent\n");
	}
}

SEXP do_allocMatrix(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP vals, snr, snc;
	RINT na, nr, nc, byrow;

	if ((na = length(args)) != 3 && na != 4)
		error("incorrect arg count to \"matrix\"\n");
	vals = CAR(args);
	snr = CADR(args);
	snc = CADDR(args);
	if (na == 4)
		byrow = asInteger(CADR(CDDR(args)));
	else
		byrow = 0;

	if (!isVector(vals) || LENGTH(vals) <= 0)
		error("invalid first arg in matrix alloc\n");
	if (!isNumeric(snr) || !isNumeric(snc))
		error("non-numeric matrix extent\n");
	nr = asInteger(snr);
	nc = asInteger(snc);
	PROTECT(snr = allocMatrix(TYPEOF(vals), nr, nc));
	LEVELS(snr) = LEVELS(vals);
	copyMatrix(snr, vals, byrow);
	UNPROTECT(1);
	return snr;
}

SEXP allocMatrix(SEXPTYPE mode, RINT nrow, RINT ncol)
{
	SEXP s, t;
	RINT n, i;

	if (nrow < 0 || ncol < 0)
		error("allocMatrix - negative extents to matrix\n");
	n = nrow * ncol;
	PROTECT(s = allocVector(mode, n));
	PROTECT(t = allocVector(INTSXP, 2));
	INTEGER(t)[0] = nrow;
	INTEGER(t)[1] = ncol;
	setAttrib(s, DimSymbol, t);
	UNPROTECT(2);
	return s;
}

SEXP do_allocArray(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP vals, dims, ans;

	if (length(args) != 2)
		error("incorrect arg count to \"array\"\n");
	vals = CAR(args);
	dims = CADR(args);

	if (isVector(vals) && isNumeric(dims) && LENGTH(dims) >= 2) {
		PROTECT(dims = coerceVector(dims, INTSXP));
		CheckDims(dims);
		PROTECT(ans = allocArray(TYPEOF(vals), dims));
		LEVELS(ans) = LEVELS(vals);
		copyVector(ans, vals);
		UNPROTECT(2);
		return ans;
	}
	else
		error("bad arguments to array\n");
}

/* strip away redundant dimensioning information */
/* and dimnames/names if there are any */

SEXP DropDims(SEXP dims, SEXP names)
{
	SEXP ddims, tmp, rval;
	int i, k;

	/* How many "real" extents are there */
	k = 0;
	for (i = 0; i < LENGTH(dims); i++)
		k += (INTEGER(dims)[i] > 1);
	if (k == 0)
		return nilValue;
	PROTECT(dims);
	PROTECT(names);

	if (names != nilValue) {
		if (k == LENGTH(dims)) {
			rval = list2(names, dims);	/* nothing to do */
			TAG(rval) = DimNamesSymbol;	/* just tag list */
			TAG(CDR(rval)) = DimSymbol;	/* and return */
			UNPROTECT(2);
			return rval;
		}
		PROTECT(ddims = allocVector(INTSXP, k));
		PROTECT(rval = tmp = allocList(k));
		k = 0;
		for (i = 0; i < LENGTH(dims); i++) {
			if (INTEGER(dims)[i] > 1) {
				INTEGER(ddims)[k++] = INTEGER(dims)[i];
				CAR(tmp) = duplicate(CAR(names));
				TAG(tmp) = TAG(names);
				tmp = CDR(tmp);
			}
			names = CDR(names);
		}
		tmp = rval;
		if (length(ddims) == 1) {	/* we have a vector */
			if (tmp != nilValue && CAR(tmp) != nilValue) {
				rval = tmp;
				TAG(rval) = NamesSymbol;
			}
			else
				rval = nilValue;
		}
		else {		/* we have an array */
			rval = list2(tmp, ddims);
			TAG(rval) = DimNamesSymbol;
			TAG(CDR(rval)) = DimSymbol;
		}
		UNPROTECT(2);
	}
	else {
		if (k == LENGTH(dims)) {
			rval = list1(dims);
			TAG(rval) = DimSymbol;
			UNPROTECT(2);
			return rval;
		}
		ddims = allocVector(INTSXP, k);
		k = 0;
		for (i = 0; i < LENGTH(dims); i++)
			if ((INTEGER(dims)[i] > 1))
				INTEGER(ddims)[k++] = INTEGER(dims)[i];
		if (length(ddims) == 1) {
			UNPROTECT(2);
			return nilValue;
		}
		else {
			rval = list1(ddims);
			TAG(rval) = DimSymbol;
		}
	}
	UNPROTECT(2);
	return rval;
}

SEXP allocArray(SEXPTYPE mode, SEXP dims)
{
	SEXP array;
	int i, n;

	n = 1;
	for (i = 0; i < LENGTH(dims); i++)
		n = n * INTEGER(dims)[i];

	PROTECT(dims = duplicate(dims));
	PROTECT(array = allocVector(mode, n));
	setAttrib(array, DimSymbol, dims);
	UNPROTECT(2);
	return array;
}

SEXP do_nrc(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP dims, ans;

	if (length(args) != 1)
		error("incorrect number of args to nrow/ncol\n");

	ans = allocVector(INTSXP, 1);

	if (PRIMVAL(op) == 0) {
		if (isVector(CAR(args)) || isList(CAR(args)))
			INTEGER(ans)[0] = length(CAR(args));
		return ans;
	}
	else if (isMatrix(CAR(args)) || isFrame(CAR(args))) {
		PROTECT(ans);
		dims = getAttrib(CAR(args), DimSymbol);
		switch (PRIMVAL(op)) {
		case 1:
			INTEGER(ans)[0] = INTEGER(dims)[0];
			break;
		case 2:
			INTEGER(ans)[0] = INTEGER(dims)[1];
			break;
		default:
			abort();
		}
		UNPROTECT(1);
		return ans;
	}
	return nilValue;
}

SEXP do_nlevels(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP ans;

	checkArity(op, args);
	ans = allocVector(INTSXP, 1);
	if (isFactor(CAR(args)))
		INTEGER(ans)[0] = LEVELS(CAR(args));
	else
		INTEGER(ans)[0] = NA_INTEGER;
	return ans;
}


SEXP do_rowscols(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP dims, ans;
	RINT i, j, nr, nc;

	if (length(args) != 1)
		error("incorrect number of args to row/col\n");
	if (!isMatrix(CAR(args)))
		error("a matrix is required as arg to row/col\n");

	nr = nrows(CAR(args));
	nc = ncols(CAR(args));

	ans = allocMatrix(INTSXP, nr, nc);

	switch (PRIMVAL(op)) {
	case 1:
		for (i = 0; i < nr; i++)
			for (j = 0; j < nc; j++)
				INTEGER(ans)[i + j * nr] = i + 1;
		break;
	case 2:
		for (i = 0; i < nr; i++)
			for (j = 0; j < nc; j++)
				INTEGER(ans)[i + j * nr] = j + 1;
		break;
	}
	return ans;
}

static void matprod(double *x, RINT nrx, RINT ncx, double *y, RINT nry, RINT ncy, double *z)
{
	RINT i, j, k;
	double xij, yjk, sum;

	for (i = 0; i < nrx; i++)
		for (k = 0; k < ncy; k++) {
			z[i + k * nrx] = NA_REAL;
			sum = 0.0;
			for (j = 0; j < ncx; j++) {
				xij = x[i + j * nrx];
				yjk = y[j + k * nry];
				if (xij == NA_REAL || yjk == NA_REAL)
					goto next_ik;
				sum += xij * yjk;
			}
			z[i + k * nrx] = sum;
		      next_ik:;
		}
}

SEXP do_matprod(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	RINT ldx, ldy, nrx, ncx, nry, ncy;
	SEXP x, y, xdims, ydims, dimnames, ans;

	if (!isNumeric(CAR(args)) || !isNumeric(CADR(args)))
		error("%*% requires numeric matrix/vector arguments\n");

	x = CAR(args);
	y = CADR(args);

	xdims = getAttrib(CAR(args), DimSymbol);
	ydims = getAttrib(CADR(args), DimSymbol);

	ldx = LENGTH(xdims);
	ldy = LENGTH(ydims);

	if (ldx != 2 && ldy != 2) {
		nrx = 1;
		ncx = LENGTH(x);
		nry = LENGTH(y);
		ncy = 1;
	}
	else if (ldx != 2) {
		nry = INTEGER(ydims)[0];
		ncy = INTEGER(ydims)[1];
		if (LENGTH(x) == nry) {
			nrx = 1;
			ncx = LENGTH(x);
		}
		else {
			nrx = LENGTH(x);
			ncx = 1;
		}
	}
	else if (ldy != 2) {
		nrx = INTEGER(xdims)[0];
		ncx = INTEGER(xdims)[1];
		if (LENGTH(y) == ncx) {
			nry = LENGTH(y);
			ncy = 1;
		}
		else {
			nry = 1;
			ncy = LENGTH(y);
		}
	}
	else {
		nrx = INTEGER(xdims)[0];
		ncx = INTEGER(xdims)[1];
		nry = INTEGER(ydims)[0];
		ncy = INTEGER(ydims)[1];
	}

	if (ncx != nry)
		error("%*% requires conformable matrix/vector arguments\n");

	CAR(args) = coerceVector(CAR(args), REALSXP);
	CADR(args) = coerceVector(CADR(args), REALSXP);
	PROTECT(ans = allocMatrix(REALSXP, nrx, ncy));

	matprod(REAL(CAR(args)), nrx, ncx, REAL(CADR(args)), nry, ncy, REAL(ans));

	PROTECT(xdims = getAttrib(CAR(args), DimNamesSymbol));
	PROTECT(ydims = getAttrib(CADR(args), DimNamesSymbol));
	if (xdims != nilValue || ydims != nilValue) {
		setAttrib(ans, DimNamesSymbol, list2(CAR(xdims), CADR(ydims)));
	}
	UNPROTECT(3);
	return ans;
}

SEXP do_transpose(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP a, r, dims, dn;
	RINT i, j, len, ncol, nrow;

	checkArity(op, args);
	a = CAR(args);
	ncol = ncols(a);
	nrow = nrows(a);
	len = length(a);

	PROTECT(r = allocVector(TYPEOF(a), len));

	switch (TYPEOF(a)) {
	case LGLSXP:
	case FACTSXP:
	case ORDSXP:
	case INTSXP:
		for (i = 0; i < len; i++)
			INTEGER(r)[i] = INTEGER(a)[(i / ncol) + (i % ncol) * nrow];
		break;
	case REALSXP:
		for (i = 0; i < len; i++)
			REAL(r)[i] = REAL(a)[(i / ncol) + (i % ncol) * nrow];
		break;
	case STRSXP:
		for (i = 0; i < len; i++)
			STRING(r)[i] = STRING(a)[(i / ncol) + (i % ncol) * nrow];
		break;
	}
	dims = allocVector(INTSXP, 2);
	INTEGER(dims)[0] = ncol;
	INTEGER(dims)[1] = nrow;
	setAttrib(r, DimSymbol, dims);

	dn = getAttrib(a, DimNamesSymbol);
	if (dn != nilValue) {
		dn = duplicate(dn);
		dims = CAR(dn);
		CAR(dn) = CADR(dn);
		CADR(dn) = dims;
		setAttrib(r, DimNamesSymbol, dn);
	}

	UNPROTECT(1);
	return r;
}

/* swap works by finding for a index i, the position in the array with dimensions dims1 in terms
   of (i,j,k,l,m...); i.e. component-wise position, then permute these to the order of the array
   with dimensions dims2 and work backwards to an integer offset in this array
 */


static RINT swap(RINT ival, SEXP dims1, SEXP dims2, SEXP perm)
{
	RINT ind1[MAXDIM], ind2[MAXDIM], len, t1, i;

	len = length(dims1);
	if (len > MAXDIM)
		error("aperm: array dimension larger than %d\n", MAXDIM);

	t1 = ival;

	for (i = 0; i < len; i++) {
		ind1[i] = t1 % INTEGER(dims1)[i];
		t1 = t1 / INTEGER(dims1)[i];
	}

	for (i = 0; i < len; i++)
		ind2[i] = ind1[(INTEGER(perm)[i] - 1)];

	t1 = ind2[(len - 1)];
	for (i = (len - 2); i >= 0; i--) {
		t1 *= INTEGER(dims2)[i];
		t1 += ind2[i];
	}
	return t1;
}

SEXP do_aperm(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP a, perm, resize, r, dimsa, dimsr;
	RINT i, j, len, ncol, nrow;

	checkArity(op, args);

	a = CAR(args);
	PROTECT(dimsa = getAttrib(a, DimSymbol));
	if (dimsa == nilValue)
		error("aperm: wrong argument 1, must be an array\n");

	PROTECT(perm = coerceVector(CADR(args), INTSXP));
	if (!isVector(perm) || (length(perm) != length(dimsa)))
		error("aperm: wrong argument 2, must be a vector\n");

	len = length(a);

	PROTECT(dimsr = allocVector(INTSXP, length(dimsa)));
	for (i = 0; i < length(dimsa); i++)
		INTEGER(dimsr)[i] = INTEGER(dimsa)[(INTEGER(perm)[i] - 1)];

	PROTECT(r = allocVector(TYPEOF(a), len));

	switch (TYPEOF(a)) {
	case INTSXP:
	case FACTSXP:
	case ORDSXP:
	case LGLSXP:
		for (i = 0; i < len; i++) {
			j = swap(i, dimsa, dimsr, perm);
			INTEGER(r)[j] = INTEGER(a)[i];
		}
		break;
	case REALSXP:
		for (i = 0; i < len; i++) {
			j = swap(i, dimsa, dimsr, perm);
			REAL(r)[j] = REAL(a)[i];
		}
		break;
	case STRSXP:
		for (i = 0; i < len; i++) {
			j = swap(i, dimsa, dimsr, perm);
			STRING(r)[j] = STRING(a)[i];
		}
		break;
	default:
		abort();
	}

	if (INTEGER(CAR(CDDR(args)))[0])
		setAttrib(r, DimSymbol, dimsr);
	else
		setAttrib(r, DimSymbol, dimsa);
	UNPROTECT(4);
	return r;
}
