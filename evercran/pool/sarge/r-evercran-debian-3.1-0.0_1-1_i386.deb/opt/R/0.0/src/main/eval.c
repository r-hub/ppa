/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#define ARGUSED(x) LEVELS(x)

#include "Defn.h"

SEXP listAppend(SEXP, SEXP);
static SEXP applyForop(SEXP args, SEXP rho);
extern SEXP getVar(SEXP, SEXP);
extern SEXP append(SEXP, SEXP);

/* The universe will end if the Stack on the Mac grows until it hits */
/* the heap.  This code places a limit on the depth to which eval can */
/* recurse. */
/* NEEDED: A fixup is needed in browser, because it can trap errors, */
/* and currently does not reset the limit to the right value */

#ifdef Macintosh
extern void isintrpt();
#define EVAL_LIMIT 100
#endif

/* not ifdef'ed to keep main etc happy */
extern int evaldepth;
extern int evalcnt;


/* eval - return value of e evaluated in rho */
SEXP eval(SEXP e, SEXP rho)
{

	SEXP op, tmp, val;
	BUILTINOP primname;

	/*
	 * The use of depthsave below is necessary because of the possibility
	 * of non-local returns from evaluation.  Without this an "expression
	 * too complex error" is quite likely.
	 */

#ifdef EVAL_LIMIT
	int depthsave = evaldepth++;
	if (evaldepth > EVAL_LIMIT)
		error("expression too complex for evaluator\n");
#endif
#ifdef Macintosh
	if ((evalcnt++ % 100) == 0) {
		isintrpt();
	}
#endif

	visible = 1;
	switch (TYPEOF(e)) {
	case NILSXP:
	case LISTSXP:
	case LGLSXP:
	case FACTSXP:
	case ORDSXP:
	case INTSXP:
	case REALSXP:
	case STRSXP:
	case SPECIALSXP:
	case BUILTINSXP:
	case ENVSXP:
	case CLOSXP:
		tmp = e;
		break;
	case SYMSXP:
		visible = 1;
		if (e == DotsSymbol)
			error("... used in an incorrect context\n");
		tmp = findVar(e, rho);
		if (tmp == unboundValue)
			error("Object \"%s\" not found\n", CHAR(PRINTNAME(e)));
		else if (tmp == missingArg)
			error("Argument \"%s\" is missing, with no default\n", CHAR(PRINTNAME(e)));
		else if (TYPEOF(tmp) == PROMSXP) {
			PROTECT(tmp);
			tmp = eval(tmp, rho);
			if (NAMED(tmp) == 1)
				NAMED(tmp) = 2;
			UNPROTECT(1);
		}
		else if (!isNull(tmp))
			NAMED(tmp) = 1;
		break;
	case PROMSXP:
		if (PRVALUE(e) == unboundValue) {
			val = eval(PREXPR(e), PRENV(e));
			PRVALUE(e) = val;
		}
		tmp = PRVALUE(e);
		break;
	case LANGSXP:
		if (TYPEOF(CAR(e)) == SYMSXP)
			PROTECT(op = findFun(CAR(e), rho));
		else
			PROTECT(op = eval(CAR(e), rho));
		if (TYPEOF(op) == SPECIALSXP) {
			int save = stacktop;
			PROTECT(CDR(e));
			tmp = PRIMFUN(op) (e, op, CDR(e), rho);
			UNPROTECT(1);
			if(save != stacktop) {
				printf("stack imbalance in %s, %d then %d\n",
					PRIMNAME(op), save, stacktop);
			}
		}
		else if (TYPEOF(op) == BUILTINSXP) {
			int save = stacktop;
			PROTECT(tmp = evalList(CDR(e), rho));
			tmp = PRIMFUN(op) (e, op, tmp, rho);
			UNPROTECT(1);
			if(save != stacktop) {
				printf("stack imbalance in %s, %d then %d\n",
					PRIMNAME(op), save, stacktop);
			}
		}
		else if (TYPEOF(op) == CLOSXP) {
			PROTECT(tmp = promiseArgs(CDR(e), rho));
			tmp = applyClosure(CAR(e), op, tmp, rho);
			UNPROTECT(1);
		}
		else
			error("attempt to apply non-function\n");
		UNPROTECT(1);
		break;
	case DOTSXP:
		error("... used in an incorrect context\n");
	default:
		abort();
	}
#ifdef EVAL_LIMIT
	evaldepth = depthsave;
#endif
	return (tmp);
}

SEXP extractUnused(SEXP a);

/* applyClosure - apply SEXP op of type CLOSXP to actuals */
SEXP applyClosure(SEXP funName, SEXP op, SEXP arglist, SEXP sysparent)
{
	RINT i, nargs, seendots;
	SEXP fun, body, formals, actuals, tmp, s;
	SEXP savedrho, newrho;
	SEXP f, a, b;
	SEXP dots;
	RCONTEXT cntxt;

	/* formals = list of formal arguments */
	/* actuals = values to be bound to formals */
	/* arglist = the tagged list of values passed in */

	formals = FORMALS(op);
	body = BODY(op);
	savedrho = CLOENV(op);
	nargs = length(arglist);

	/* Create the list of values */

	actuals = nilValue;
	for (i = 0; i < length(formals); i++) {
		actuals = CONS(missingArg, actuals);
		MISSING(actuals) = 1;
	}
	PROTECT(actuals);

	/* Mark all arguments unused */

	for (b = arglist; b != nilValue; b = CDR(b))
		ARGUSED(b) = 0;

	/* First pass: matches based on tags */
	/* Also locates first ... */

	dots = nilValue;
	f = formals;
	a = actuals;
	while (f != nilValue) {
		if (CAR(f) == DotsSymbol && dots == nilValue) {
			/* Record where ... value goes */
			dots = a;
		}
		else {
			for (b = arglist; b != nilValue; b = CDR(b)) {
				if (!ARGUSED(b) && TAG(b) != nilValue && pmatch(CAR(f), TAG(b))) {
					if (CAR(a) != missingArg)
						error("formal argument \"%s\" matched by multiple actual arguments\n", CHAR(PRINTNAME(CAR(f))));
					CAR(a) = CAR(b);
					MISSING(a) = 0;		/* not missing this arg */
					ARGUSED(b) = 1;
				}
			}
		}
		f = CDR(f);
		a = CDR(a);
	}

	/* Second pass: matches based on order */
	/* All args specified in tag=value form have now been matched. */
	/* If we find ... we gobble up all the remaining args. */
	/* Otherwise we bind untagged values in order */
	/* to any unmatched formals. */

	f = formals;
	a = actuals;
	b = arglist;
	seendots = 0;

	while (f != nilValue && b != nilValue && !seendots) {
		if (CAR(f) == DotsSymbol) {
			/* Skip ... matching until all tags done */
			seendots = 1;
			f = CDR(f);
			a = CDR(a);
		}
		else if (CAR(a) != missingArg) {
			/* Already matched by tag */
			/* skip to next formal */
			f = CDR(f);
			a = CDR(a);
		}
		else if (ARGUSED(b) || TAG(b) != nilValue) {
			/* This value used or tagged , skip to next value */
			/* The second test above is needed because we */
			/* shouldn't consider tagged values for positional */
			/* matches. */
			/* The formal being considered remains the same */
			b = CDR(b);
		}
		else {
			/* We have a positional match */
			CAR(a) = CAR(b);
			MISSING(a) = 0;
			ARGUSED(b) = 1;
			b = CDR(b);
			f = CDR(f);
			a = CDR(a);
		}
	}

	if (dots != nilValue) {
		/* Gobble up all unused actuals */
		CAR(dots) = extractUnused(arglist);
		MISSING(dots) = 0;
		if (TYPEOF(CAR(dots)) == LISTSXP)
			TYPEOF(CAR(dots)) = DOTSXP;
	}
	else {
		/* Check that all arguments are used */
		for (b = arglist; b != nilValue; b = CDR(b))
			if (!ARGUSED(b) && PREXPR(CAR(b)) != missingArg)
				errorcall(funName, "unused argument to function\n");
	}

	UNPROTECT(1);
	PROTECT(newrho = extendEnv(savedrho, formals, actuals));
	NARGS(newrho) = nargs;

	/* Use default code for unbound formals */
	f = formals;
	a = actuals;
	while (f != nilValue) {
		if (CAR(a) == missingArg && TAG(f) != missingArg) {
			CAR(a) = mkPROMISE(TAG(f), newrho);
		}
		f = CDR(f);
		a = CDR(a);
	}

	/* Default value */
	tmp = nilValue;
	begincontext(&cntxt, 2, sysparent, newrho);
	if (setjmp(cntxt.cjmpbuf)) {
		tmp = returnedValue;
	}
	else {
		tmp = eval(body, newrho);
	}
	endcontext(&cntxt);
	UNPROTECT(1);

	return (tmp);
}

/* Build a list of promises to evaluate unmatched arguments */
SEXP extractUnused(SEXP a)
{
	if (a == nilValue)
		return nilValue;
	if (ARGUSED(a))
		return extractUnused(CDR(a));
	SETCDR(a, extractUnused(CDR(a)));
	return a;
}


static SEXP evalseq(SEXP expr, SEXP rho)
{
	SEXP val, nval, nexpr;

	if (isNull(expr))
		error("invalid left side of assignment\n");

	if (isSymbol(expr)) {
		PROTECT(expr);
		nval = eval(expr, rho);
		UNPROTECT(1);
		return CONS(eval(expr, rho), expr);
	}
	else if (isLanguage(expr)) {
		PROTECT(expr);
		PROTECT(val = evalseq(CADR(expr), rho));
		PROTECT(nexpr = LCONS(CAR(val), CDDR(expr)));
		PROTECT(nexpr = LCONS(CAR(expr), nexpr));
		nval = eval(nexpr, rho);
		UNPROTECT(4);
		return CONS(nval, val);
	}
	else
		error("attempt to assign to non-symbol\n");
}

SEXP getVarInFrame(SEXP, SEXP);

/* NOTE: list and end must be protected before top level entry */
SEXP langAppend(SEXP lst, SEXP end)
{
	if (lst == nilValue)
		lst = LCONS(end, nilValue);
	else
		lst = CONS(CAR(lst), langAppend(CDR(lst), end));
	return lst;
}

static SEXP replaceCall(SEXP fun, SEXP val, SEXP args, SEXP rhs)
{
	PROTECT(fun);
	PROTECT(val);
	PROTECT(args);
	PROTECT(rhs);
	val = LCONS(fun, LCONS(val, langAppend(args, rhs)));
	UNPROTECT(4);
	return val;
}

static SEXP assignCall(SEXP op, SEXP symbol, SEXP fun, SEXP val, SEXP args, SEXP rhs)
{
	PROTECT(op);
	PROTECT(symbol);
	val = replaceCall(fun, val, args, rhs);
	UNPROTECT(2);
	return lang3(op, symbol, val);
}

/* assignments for complex lval specifications */
/* we have checked to see that args is a LANGSXP */

SEXP applydefine(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP expr, fun, lhs, rhs;
	char buf[32];

	expr = CAR(args);
	PROTECT(lhs = evalseq(CADR(expr), rho));
	PROTECT(rhs = eval(CADR(args), rho));
	while (isLanguage(CADR(expr))) {
		sprintf(buf, "%s<-", CHAR(PRINTNAME(CAR(expr))));
		UNPROTECT(1);
		PROTECT(rhs = replaceCall(install(buf), CAR(lhs), CDDR(expr), rhs));
		rhs = eval(rhs, rho);
		lhs = CDR(lhs);
		expr = CADR(expr);
	}
	sprintf(buf, "%s<-", CHAR(PRINTNAME(CAR(expr))));
	PROTECT(expr = assignCall(install("<-"), CDR(lhs),
				 install(buf), CAR(lhs), CDDR(expr), rhs));
	expr = eval(expr, rho);
	UNPROTECT(3);
	return expr;
}

/* do_special - apply special form op to args */
SEXP do_special(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	RINT tmp;
	SEXP s, t;
	RCONTEXT cntxt;

	switch (PRIMVAL(op)) {
	case IFOP:
		tmp = asLogical(eval(CAR(args), rho));
		if (tmp == NA_LOGICAL)
			errorcall(call, "missing value where logical needed\n");
		else if (tmp)
			return (eval(CAR(CDR(args)), rho));
		else if (length(args) > 2)
			return (eval(CAR(CDR(CDR(args))), rho));
		else
			return (nilValue);
	case WHILEOP:
		s = eval(CAR(args), rho);
		t = nilValue;
		for (;;) {
			if ((tmp = asLogical(s)) == NA_LOGICAL)
				errorcall(call, "missing value where logical needed\n");
			else if (!tmp)
				break;
			begincontext(&cntxt, 1, nilValue, nilValue);
			if (tmp = setjmp(cntxt.cjmpbuf))
				if (tmp == 1)	/* break */
					break;
				else
					continue;	/* next  */
			else {
				PROTECT(t = eval(CAR(CDR(args)), rho));
				s = eval(CAR(args), rho);
				UNPROTECT(1);
				endcontext(&cntxt);
			}
		}
		visible = 0;
		return (t);
	case REPEATOP:
		for (;;) {
			begincontext(&cntxt, 1, nilValue, nilValue);
			if (tmp = setjmp(cntxt.cjmpbuf))
				if (tmp == 1)
					break;	/*break */
				else
					continue;	/* next */
			else {
				t = eval(CAR(args), rho);
				endcontext(&cntxt);
			}
		}
		visible = 0;
		return t;
	case FOROP:
		s = applyForop(args, rho);
		visible = 0;
		return s;
	case DEFINEOP:
		if (length(args) != 2)
			WrongArgCount("<-");
		if (isString(CAR(args)))
			CAR(args) = install(CHAR(STRING(CAR(args))[0]));
		if (isSymbol(CAR(args))) {
			s = eval(CADR(args), rho);
			if (NAMED(s))
				s = duplicate(s);
			PROTECT(s);
			visible = 0;
			defineVar(CAR(args), s, rho);
			UNPROTECT(1);
			return (s);
		}
		else if (isLanguage(CAR(args))) {
			visible = 0;
			return applydefine(call, op, args, rho);
		}
		else
			error("attempt to assign to non-symbol\n");
	case SETOP:
		if (length(args) != 2)
			WrongArgCount("<<-");
		if (isString(CAR(args)))
			CAR(args) = install(CHAR(STRING(CAR(args))[0]));
		if (isSymbol(CAR(args))) {
			s = eval(CADR(args), rho);
			if (NAMED(s))
				s = duplicate(s);
			PROTECT(s);
			visible = 0;
			setVar(CAR(args), s, rho);
			UNPROTECT(1);
			NAMED(s) = 1;
			return s;
		}
		else if (isList(CAR(args)))
			return applydefine(call, op, args, rho);
		else
			error("attempt to assign to non-symbol\n");
	case GSETOP:
		if (length(args) != 2)
			WrongArgCount(":=");
		if (isString(CAR(args)))
			CAR(args) = install(CHAR(STRING(CAR(args))[0]));
		if (isSymbol(CAR(args))) {
#ifdef DEBUG_LEX
			printf("%s\n", CHAR(PRINTNAME(CAR(args))));
#endif
			s = eval(CADR(args), rho);
			if (NAMED(s))
				s = duplicate(s);
			PROTECT(s);
			visible = 0;
			gsetVar(CAR(args), s, rho);
			UNPROTECT(1);
			NAMED(s) = 1;
			return s;
		}
		else
			error("attempt to assign to non-symbol\n");
	case QUOTEOP:
		return (CAR(args));
	case QUITOP:
		CleanUp();
		exit(0);
	case LAMBDAOP:
		if (length(args) < 2)
			WrongArgCount("lambda");
		CheckFormals(CAR(args));
		return mkCLOSXP(CAR(args), CADR(args), rho);
	case BEGINOP:
		if (args == nilValue) {
			s = nilValue;
		}
		else {
			while (CDR(args) != nilValue) {
				eval(CAR(args), rho);
				args = CDR(args);
			}
			s = eval(CAR(args), rho);
		}
		return s;
	case BREAKOP:
		findcontext(1, nilValue);
	case NEXTOP:
		findcontext(2, nilValue);
	case STOPOP:
		CAR(args) = coerceVector(CAR(args), STRSXP);
		if (length(CAR(args)) <= 0)
			error("\n");
		else
			error("%s\n", CHAR(STRING(CAR(args))[0]));
	case WARNINGOP:
		if (CAR(args) != nilValue) {
			CAR(args) = coerceVector(CAR(args), STRSXP);
			warning("%s\n", CHAR(STRING(CAR(args))[0]));
		}
		else
			warning("%s\n", "");
		visible = 0;
		return CAR(args);
	case RETURNOP:
		s = eval(CAR(args), rho);
		/* visible = 1; */
		findcontext(13, s);
	default:
		abort();
	}
}


static SEXP applyForop(SEXP args, SEXP rho)
{
	RINT i, n, tmp;
	SEXP ans, sym, v, val, body;
	RCONTEXT cntxt;

	sym = CAR(args);
	val = CADR(args);
	body = CADDR(args);

	PROTECT(args);
	PROTECT(rho);
	PROTECT(val = eval(val, rho));
	defineVar(sym, nilValue, rho);
	if (isList(val)) {
		n = length(val);
		PROTECT(v = nilValue);
	}
	else {
		n = LENGTH(val);
		PROTECT(v = allocVector(TYPEOF(val), 1));
	}
	ans = nilValue;
	for (i = 0; i < n; i++) {
		begincontext(&cntxt, 1, nilValue, nilValue);
		if (tmp = setjmp(cntxt.cjmpbuf))
			if (tmp == 1)
				break;	/* break */
			else
				continue;	/* next  */
		else {
			if (isVector(v)) {
				UNPROTECT(1);
				PROTECT(v = allocVector(TYPEOF(val), 1));
			}
			switch (TYPEOF(val)) {
			case LGLSXP:
				LOGICAL(v)[0] = LOGICAL(val)[i];
				setVar(sym, v, rho);
				ans = eval(body, rho);
				break;
			case INTSXP:
				INTEGER(v)[0] = INTEGER(val)[i];
				setVar(sym, v, rho);
				ans = eval(body, rho);
				break;
			case REALSXP:
				REAL(v)[0] = REAL(val)[i];
				setVar(sym, v, rho);
				ans = eval(body, rho);
				break;
			case STRSXP:
				STRING(v)[0] = STRING(val)[i];
				setVar(sym, v, rho);
				ans = eval(body, rho);
				break;
			case LISTSXP:
				setVar(sym, CAR(val), rho);
				ans = eval(body, rho);
				val = CDR(val);
			}
			endcontext(&cntxt);
		}
	}
	UNPROTECT(4);
	visible = 0;
	return ans;
}


SEXP do_builtin(SEXP call, SEXP op, SEXP vl, SEXP rho)
{
	SEXP s1, s2;
	SEXP result = nilValue;

	if (PRIMARITY(op) != length(vl))
		error("Wrong number of arguments to primitive\n");

	/* get the actual arg(s) */
	s1 = CAR(vl);
	if (PRIMARITY(op) == 2)
		s2 = CADR(vl);

	switch (PRIMVAL(op)) {
	case PARENOP:
		result = s1;
		break;
	case LPRINTOP:
		Rprintf("sorry: lisp printing is now defunct\n");
		visible = 0;
		result = NULL;
		break;
	case GCOP:
		gc();
		visible = 0;
		break;
	case SEQOP:
		result = seq(s1, s2);
		break;
	case REPOP:
		result = rep(s1, s2);
		break;
	}
	return (result);
}


/* evalList - evaluate each expression in el */
SEXP evalList(SEXP el, SEXP rho)
{
	SEXP h, t;

	if (el == nilValue)
		return nilValue;

	if (CAR(el) == DotsSymbol) {
		h = findVar(CAR(el), rho);
		if (h == nilValue)
			return evalList(CDR(el), rho);
		if (TYPEOF(h) != DOTSXP) {
			if (h == missingArg)
				return evalList(CDR(el), rho);
			error("... used in an incorrect context\n");
		}
		PROTECT(h = evalList(h, rho));
		PROTECT(t = evalList(CDR(el), rho));
		t = listAppend(h, t);
		UNPROTECT(2);
		return t;
	}
	else if (CAR(el) == missingArg) {
		return evalList(CDR(el), rho);
	}
	else {
		PROTECT(h = eval(CAR(el), rho));
		PROTECT(t = evalList(CDR(el), rho));
		t = CONS(h, t);
		TAG(t) = TAG(el);
		UNPROTECT(2);
		return t;
	}
}

/* promiseArgs - create a promise to evaluate each argument */
SEXP promiseArgs(SEXP el, SEXP rho)
{
	SEXP h, t;
	if (el == nilValue) {
		return nilValue;
	}
	else if (CAR(el) == DotsSymbol) {
		h = findVar(CAR(el), rho);
		if (TYPEOF(h) != DOTSXP) {
			if (h == missingArg || h == nilValue)
				return promiseArgs(CDR(el), rho);
			error("... used in an incorrect context\n");
		}
		PROTECT(h = promiseArgs(h, rho));
		PROTECT(t = promiseArgs(CDR(el), rho));
		t = listAppend(h, t);
		UNPROTECT(2);
		return t;
	}
	else {
		PROTECT(h = mkPROMISE(CAR(el), rho));
		PROTECT(t = promiseArgs(CDR(el), rho));
		t = CONS(h, t);
		TAG(t) = TAG(el);
		UNPROTECT(2);
		return t;
	}
}


void CheckFormals(SEXP ls)
{
	if (isList(ls))
		for (; ls != nilValue; ls = CDR(ls))
			if (TYPEOF(CAR(ls)) != SYMSXP)
				error("invalid formal argument list for \"function\"\n");
}


/* WrongArgCount - error recovery for wrong # of args */
void WrongArgCount(char *s)
{
	error("incorrect number of arguments to \"%s\"\n", s);
}

/*
 * evaluate the expression given in the argument list in the environment
 * specified by the second argument, for now there won't be a second arg but
 * later....
 */

SEXP do_eval(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP expr, env;
	checkArity(op, args);

	expr = CAR(args);
	if (CADR(args) == nilValue)
		env = sysparent(1);
	else if (TYPEOF(CADR(args)) == ENVSXP)
		env = CADR(args);
	else
		errorcall(call, "invalid second argument\n");
/*
	while(!isNull(expr) && (isLanguage(expr) || isSymbol(expr))) {
		PROTECT(expr);
		expr = eval(expr, env);
		UNPROTECT(1);
	}
*/
	if(isLanguage(expr) || isSymbol(expr)) {
		PROTECT(expr);
		expr = eval(expr, env);
		UNPROTECT(1);
	}
	return expr;
}
