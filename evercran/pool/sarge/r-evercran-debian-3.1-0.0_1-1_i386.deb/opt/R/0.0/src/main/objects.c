/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"

SEXP usemethod(char *generic, SEXP call, SEXP args, SEXP env)
{
	SEXP class, method, sxp;
	char buf[128];
	int i, nclass;

	if(isObject(CAR(args))) {
		class = getAttrib(CAR(args), ClassSymbol);
		nclass = LENGTH(class);
		for(i=0 ; i<nclass ; i++) {
			sprintf(buf, "%s.%s",
				generic,
				CHAR(STRING(class)[i]));
			method = install(buf);
			sxp = findVar(method, env);
			if(isFunction(sxp)) {
				PROTECT(sxp = LCONS(method, args));
				sxp = eval(sxp, env);
				UNPROTECT(1);
				return sxp;
			}
		}
	}
	sprintf(buf, "%s.default", generic);
	method = install(buf);
	sxp = findFun(method, env);
	PROTECT(sxp = LCONS(method, args));
	sxp = eval(sxp, env);
	UNPROTECT(1);
	return sxp;
}

SEXP do_usemethod(SEXP call, SEXP op, SEXP args, SEXP env)
{
	int i, nclass;
	char buf[128];

	int nargs = length(args);
	if(nargs < 2)
		errorcall(call, "too few arguments to UseMethod\n");

	if(TYPEOF(CAR(args)) != STRSXP || LENGTH(CAR(args)) < 1)
		errorcall(call, "first argument must be a method name\n");
	strcpy(buf, CHAR(STRING(CAR(args))[0]));

	return usemethod(buf, call, CDR(args), env);
}
