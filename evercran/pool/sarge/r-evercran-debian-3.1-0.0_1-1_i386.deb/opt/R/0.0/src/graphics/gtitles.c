/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Graphics.h"
#include <math.h>

GTitles(char *main, char *sub, char *xlab, char *ylab)
{
	double x, y;
	double cexsave, colsave, xpdsave;

	if(!GP->ann)
		return;

	/* Conversion of ``lines'' to ``figure location'' */
	x = fabs((GP->cra[1]*GP->mex)/GP->fig2dev.bx);
	y = fabs((GP->cra[1]*GP->mex)/GP->fig2dev.by);

	colsave = GP->col;
	xpdsave = GP->xpd;
	GP->col = 1;
	if(main) {
		cexsave = GP->cex;
		GP->cex = GP->cex * GP->tmag;
		GMoveTo(0.5*(GP->plt[0]+GP->plt[1]), 0.5*(GP->plt[3]+1.0));
		GText(main, 0.5, 0.5);
		GP->cex = cexsave;
	}
	if(xlab) {
		GMoveTo(0.5*(GP->plt[0]+GP->plt[1]), GP->plt[2] - y * (GP->mgp[0]+1.0));
		GText(xlab, 0.5, 0.0);
	}
	if(ylab) {
		GMoveTo(GP->plt[0] - x * GP->mgp[0], 0.5*(GP->plt[2]+GP->plt[3]));
		GRText(ylab, 0.5, 0.0, 90.0);
	}
	GP->col = colsave;
	GP->xpd = xpdsave;
}
