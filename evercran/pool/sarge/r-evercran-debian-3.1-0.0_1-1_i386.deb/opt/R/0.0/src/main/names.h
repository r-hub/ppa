/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#define PP_ASSIGN	 1
#define PP_ASSIGN2	 2
#define PP_BINARY	 3
#define PP_BINARY2	 4
#define PP_BREAK	 5
#define PP_CURLY	 6
#define PP_FOR		 7
#define PP_FUNCALL	 8
#define PP_FUNCTION	 9
#define PP_IF		10
#define PP_NEXT		11
#define PP_PAREN	12
#define PP_RETURN	13
#define PP_SUBASS	14
#define PP_SUBSET	15
#define PP_WHILE	16
#define PP_UNARY	17
#define PP_DOLLAR	18
#define PP_FOREIGN	19
#define PP_REPEAT	20
