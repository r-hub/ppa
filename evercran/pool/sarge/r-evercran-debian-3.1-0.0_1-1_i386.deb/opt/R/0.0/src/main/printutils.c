/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 * Printing:
 *
 * All printing in R is done via the functions Rprintf and REprintf.
 * These routines work exactly like printf(3).  Rprintf writes to
 * ``standard output''.  It is redirected by the sink() function,
 * and is suitable for ordinary output.  REprintf writes to
 * ``standard error'' and is useful for error messages and warnings.
 * It is not redirected by sink().
 *
 * Utilities:
 *
 * The utilities EncodeLogical, EncodeFactor, EncodeInteger, EncodeReal
 * and EncodeString can be used to convert R objects to a form suitable
 * for printing.  These print the values passed in a formatted form
 * or, in the case of NA values, an NA indicator.  EncodeString takes
 * care of printing all the standard ANSI escapes \a, \t \n etc.
 * so that these appear in their backslash form in the string.  There
 * is also a routine called Rstrlen which computes the length of the
 * string in its escaped rather than literal form.
 *
 * Finally there is a routine called EncodeElement which will encode
 * a single R-vector element.  This is mainly used in gizmos like deparse.
 */

#include <math.h>
#include <stdarg.h>
#include "Defn.h"
#include "Print.h"

#define BUFSIZE 512
static char Encodebuf[BUFSIZE];

char *EncodeLogical(RINT x, RINT w)
{
	if (x == NA_LOGICAL) sprintf(Encodebuf, "%*s", (int) w, "NA");
	else if (x) sprintf(Encodebuf, "%*s", (int) w, "T");
	else sprintf(Encodebuf, "%*s", (int) w, "F");
	return Encodebuf;
}

char *EncodeFactor(RINT x, RINT w, char *level)
{
	if (x == NA_INTEGER) sprintf(Encodebuf, "%*s", (int) w, "NA");
	else if(level) sprintf(Encodebuf, "%-*s", (int)w, level);
	else sprintf(Encodebuf, "%*d", w, x + 1);
	return Encodebuf;
}

char *EncodeInteger(RINT x, RINT w)
{
	if (x == NA_INTEGER) sprintf(Encodebuf, "%*s", (int) w, "NA");
	else sprintf(Encodebuf, "%*ld", (int) w, x);
	return Encodebuf;
}

char *EncodeReal(RFLOAT x, RINT w, RINT d, RINT e)
{
	/* BUG - Sun IEEE  & -0 */
	if (x == 0.0) x = 0.0;
	if (x == NA_REAL) sprintf(Encodebuf, "%*s", (int) w, "NA");
	else if (e) sprintf(Encodebuf, "%*.*e", (int) w, (int) d, x);
	else sprintf(Encodebuf, "%*.*f", (int) w, (int) d, x);
	return Encodebuf;
}

static hexdigit(unsigned int x)
{
	return ((x <= 9)? '0' :  'A'-10) + x;
}

int Rstrlen(char *s)
{
	char *p;
	int len;
	len = 0;
	p = s;
	while(*p) {
		if(isprint(*p)) {
			switch(*p) {
			case '\\':
			case '\'':
			case '\"': len += 2; break;
			default: len += 1; break;
			}
		}
		else switch(*p) {
		case '\a':
		case '\b':
		case '\f':
		case '\n':
		case '\r':
		case '\t':
		case '\v': len += 2; break;
		default: len += 4; break;
		}
		p++;
	}
	return len;
}

char *EncodeString(char *s, RINT w, int quote)
{
	int b, i;
	char *p, *q;
	p = s;
	q = Encodebuf;
	if(quote) *q++ = quote;
	while(*p) {
		if(isprint(*p)) {
			switch(*p) {
			case '\\': *q++ = '\\'; *q++ = '\\'; break;
			case '\'': *q++ = '\\'; *q++ = '\''; break;
			case '\"': *q++ = '\\'; *q++ = '\"'; break;
			default: *q++ = *p; break;
			}
		}
		else switch(*p) {
		case '\a': *q++ = '\\'; *q++ = 'a'; break;
		case '\b': *q++ = '\\'; *q++ = 'b'; break;
		case '\f': *q++ = '\\'; *q++ = 'f'; break;
		case '\n': *q++ = '\\'; *q++ = 'n'; break;
		case '\r': *q++ = '\\'; *q++ = 'r'; break;
		case '\t': *q++ = '\\'; *q++ = 't'; break;
		case '\v': *q++ = '\\'; *q++ = 'v'; break;
		default: *q++ = '0'; *q++ = 'x';
			*q++ = hexdigit((*p & 0xF0) >> 4);
			*q++ = hexdigit(*p & 0x0F);
		}
		p++;
	}
	if(quote) *q++ = quote; *q = '\0';
	b = w - strlen(Encodebuf);
	for(i=0 ; i<b ; i++) *q++ = ' ';
	*q = '\0';
	return Encodebuf;
}

char *EncodeRjustString(char *s, RINT w, int quote)
{
	int b, i;
	char *p, *q;
	p = s;
	q = Encodebuf;
	b = w - Rstrlen(s) - (quote ? 2 : 0);
	for(i=0 ; i<b ; i++) *q++ = ' ';
	if(quote) *q++ = quote;
	while(*p) {
		if(isprint(*p)) {
			switch(*p) {
			case '\\': *q++ = '\\'; *q++ = '\\'; break;
			case '\'': *q++ = '\\'; *q++ = '\''; break;
			case '\"': *q++ = '\\'; *q++ = '\"'; break;
			default: *q++ = *p; break;
			}
		}
		else switch(*p) {
		case '\a': *q++ = '\\'; *q++ = 'a'; break;
		case '\b': *q++ = '\\'; *q++ = 'b'; break;
		case '\f': *q++ = '\\'; *q++ = 'f'; break;
		case '\n': *q++ = '\\'; *q++ = 'n'; break;
		case '\r': *q++ = '\\'; *q++ = 'r'; break;
		case '\t': *q++ = '\\'; *q++ = 't'; break;
		case '\v': *q++ = '\\'; *q++ = 'v'; break;
		default: *q++ = '0'; *q++ = 'x';
			*q++ = hexdigit((*p & 0xF0) >> 4);
			*q++ = hexdigit(*p & 0x0F);
		}
		p++;
	}
	if(quote) *q++ = quote;
	*q = '\0';
	return Encodebuf;
}

char *EncodeElement(SEXP x, RINT index, int quote)
{
	int w, d, e;
	switch(TYPEOF(x)) {
		case LGLSXP:
			formatLogical(&INTEGER(x)[index], 1, &w);
			EncodeLogical(INTEGER(x)[index], w);
			break;
		case INTSXP:
		case FACTSXP:
		case ORDSXP:
			/* TODO - Separate Factor */
			formatInteger(&INTEGER(x)[index], 1, &w);
			EncodeInteger(INTEGER(x)[index], w);
			break;
		case REALSXP:
			formatReal(&REAL(x)[index], 1, &w, &d, &e);
			EncodeReal(REAL(x)[index], w, d, e);
			break;
		case STRSXP:
			formatString(&STRING(x)[index], 1, &w, quote);
			EncodeString(CHAR(STRING(x)[index]), w, quote);
			break;
	}
	return Encodebuf;
}

int Rprintf(char *format, ...)
{
	va_list(ap);
	va_start(ap, format);
	if(Routputfile) {
		vfprintf(Routputfile, format, ap);
	}
	else {
		char buf[BUFSIZE]; int len;
		vsprintf(buf, format, ap);
		len = strlen(buf);
		writecons(buf, len);
	}
	va_end(ap);
}

int REprintf(char *format, ...)
{
	va_list(ap);
	va_start(ap, format);
	if(Rconsolefile) {
		vfprintf(Rconsolefile, format, ap);
	}
	else {
		char buf[BUFSIZE]; int len;
		vsprintf(buf, format, ap);
		len = strlen(buf);
		writecons(buf, len);
	}
	va_end(ap);
}

int Rvprintf(const char *format, va_list arg)
{
	if(Routputfile) {
		vfprintf(Routputfile, format, arg);
	}
	else {
		char buf[BUFSIZE]; int slen;
		vsprintf(buf, format, arg);
		slen = strlen(buf);
		writecons(buf, slen);
	}
}

int REvprintf(const char *format, va_list arg)
{
	if(Rconsolefile) {
		vfprintf(Rconsolefile, format, arg);
	}
	else {
		char buf[BUFSIZE]; int slen;
		vsprintf(buf, format, arg);
		slen = strlen(buf);
		writecons(buf, slen);
	}
}

int IndexWidth(RINT n)
{
	return (RINT) (log10(n + 0.5) + 1);
}

void VectorIndex(RINT i, RINT w)
{
	Rprintf("%*s[%ld]", w-IndexWidth(i)-2, "", i);
}

void MatrixColumnLabel(SEXP * cl, RINT j, RINT w)
{
	int l;

	if (cl) { 
		l = Rstrlen(CHAR(cl[j]));
		Rprintf("%*s%s", w-l+PRINT_GAP, "", EncodeString(CHAR(cl[j]), l, 0));
	}
	else {
		Rprintf("%*s[,%ld]", w-IndexWidth(j+1)+PRINT_GAP-3, "", j+1);
	}
}
 
void MatrixRowLabel(SEXP * rl, RINT i, RINT rlabw)
{
	int l;

	if (rl) {
		l = Rstrlen(CHAR(rl[i]));
		Rprintf("\n%s%*s", EncodeString(CHAR(rl[i]), l, 0), rlabw-l, "");
	}
	else {
		Rprintf("\n%*s[%ld,]", rlabw-3-IndexWidth(i + 1), "", i+1);
	}
}
