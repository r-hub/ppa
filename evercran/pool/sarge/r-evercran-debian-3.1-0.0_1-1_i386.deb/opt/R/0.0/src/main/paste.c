/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <string.h>
#include "Defn.h"
#include "Print.h"

/* do_paste uses two passes to paste the arguments (in CAR(args)) */
/* together the first pass calculates the width of the paste buffer, */
/* then it is alloc-ed and the second pass stuffs the information in. */

SEXP mkChar(char *);

SEXP do_paste(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP x, y, rvec, fwidth, dwidth, tmpchar, tmpx;
	RINT lenx, maxlen, i, w, n, e, tlen, sepw, pos, pwidth, islist;
	char *buff;

	checkArity(op, args);

	x = CAR(args);
	if (!isList(x))
		error("invalid first argument to internal paste\n");

	y = CADR(args);
	if (!isString(y) || LENGTH(y) <= 0)
		error("invalid paste separator\n");
	y = STRING(y)[0];
	sepw = LENGTH(y);

	/* Maximum argument length and */
	/* check for arguments of list type */

	lenx = length(x);
	maxlen = 0;
	islist = 0;
	for (rvec = x; rvec != nilValue; rvec = CDR(rvec)) {
		if (isList(CAR(rvec)))
			islist++;
		maxlen = (length(CAR(rvec)) > maxlen) ? length(CAR(rvec)) : maxlen;
	}

	/* Do this only if there is a list argument */
	/* so we don't automatically duplicate something large */

	if (islist) {
		PROTECT(x = duplicate(CAR(args)));
		for (rvec = x; rvec != nilValue; rvec = CDR(rvec))
			if (isList(CAR(rvec)))
				CAR(rvec) = coerceList(CAR(rvec), STRSXP);
		UNPROTECT(1);
	}

	/* Allocate accounting structures */

	PROTECT(x);
	PROTECT(rvec = allocVector(STRSXP, maxlen));
	PROTECT(fwidth = allocVector(INTSXP, lenx));
	PROTECT(dwidth = allocVector(INTSXP, lenx));
	setIVector(INTEGER(fwidth), lenx, 0);
	setIVector(INTEGER(dwidth), lenx, 0);

	for (i = 0; i < maxlen; i++) {
		pos = 0;
		pwidth = 0;
		for (tmpx = x; tmpx != nilValue; tmpx = CDR(tmpx)) {
			tlen = length(CAR(tmpx));
			if (tlen > 0) {
				switch (TYPEOF(CAR(tmpx))) {
				case STRSXP:
					INTEGER(fwidth)[pos] = LENGTH(STRING(CAR(tmpx))[i % tlen]);
					break;
				case INTSXP:
					formatInteger(&INTEGER(CAR(tmpx))[i % tlen], 1, &w);
					INTEGER(fwidth)[pos] = w;
					break;
				case REALSXP:
					formatReal(&REAL(CAR(tmpx))[i % tlen], 1, &w, &n, &e);
					if (e)	/* print using e format */
						INTEGER(fwidth)[pos] = -w;
					else
						INTEGER(fwidth)[pos] = w;
					INTEGER(dwidth)[pos] = n;
					break;
				default:
					abort();
				}
				pwidth += abs(INTEGER(fwidth)[pos]);
			}
			pos++;
		}
		pwidth += (lenx - 1) * sepw;
		tmpchar = allocString(pwidth);
		buff = CHAR(tmpchar);
		pos = 0;
		for (tmpx = x; tmpx != nilValue; tmpx = CDR(tmpx)) {
			tlen = length(CAR(tmpx));
			w = INTEGER(fwidth)[pos];
			n = INTEGER(dwidth)[pos];
			if (tlen > 0) {
				switch (TYPEOF(CAR(tmpx))) {
				case STRSXP:
					sprintf(buff, "%*s", (int) w, CHAR(STRING(CAR(tmpx))[i % tlen]));
					break;
				case INTSXP:
					if (INTEGER(CAR(tmpx))[i % tlen] == NA_INTEGER)
						sprintf(buff, "%*s", (int) w, "NA");
					else
						sprintf(buff, "%*ld", (int) w, INTEGER(CAR(tmpx))[i % tlen]);
					break;
				case REALSXP:
					if (REAL(CAR(tmpx))[i % tlen] == NA_REAL)
						sprintf(buff, "%*s", (int) w, "NA");
					else if (w < 0)
						sprintf(buff, "%*.*e", (int) (-w), (int) n, REAL(CAR(tmpx))[i % tlen]);
					else
						sprintf(buff, "%*.*f", (int) w, (int) n, REAL(CAR(tmpx))[i % tlen]);
					break;
				default:
					abort();
				}
			}
			buff += abs(w);
			if (CDR(tmpx) != nilValue && sepw != 0) {
				sprintf(buff, "%*s", (int) sepw, CHAR(y));
				buff += sepw;
			}
			INTEGER(fwidth)[pos] = 0;	/* zero these out for the next go */
			INTEGER(dwidth)[pos] = 0;
			pos++;
			if ((buff - CHAR(tmpchar)) > pwidth)
				error("paste: buffer too small\n");
		}
		STRING(rvec)[i] = tmpchar;
	}
	UNPROTECT(4);
	return rvec;
}

SEXP do_format(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP x, y;
	int i, n, trim;
	RINT w, d, e;
	char *strp;

	switch (length(args)) {
	case 1:
		trim = 0;
		break;
	case 2:
		trim = asLogical(CADR(args));
		if (trim == NA_INTEGER)
			errorcall(call, "invalid \"trim\" argument\n");
		break;
	default:
		errorcall(call, "incorrect number of arguments\n");
	}

	if (!isVector(x = CAR(args)))
		errorcall(call, "first argument must be atomic\n");

	if ((n = LENGTH(x)) <= 0)
		return allocVector(STRSXP, 0);

	switch (TYPEOF(x)) {
	case LGLSXP:
		PROTECT(y = allocVector(STRSXP, n));
		if (trim)
			w = 0;
		else
			formatLogical(LOGICAL(x), n, &w);
		for (i = 0; i < n; i++) {
			strp = EncodeLogical(LOGICAL(x)[i], w);
			STRING(y)[i] = mkChar(strp);
		}
		UNPROTECT(1);
		break;
	case INTSXP:
	case FACTSXP:
	case ORDSXP:
		PROTECT(y = allocVector(STRSXP, n));
		if (trim)
			w = 0;
		else
			formatInteger(INTEGER(x), n, &w);
		for (i = 0; i < n; i++) {
			strp = EncodeInteger(INTEGER(x)[i], w);
			STRING(y)[i] = mkChar(strp);
		}
		UNPROTECT(1);
		break;
	case REALSXP:
		formatReal(REAL(x), n, &w, &d, &e);
		if (trim)
			w = 0;
		PROTECT(y = allocVector(STRSXP, n));
		for (i = 0; i < n; i++) {
			strp = EncodeReal(REAL(x)[i], w, d, e);
			STRING(y)[i] = mkChar(strp);
		}
		UNPROTECT(1);
		break;
	case STRSXP:
		formatString(STRING(x), n, &w, 0);
		if (trim) w = 0;
		PROTECT(y = allocVector(STRSXP, n));
		for (i = 0; i < n; i++) {
			strp = EncodeString(CHAR(STRING(x)[i]), w, 0);
			STRING(y)[i] = mkChar(strp);
		}
		UNPROTECT(1);
		break;
	}
	return y;
}
