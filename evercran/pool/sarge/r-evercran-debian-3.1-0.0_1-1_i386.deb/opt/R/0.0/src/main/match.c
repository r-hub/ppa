/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"

/*
 * This code will perform partial matching for list tags.
 *
 * Examples:
 *
 *      psmatch("aaa", "aaa") -> 1
 *      psmatch("aaa", "aa") -> 1
 *      psmatch("aa", "aaa") -> 0
 */


/******************************************/
/* Basic gizmo - called by wrappers below */
/******************************************/

int psmatch(char *f, char *t)
{
	while (*f || *t) {
		if (*t == '\0')
			return 1;
		if (*f == '\0')
			return 0;
		if (*t != *f)
			return 0;
		t++;
		f++;
	}
	return 1;
}

/**********************************/
/* Matching formals and arguments */
/**********************************/

int pmatch(SEXP formal, SEXP tag)
{
	return psmatch(CHAR(PRINTNAME(formal)), CHAR(PRINTNAME(tag)));
}

/**************************************************/
/* Destructively Extract A Named List Element     */
/* Returns the first partially matching tag found */
/* Pattern is a C string                          */
/**************************************************/

SEXP matchPar(char *tag, SEXP * list)
{
	SEXP *l, s;

	for (l = list; *l != nilValue; l = &CDR(*l))
		if (TAG(*l) != nilValue && psmatch(tag, CHAR(PRINTNAME(TAG(*l))))) {
			s = *l;
			*l = CDR(*l);
			return CAR(s);
		}
	return missingArg;
}

/**************************************************/
/* Destructively Extract A Named List Element     */
/* Returns the first partially matching tag found */
/* Pattern is a symbol                            */
/**************************************************/

SEXP matchArg(SEXP tag, SEXP * list)
{
	return matchPar(CHAR(PRINTNAME(tag)), list);
}
