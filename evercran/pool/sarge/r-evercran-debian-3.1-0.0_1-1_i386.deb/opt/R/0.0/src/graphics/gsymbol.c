/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Graphics.h"
#include <math.h>

GSymbol(int pch)
{
	double x, y, xc, yc;

	x = DP->xlast;
        y = DP->ylast;
	xc = 0.33 * fabs(GP->cex * GP->cra[1] * GP->asp / GP->fig2dev.bx);
	yc = 0.33 * fabs(GP->cex * GP->cra[1] / GP->fig2dev.by);

	switch(pch) {
	case 0:			/* SQUARE */
		GStartPath();
		GMoveTo(x-xc, y-yc);
		GLineTo(x-xc, y+yc);
		GLineTo(x+xc, y+yc);
		GLineTo(x+xc, y-yc);
		GLineTo(x-xc, y-yc);
		GEndPath();
		break;
	case 1:			/* OCTAGON */
		GStartPath();
		GMoveTo(x-0.5*xc, y-yc);
		GLineTo(x-xc, y-0.5*yc);
		GLineTo(x-xc, y+0.5*yc);
		GLineTo(x-0.5*xc, y+yc);
		GLineTo(x+0.5*xc, y+yc);
		GLineTo(x+xc, y+0.5*yc);
		GLineTo(x+xc, y-0.5*yc);
		GLineTo(x+0.5*xc, y-yc);
		GLineTo(x-0.5*xc, y-yc);
		GEndPath();
		break;
	case 2:			/* TRIANGLE POINT-UP */
		GStartPath();
		GMoveTo(x-xc, y-yc);
		GLineTo(x, y+yc);
		GLineTo(x+xc, y-yc);
		GLineTo(x-xc, y-yc);
		GEndPath();
		break;
	case 3:			/* PLUS */
		GStartPath();
		GMoveTo(x-xc, y);
		GLineTo(x+xc, y);
		GMoveTo(x, y-yc);
		GLineTo(x, y+yc);
		GEndPath();
		break;
	case 4:			/* TIMES */
		GStartPath();
		GMoveTo(x-xc, y+yc);
		GLineTo(x+xc, y-yc);
		GMoveTo(x-xc, y-yc);
		GLineTo(x+xc, y+yc);
		GEndPath();
		break;
	case 5:			/* DIAMOND */
		GStartPath();
		GMoveTo(x, y-yc);
		GLineTo(x-xc, y);
		GLineTo(x, y+yc);
		GLineTo(x+xc, y);
		GLineTo(x, y-yc);
		GEndPath();
		break;
	case 6:
		GStartPath();
		GMoveTo(x-xc,y+yc);
		GLineTo(x+xc,y+yc);
		GLineTo(x,y-yc);
		GLineTo(x-xc,y+yc);
		GEndPath();
		break;
	case 7:
		GSymbol(0);
		GMoveTo(x,y);
		GSymbol(4);
		break;
	case 8:
		GSymbol(3);
		GMoveTo(x,y);
		GSymbol(4);
		break;
	case 9:
		GSymbol(3);
		GMoveTo(x,y);
		GSymbol(5);
		break;
	case 10:
		GSymbol(1);
		GMoveTo(x,y);
		GSymbol(3);
		break;
	case 11:
		GSymbol(2);
		GMoveTo(x,y);
		GSymbol(6);
		break;
	case 12:
		GSymbol(0);
		GMoveTo(x,y);
		GSymbol(3);
		break;
	case 13:
		GSymbol(1);
		GMoveTo(x,y);
		GSymbol(4);
		break;
	case 14:
		GSymbol(0);
		GMoveTo(x,y);
		GSymbol(2);
		break;
	}
}
